# GesTora na Vercel

Versão da GesTora adaptada para correr na Vercel com o runtime comunitário `vercel-php`.

## O que mudou em relação à versão original

| Antes (Apache/cPanel)                         | Agora (Vercel)                                                    |
|-----------------------------------------------|-------------------------------------------------------------------|
| `config/config.local.php` escrito pelo instalador | Variáveis de ambiente (`DB_HOST`, `DB_USER`, …)               |
| `install.lock` em disco                       | Bloqueio automático quando já existe um utilizador na BD          |
| Sessões em ficheiros                          | Sessões na tabela `sessoes` (criada automaticamente)              |
| `.htaccess` a proteger pastas                 | `api/index.php` só executa `.php` que estejam diretamente em `app/` |
| `assets/` na raiz                             | `public/assets/` (servido como ficheiros estáticos)               |
| IP lido de `REMOTE_ADDR`                      | IP lido de `X-Forwarded-For` (apenas quando corre na Vercel)      |

Estrutura:

```
api/index.php      ponto de entrada (front controller)
app/               páginas PHP, includes/, config/, database/
public/assets/     CSS, JS e imagens
vercel.json        runtime PHP + rotas
```

## Passo a passo

### 1. Criar a base de dados MySQL
A Vercel não tem MySQL. Precisas de um MySQL/MariaDB acessível pela Internet **com TLS**.
O TiDB Cloud Starter (compatível com MySQL) é uma opção; qualquer outro MySQL 8 / MariaDB 10.3+ serve.

- Cria uma base de dados vazia (ex.: `gestora`) e anota host, porta, utilizador e palavra-passe.
- Escolhe a região mais próxima da região das funções (por defeito `fra1`, Frankfurt). Se a base de dados
  ficar noutra região, muda `"regions"` em `vercel.json` (por exemplo `iad1` para costa leste dos EUA).
  Funções e base de dados longe uma da outra deixam o sistema muito lento.

### 2. Enviar o projeto
Põe esta pasta num repositório Git (GitHub/GitLab/Bitbucket) e importa-o na Vercel (**Add New → Project**),
ou usa a CLI: `npm i -g vercel && vercel`.
Deixa **Framework Preset = Other** e não definas Build Command.

### 3. Variáveis de ambiente (Project → Settings → Environment Variables)

| Variável        | Valor                                                                    |
|-----------------|--------------------------------------------------------------------------|
| `DB_HOST`       | servidor da base de dados                                                |
| `DB_PORT`       | porta (3306 no MySQL; 4000 no TiDB)                                      |
| `DB_NAME`       | nome da base de dados                                                    |
| `DB_USER`       | utilizador                                                               |
| `DB_PASS`       | palavra-passe                                                            |
| `DB_SSL`        | `1` (quase todos os serviços geridos exigem TLS)                         |
| `SETUP_TOKEN`   | segredo à tua escolha (mín. 16 caracteres) para poderes correr o instalador |
| `APP_TIMEZONE`  | opcional, por defeito `Africa/Luanda`                                    |
| `APP_DEBUG`     | opcional, `1` para ver erros detalhados (desliga depois)                 |

Se a ligação TLS falhar por falta de certificado, descarrega o certificado CA do teu fornecedor,
guarda-o como `app/config/ca.pem` e faz novo deploy. (Na Vercel o bundle do sistema em
`/etc/pki/tls/certs/ca-bundle.crt` é detetado automaticamente.)

### 4. Deploy e instalação
1. Faz o deploy (ou **Redeploy** depois de definir as variáveis).
2. Abre `https://o-teu-projeto.vercel.app/install.php`.
3. Escreve o `SETUP_TOKEN`, os dados da empresa e do administrador, e clica **Instalar agora**.
4. Entra no sistema. O instalador fica bloqueado sozinho. Remove `SETUP_TOKEN` das variáveis por segurança.

### Migrar os dados que já tens
Se já tens dados no GesTora local, em vez do instalador exporta e importa a base de dados:

```
mysqldump -u root -p gestora > gestora.sql
mysql -h HOST -P PORTA -u UTILIZADOR -p --ssl-mode=VERIFY_IDENTITY NOME_BD < gestora.sql
```
Depois abre `/login.php` normalmente.

## Limitações a ter em conta
- O runtime `vercel-php` é mantido pela comunidade, não pela Vercel.
- Não há disco persistente: qualquer funcionalidade futura que grave ficheiros (anexos, logos) precisa de armazenamento externo (ex.: Vercel Blob).
- O primeiro pedido depois de um período parado é mais lento (arranque a frio).
- Faz cópias de segurança regulares da base de dados.
