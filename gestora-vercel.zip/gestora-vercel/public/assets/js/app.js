/* GesTora — comportamentos comuns da interface */
(function () {
  'use strict';

  var root = document.documentElement;

  /* ---------- Tema claro / escuro ---------- */
  var themeBtn = document.getElementById('themeBtn');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('gt-theme', next); } catch (e) {}
      document.dispatchEvent(new Event('gt:theme'));
    });
  }

  /* ---------- Menu lateral (telemóvel) ---------- */
  var menuBtn = document.getElementById('menuBtn');
  var scrim = document.getElementById('scrim');
  if (menuBtn) menuBtn.addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
  if (scrim) scrim.addEventListener('click', function () { document.body.classList.remove('nav-open'); });

  /* ---------- Menus suspensos ---------- */
  document.addEventListener('click', function (ev) {
    var trigger = ev.target.closest('[data-dropdown]');
    var openOnes = document.querySelectorAll('.dropdown.open');
    if (trigger) {
      var dd = trigger.closest('.dropdown');
      var wasOpen = dd.classList.contains('open');
      openOnes.forEach(function (d) { d.classList.remove('open'); });
      if (!wasOpen) dd.classList.add('open');
      return;
    }
    if (!ev.target.closest('.dropdown-menu')) openOnes.forEach(function (d) { d.classList.remove('open'); });
  });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') document.querySelectorAll('.dropdown.open').forEach(function (d) { d.classList.remove('open'); });
  });

  /* ---------- Mensagens flash ---------- */
  document.querySelectorAll('.flash').forEach(function (f) {
    var x = f.querySelector('.flash-x');
    if (x) x.addEventListener('click', function () { f.remove(); });
    if (f.classList.contains('flash-success')) setTimeout(function () { f.style.transition = 'opacity .4s'; f.style.opacity = '0'; setTimeout(function () { f.remove(); }, 450); }, 6000);
  });

  /* ---------- Confirmações ---------- */
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    var msg = f.getAttribute && f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) ev.preventDefault();
  });
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-confirm-click]');
    if (b && !window.confirm(b.getAttribute('data-confirm-click'))) { ev.preventDefault(); }
  });

  /* ---------- Mostrar/ocultar palavra-passe ---------- */
  document.querySelectorAll('.toggle-pass').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-target'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Ocultar palavra-passe' : 'Mostrar palavra-passe');
      btn.querySelector('.i-show').classList.toggle('hide', show);
      btn.querySelector('.i-hide').classList.toggle('hide', !show);
    });
  });

  /* ---------- Evitar duplo envio ---------- */
  document.querySelectorAll('form[data-once]').forEach(function (f) {
    f.addEventListener('submit', function () {
      var btns = f.querySelectorAll('button[type=submit]');
      setTimeout(function () { btns.forEach(function (b) { b.disabled = true; }); }, 0);
    });
  });

  /* ---------- Formatação ---------- */
  function fmt(v, cur) {
    var n = Number(v) || 0;
    var s = n.toLocaleString('de-DE', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    return cur ? s + ' ' + cur : s;
  }
  window.GT = { fmt: fmt };

  /* ---------- Gráficos (SVG leves) ---------- */
  var tip = document.createElement('div');
  tip.className = 'chart-tip';
  document.body.appendChild(tip);

  function niceMax(v) {
    if (v <= 0) return 10;
    var p = Math.pow(10, Math.floor(Math.log10(v)));
    var n = v / p;
    var m = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
    return m * p;
  }

  function el(tag, attrs, text) {
    var n = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }

  function shortNum(v) {
    var a = Math.abs(v);
    if (a >= 1e6) return (v / 1e6).toLocaleString('de-DE', { maximumFractionDigits: 1 }) + ' M';
    if (a >= 1e3) return (v / 1e3).toLocaleString('de-DE', { maximumFractionDigits: 1 }) + ' k';
    return v.toLocaleString('de-DE');
  }

  function drawChart(host) {
    var cfg;
    try { cfg = JSON.parse(host.getAttribute('data-chart')); } catch (e) { return; }
    var cur = host.getAttribute('data-currency') || '';
    var labels = cfg.labels || [];
    var series = cfg.series || [];
    host.innerHTML = '';
    if (!labels.length || !series.length) return;

    var W = 720, H = 300, ml = 52, mr = 14, mt = 14, mb = 34;
    var pw = W - ml - mr, ph = H - mt - mb;
    var all = [];
    series.forEach(function (s) { s.values.forEach(function (v) { all.push(Number(v) || 0); }); });
    var mx = niceMax(Math.max.apply(null, all.concat([0])));
    var mn = Math.min.apply(null, all.concat([0]));
    var lo = mn < 0 ? -niceMax(-mn) : 0;
    var span = mx - lo || 1;
    var y = function (v) { return mt + ph - ((v - lo) / span) * ph; };

    var svg = el('svg', { viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': cfg.title || 'Gráfico' });
    var defs = el('defs', {});
    var g1 = el('linearGradient', { id: 'chArea', x1: 0, y1: 0, x2: 0, y2: 1 });
    g1.appendChild(el('stop', { offset: '0', 'stop-color': '#00b4ff', 'stop-opacity': '.38' }));
    g1.appendChild(el('stop', { offset: '1', 'stop-color': '#0a5cff', 'stop-opacity': '0' }));
    var g2 = el('linearGradient', { id: 'chBar', x1: 0, y1: 0, x2: 0, y2: 1 });
    g2.appendChild(el('stop', { offset: '0', 'stop-color': '#00b4ff' }));
    g2.appendChild(el('stop', { offset: '1', 'stop-color': '#0a3cff' }));
    defs.appendChild(g1); defs.appendChild(g2); svg.appendChild(defs);

    var ticks = 5;
    for (var i = 0; i <= ticks; i++) {
      var tv = lo + (span * i) / ticks, ty = y(tv);
      svg.appendChild(el('line', { x1: ml, x2: W - mr, y1: ty, y2: ty, 'class': 'ch-grid' }));
      svg.appendChild(el('text', { x: ml - 8, y: ty + 4, 'text-anchor': 'end', 'class': 'ch-axis' }, shortNum(tv)));
    }

    var n = labels.length;
    var step = pw / n;
    var every = Math.ceil(n / 12);
    labels.forEach(function (lb, idx) {
      if (idx % every) return;
      svg.appendChild(el('text', { x: ml + step * idx + step / 2, y: H - 10, 'text-anchor': 'middle', 'class': 'ch-axis' }, lb));
    });

    if (cfg.type === 'bar') {
      var sn = series.length, gw = step * 0.72, bw = gw / sn;
      series.forEach(function (s, si) {
        s.values.forEach(function (v, idx) {
          v = Number(v) || 0;
          var x = ml + step * idx + (step - gw) / 2 + bw * si;
          var y0 = y(0), y1 = y(v);
          var r = el('rect', { x: x + 1, y: Math.min(y0, y1), width: Math.max(bw - 2, 1), height: Math.max(Math.abs(y0 - y1), 1), rx: 4, 'class': si === 0 ? 'ch-bar' : 'ch-bar2' });
          svg.appendChild(r);
        });
      });
    } else {
      series.forEach(function (s, si) {
        var pts = s.values.map(function (v, idx) { return [ml + step * idx + step / 2, y(Number(v) || 0)]; });
        if (si === 0 && pts.length > 1) {
          var area = 'M' + pts[0][0] + ',' + y(0) + ' L' + pts.map(function (p) { return p.join(','); }).join(' L') + ' L' + pts[pts.length - 1][0] + ',' + y(0) + ' Z';
          svg.appendChild(el('path', { d: area, fill: 'url(#chArea)' }));
        }
        svg.appendChild(el('path', { d: 'M' + pts.map(function (p) { return p.join(','); }).join(' L'), 'class': si === 0 ? 'ch-line' : 'ch-line2' }));
        if (si === 0) pts.forEach(function (p) { svg.appendChild(el('circle', { cx: p[0], cy: p[1], r: 4, 'class': 'ch-dot' })); });
      });
    }

    /* áreas de hover + tooltip */
    labels.forEach(function (lb, idx) {
      var hit = el('rect', { x: ml + step * idx, y: mt, width: step, height: ph, 'class': 'ch-hit' });
      hit.addEventListener('mousemove', function (ev) {
        tip.innerHTML = '<b>' + lb + '</b>' + series.map(function (s) {
          return '<div>' + (series.length > 1 ? s.name + ': ' : '') + fmt(s.values[idx], cur) + '</div>';
        }).join('');
        tip.style.opacity = '1';
        tip.style.left = Math.min(ev.clientX + 14, window.innerWidth - 180) + 'px';
        tip.style.top = (ev.clientY + 14) + 'px';
      });
      hit.addEventListener('mouseleave', function () { tip.style.opacity = '0'; });
      svg.appendChild(hit);
    });
    host.appendChild(svg);
  }

  document.querySelectorAll('[data-chart]').forEach(drawChart);

})();
