/* GesTora — formulário de nova venda */
(function () {
  'use strict';
  var data = JSON.parse(document.getElementById('saleData').textContent);
  var tbody = document.querySelector('#lines tbody');
  var noLines = document.getElementById('noLines');
  var search = document.getElementById('prodSearch');
  var list = document.getElementById('acList');
  var descInput = document.getElementById('desconto');
  var pagoWrap = document.getElementById('pagoWrap');
  var cur = data.moeda;

  function dec(s) {
    s = String(s == null ? '' : s).replace(/\s| /g, '');
    if (s.indexOf(',') > -1 && s.indexOf('.') > -1) s = s.replace(/\./g, '').replace(',', '.');
    else if (s.indexOf(',') > -1) s = s.replace(',', '.');
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }
  function money(n) { return GT.fmt(Math.round(n * 100) / 100, cur); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function addLine(l) {
    l = l || { pid: 0, desc: '', qty: 1, preco: 0 };
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td><input type="hidden" name="item_pid[]" value="' + (l.pid || '') + '">' +
      '<input class="l-desc" type="text" name="item_desc[]" value="' + esc(l.desc) + '" placeholder="Descrição do item" maxlength="200" aria-label="Descrição"' + (l.pid ? ' data-pid="1"' : '') + '></td>' +
      '<td><input class="l-qty" type="text" inputmode="decimal" name="item_qty[]" value="' + (l.qty != null ? l.qty : 1) + '" aria-label="Quantidade"></td>' +
      '<td><input class="l-price" type="text" inputmode="decimal" name="item_preco[]" value="' + (l.preco != null ? l.preco : 0) + '" aria-label="Preço unitário"></td>' +
      '<td class="l-total">0</td>' +
      '<td><button type="button" class="btn btn-sm btn-icon btn-danger rm" title="Remover linha" aria-label="Remover linha">&times;</button></td>';
    tbody.appendChild(tr);
    recalc();
    return tr;
  }

  function addProduct(p) {
    // Se já existir, soma 1 à quantidade
    var rows = tbody.querySelectorAll('tr');
    for (var i = 0; i < rows.length; i++) {
      var pid = rows[i].querySelector('[name="item_pid[]"]').value;
      if (String(pid) === String(p.id)) {
        var q = rows[i].querySelector('.l-qty');
        q.value = dec(q.value) + 1;
        recalc();
        return;
      }
    }
    addLine({ pid: p.id, desc: p.nome, qty: 1, preco: p.preco });
  }

  function recalc() {
    var sub = 0, any = false;
    tbody.querySelectorAll('tr').forEach(function (tr) {
      var q = dec(tr.querySelector('.l-qty').value), pr = dec(tr.querySelector('.l-price').value);
      var t = Math.round(q * pr * 100) / 100;
      tr.querySelector('.l-total').textContent = money(t);
      sub += t; any = true;
    });
    noLines.style.display = any ? 'none' : '';
    var desc = Math.max(0, Math.min(dec(descInput.value), sub));
    var liquido = sub - desc, taxa = data.iva, base, iva, total;
    if (data.incluiIva) { total = liquido; base = taxa > 0 ? total / (1 + taxa / 100) : total; iva = total - base; }
    else { base = liquido; iva = base * taxa / 100; total = base + iva; }
    document.getElementById('tSub').textContent = money(sub);
    document.getElementById('tDesc').textContent = '− ' + money(desc);
    document.getElementById('tBase').textContent = money(base);
    document.getElementById('tIva').textContent = money(iva);
    document.getElementById('tTotal').textContent = money(total);
    document.getElementById('tIvaLbl').textContent = 'IVA (' + taxa + '%)' + (data.incluiIva ? ' incluído' : '');
    document.getElementById('saveBtn').disabled = !any;
  }

  tbody.addEventListener('input', recalc);
  tbody.addEventListener('click', function (ev) {
    var b = ev.target.closest('.rm');
    if (b) { b.closest('tr').remove(); recalc(); }
  });
  descInput.addEventListener('input', recalc);
  document.getElementById('addLine').addEventListener('click', function () { addLine().querySelector('.l-desc').focus(); });

  /* Pagamento parcial */
  function togglePago() {
    var parcial = document.querySelector('[name=pago_modo]:checked').value === 'parcial';
    pagoWrap.style.display = parcial ? '' : 'none';
  }
  document.querySelectorAll('[name=pago_modo]').forEach(function (r) { r.addEventListener('change', togglePago); });
  togglePago();

  /* Pesquisa de produtos */
  var hl = -1, found = [];
  function render(items) {
    found = items; hl = -1;
    if (!items.length) { list.innerHTML = '<div class="ac-empty">Nenhum produto encontrado.</div>'; list.classList.add('open'); return; }
    list.innerHTML = items.map(function (p, i) {
      var info = p.tipo === 'stock' ? (p.stock > 0 ? p.stock + ' em stock' : 'sem stock') : (p.tipo === 'servico' ? 'serviço' : 'dropshipping');
      return '<div class="ac-item" role="option" data-i="' + i + '"><span>' + esc(p.nome) + (p.codigo ? ' <small>' + esc(p.codigo) + '</small>' : '') + '</span><span><b>' + money(p.preco) + '</b> <small>' + info + '</small></span></div>';
    }).join('');
    list.classList.add('open');
  }
  function doSearch() {
    var t = search.value.trim().toLowerCase();
    if (!t) { list.classList.remove('open'); return; }
    var res = data.produtos.filter(function (p) {
      return p.nome.toLowerCase().indexOf(t) > -1 || (p.codigo && p.codigo.toLowerCase().indexOf(t) > -1);
    }).slice(0, 12);
    render(res);
  }
  function pick(i) {
    var p = found[i];
    if (!p) return;
    addProduct(p);
    search.value = ''; list.classList.remove('open'); search.focus();
  }
  search.addEventListener('input', doSearch);
  search.addEventListener('focus', doSearch);
  search.addEventListener('keydown', function (ev) {
    var items = list.querySelectorAll('.ac-item');
    if (ev.key === 'ArrowDown') { ev.preventDefault(); hl = Math.min(hl + 1, items.length - 1); }
    else if (ev.key === 'ArrowUp') { ev.preventDefault(); hl = Math.max(hl - 1, 0); }
    else if (ev.key === 'Enter') { ev.preventDefault(); pick(hl >= 0 ? hl : 0); return; }
    else if (ev.key === 'Escape') { list.classList.remove('open'); return; }
    else return;
    items.forEach(function (n, i) { n.classList.toggle('hl', i === hl); });
  });
  list.addEventListener('mousedown', function (ev) {
    var it = ev.target.closest('.ac-item');
    if (it) { ev.preventDefault(); pick(parseInt(it.getAttribute('data-i'), 10)); }
  });
  document.addEventListener('click', function (ev) { if (!ev.target.closest('.ac-wrap')) list.classList.remove('open'); });

  document.getElementById('saleForm').addEventListener('submit', function (ev) {
    if (!tbody.children.length) { ev.preventDefault(); }
  });

  (data.linhas || []).forEach(function (l) { addLine({ pid: l.pid, desc: l.desc, qty: l.qty, preco: l.preco }); });
  recalc();
})();
