(function () {
  'use strict';
  var link = document.getElementById('forgotLink');
  var note = document.getElementById('forgotNote');
  if (link && note) {
    link.addEventListener('click', function (ev) {
      ev.preventDefault();
      note.classList.toggle('hide');
    });
  }
})();
