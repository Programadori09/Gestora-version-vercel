<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_login();

if (is_post()) {
    csrf_verify();
    $op = post('op');
    if ($op === 'dados') {
        $nome = post('nome');
        $email = post('email');
        if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Indica o nome e um email válido.');
        } elseif (fetch_val('SELECT id FROM utilizadores WHERE email = ? AND id <> ?', [$email, $user['id']])) {
            flash('error', 'Esse email já está a ser usado por outra conta.');
        } else {
            q('UPDATE utilizadores SET nome = ?, email = ? WHERE id = ?', [$nome, $email, $user['id']]);
            flash('success', 'Dados atualizados.');
        }
        redirect('perfil.php');
    }
    if ($op === 'senha') {
        $atual = (string) ($_POST['atual'] ?? '');
        $nova = (string) ($_POST['nova'] ?? '');
        $conf = (string) ($_POST['conf'] ?? '');
        $hash = (string) fetch_val('SELECT senha_hash FROM utilizadores WHERE id = ?', [$user['id']]);
        if (!password_verify($atual, $hash)) {
            flash('error', 'A palavra-passe atual está incorreta.');
        } elseif (strlen($nova) < 8) {
            flash('error', 'A nova palavra-passe deve ter pelo menos 8 caracteres.');
        } elseif ($nova !== $conf) {
            flash('error', 'A confirmação não coincide com a nova palavra-passe.');
        } else {
            q('UPDATE utilizadores SET senha_hash = ? WHERE id = ?', [password_hash($nova, PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            log_activity('senha_alterada', 'Palavra-passe alterada');
            flash('success', 'Palavra-passe alterada com sucesso.');
        }
        redirect('perfil.php');
    }
}

page_header('O meu perfil', '', ['subtitle' => 'Perfil: ' . ucfirst($user['perfil']) . ' · utilizador ' . $user['utilizador']]);
?>
<div class="grid g-2">
  <form class="card" method="post" data-once>
    <?= csrf_field() ?><input type="hidden" name="op" value="dados">
    <div class="card-head"><h2>Os meus dados</h2></div>
    <div class="form-grid">
      <div class="field col-12"><label for="nome">Nome</label><input type="text" id="nome" name="nome" value="<?= e($user['nome']) ?>" required maxlength="120"></div>
      <div class="field col-12"><label for="email">Email</label><input type="email" id="email" name="email" value="<?= e($user['email']) ?>" required maxlength="160"></div>
    </div>
    <div class="form-actions"><button class="btn btn-primary" type="submit">Guardar</button></div>
  </form>
  <form class="card" method="post" data-once autocomplete="off">
    <?= csrf_field() ?><input type="hidden" name="op" value="senha">
    <div class="card-head"><h2>Alterar palavra-passe</h2></div>
    <div class="form-grid">
      <div class="field col-12"><label for="atual">Palavra-passe atual</label><input type="password" id="atual" name="atual" required autocomplete="current-password"></div>
      <div class="field col-6"><label for="nova">Nova palavra-passe</label><input type="password" id="nova" name="nova" required minlength="8" autocomplete="new-password"></div>
      <div class="field col-6"><label for="conf">Confirmar</label><input type="password" id="conf" name="conf" required minlength="8" autocomplete="new-password"></div>
    </div>
    <div class="form-actions"><button class="btn btn-primary" type="submit">Alterar palavra-passe</button></div>
  </form>
</div>
<?php page_footer(); ?>
