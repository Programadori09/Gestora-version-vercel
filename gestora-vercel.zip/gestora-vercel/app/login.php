<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';
$loginValue = '';

if (is_post()) {
    csrf_verify();
    $loginValue = post('login');
    $senha = (string) ($_POST['senha'] ?? '');
    $adminMode = post('modo') === 'admin';

    if ($loginValue === '' || $senha === '') {
        $error = 'Indica o utilizador (ou email) e a palavra-passe.';
    } elseif (login_blocked()) {
        $error = 'Demasiadas tentativas falhadas. Aguarda alguns minutos e tenta novamente.';
    } elseif (!attempt_login($loginValue, $senha)) {
        $error = 'Utilizador ou palavra-passe incorretos.';
    } else {
        $u = current_user(true);
        if ($adminMode && $u && $u['perfil'] !== 'admin') {
            do_logout();
            gt_session_start();
            $error = 'Esta conta não tem acesso de administrador.';
        } else {
            if (post('lembrar') === '1') {
                $p = session_get_cookie_params();
                setcookie(session_name(), session_id(), [
                    'expires'  => time() + 60 * 60 * 24 * 30,
                    'path'     => $p['path'],
                    'secure'   => (bool) $p['secure'],
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]);
            }
            redirect('dashboard.php');
        }
    }
}
?>
<!doctype html>
<html lang="pt-PT" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Iniciar sessão · GesTora</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400;1,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css?v=<?= e(APP_VERSION) ?>">
</head>
<body class="login">
<div class="login-page">

  <section class="login-left" aria-label="Apresentação">
    <div class="login-brand">
      <?= logo_html(62, 'light') ?>
      <p class="login-tag"><?= e(APP_TAGLINE) ?></p>
    </div>

    <div class="login-features">
      <div class="lf"><?= icon('box', 44) ?><span>Gestão de<br>Stock</span></div>
      <div class="lf"><?= icon('cart', 44) ?><span>Controlo<br>de Vendas</span></div>
      <div class="lf"><?= icon('chart', 44) ?><span>Relatórios<br>em Tempo Real</span></div>
    </div>

    <div class="login-visual" aria-hidden="true"><img src="assets/img/laptop.jpg" alt=""></div>
  </section>

  <section class="login-right">
    <div class="login-slogan">Mais organização,<br>mais resultados</div>

    <div class="login-card">
      <h1>Bem-vindo de volta!</h1>
      <p class="lead">Inicie sessão para continuar a gerir o seu <br>negócio de forma simples e eficiente.</p>

      <?php if ($error): ?>
        <div class="login-error" role="alert"><?= icon('alert', 20) ?><span><?= e($error) ?></span></div>
      <?php endif; ?>

      <form method="post" action="login.php" autocomplete="on" novalidate data-once>
        <?= csrf_field() ?>
        <div class="lfield">
          <?= icon('user', 22) ?>
          <input type="text" name="login" id="login" placeholder="Utilizador ou Email" value="<?= e($loginValue) ?>"
                 autocomplete="username" autocapitalize="none" spellcheck="false" required autofocus aria-label="Utilizador ou Email">
        </div>
        <div class="lfield">
          <?= icon('lock', 22) ?>
          <input type="password" name="senha" id="senha" placeholder="Palavra-passe" autocomplete="current-password" required aria-label="Palavra-passe">
          <button type="button" class="toggle-pass" data-target="senha" aria-label="Mostrar palavra-passe">
            <span class="i-show"><?= icon('eye-off', 22) ?></span><span class="i-hide hide"><?= icon('eye', 22) ?></span>
          </button>
        </div>

        <div class="login-row">
          <label class="check"><input type="checkbox" name="lembrar" value="1"> Manter sessão iniciada</label>
          <a href="#" id="forgotLink">Esqueceu a palavra-passe?</a>
        </div>
        <div class="login-note hide" id="forgotNote" role="note">
          Para repor a palavra-passe, contacta o administrador do sistema. Ele pode definir uma nova em <b>Administração → Utilizadores</b>.
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-enter" name="modo" value="normal"><?= icon('arrow-right', 22) ?> Entrar</button>

        <div class="login-or">Ou</div>

        <button type="submit" class="btn btn-admin" name="modo" value="admin"><?= icon('shield', 22) ?> Acesso do Administrador</button>
      </form>

      <div class="login-foot">
        GesTora &nbsp;·&nbsp; Sistema de Gestão Empresarial<br>v<?= e(APP_VERSION) ?>
      </div>
    </div>
    <div class="login-deco" aria-hidden="true"></div>
  </section>

</div>
<script src="assets/js/app.js?v=<?= e(APP_VERSION) ?>"></script>
<script src="assets/js/login.js?v=<?= e(APP_VERSION) ?>"></script>
</body>
</html>
