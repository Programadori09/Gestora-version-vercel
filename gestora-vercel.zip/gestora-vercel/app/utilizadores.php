<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('utilizadores');
$acao = get('acao');
$perfis = ['admin' => 'Administrador', 'gestor' => 'Gestor', 'vendedor' => 'Vendedor'];

function active_admins(int $exceptId = 0): int
{
    return (int) fetch_val("SELECT COUNT(*) FROM utilizadores WHERE perfil = 'admin' AND ativo = 1 AND id <> ?", [$exceptId]);
}

if (is_post()) {
    csrf_verify();
    $op = post('op');
    if ($op === 'guardar') {
        $id = (int) post('id');
        $nome = post('nome');
        $email = post('email');
        $login = post('utilizador');
        $perfil = array_key_exists(post('perfil'), $perfis) ? post('perfil') : 'vendedor';
        $ativo = post('ativo') === '1' ? 1 : 0;
        $senha = (string) ($_POST['senha'] ?? '');
        $err = '';
        if ($nome === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $err = 'Indica o nome e um email válido.';
        } elseif (!preg_match('/^[A-Za-z0-9._-]{3,40}$/', $login)) {
            $err = 'O utilizador deve ter 3 a 40 caracteres (letras, números, ponto, hífen ou _).';
        } elseif (!$id && strlen($senha) < 8) {
            $err = 'A palavra-passe deve ter pelo menos 8 caracteres.';
        } elseif ($id && $senha !== '' && strlen($senha) < 8) {
            $err = 'A nova palavra-passe deve ter pelo menos 8 caracteres.';
        } elseif (fetch_val('SELECT id FROM utilizadores WHERE (utilizador = ? OR email = ?) AND id <> ?', [$login, $email, $id])) {
            $err = 'Já existe um utilizador com esse nome de utilizador ou email.';
        } elseif ($id && ($perfil !== 'admin' || !$ativo) && fetch_val("SELECT perfil FROM utilizadores WHERE id = ?", [$id]) === 'admin' && active_admins($id) === 0) {
            $err = 'Tem de existir pelo menos um administrador ativo.';
        } elseif ($id === (int) $user['id'] && !$ativo) {
            $err = 'Não podes desativar a tua própria conta.';
        }
        if ($err) {
            flash('error', $err);
            redirect($id ? 'utilizadores.php?acao=editar&id=' . $id : 'utilizadores.php?acao=novo');
        }
        if ($id) {
            q('UPDATE utilizadores SET nome=?, email=?, utilizador=?, perfil=?, ativo=? WHERE id=?', [$nome, $email, $login, $perfil, $ativo, $id]);
            if ($senha !== '') {
                q('UPDATE utilizadores SET senha_hash = ? WHERE id = ?', [password_hash($senha, PASSWORD_DEFAULT), $id]);
            }
            flash('success', 'Utilizador atualizado.');
        } else {
            q('INSERT INTO utilizadores (nome, email, utilizador, senha_hash, perfil, ativo) VALUES (?,?,?,?,?,?)', [$nome, $email, $login, password_hash($senha, PASSWORD_DEFAULT), $perfil, $ativo]);
            flash('success', 'Utilizador criado.');
        }
        log_activity('utilizador_guardado', $login . ' (' . $perfil . ')');
        redirect('utilizadores.php');
    }
    if ($op === 'eliminar') {
        $id = (int) post('id');
        $alvo = fetch_one('SELECT perfil, utilizador FROM utilizadores WHERE id = ?', [$id]);
        if (!$alvo) {
            flash('error', 'Utilizador não encontrado.');
        } elseif ($id === (int) $user['id']) {
            flash('error', 'Não podes eliminar a tua própria conta.');
        } elseif ($alvo['perfil'] === 'admin' && active_admins($id) === 0) {
            flash('error', 'Tem de existir pelo menos um administrador ativo.');
        } else {
            q('DELETE FROM utilizadores WHERE id = ?', [$id]);
            log_activity('utilizador_removido', $alvo['utilizador']);
            flash('success', 'Utilizador eliminado.');
        }
        redirect('utilizadores.php');
    }
}

if ($acao === 'novo' || $acao === 'editar') {
    $u = ['id' => 0, 'nome' => '', 'email' => '', 'utilizador' => '', 'perfil' => 'vendedor', 'ativo' => 1];
    if ($acao === 'editar') {
        $row = fetch_one('SELECT id, nome, email, utilizador, perfil, ativo FROM utilizadores WHERE id = ?', [(int) get('id')]);
        if (!$row) {
            redirect('utilizadores.php');
        }
        $u = $row;
    }
    page_header($u['id'] ? 'Editar utilizador' : 'Novo utilizador', 'utilizadores', ['actions' => '<a class="btn" href="utilizadores.php">Voltar</a>']);
    ?>
    <form class="card" method="post" data-once autocomplete="off">
      <?= csrf_field() ?><input type="hidden" name="op" value="guardar"><input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
      <div class="form-grid">
        <div class="field col-6"><label class="required" for="nome">Nome completo</label><input type="text" id="nome" name="nome" value="<?= e($u['nome']) ?>" required maxlength="120"></div>
        <div class="field col-6"><label class="required" for="email">Email</label><input type="email" id="email" name="email" value="<?= e($u['email']) ?>" required maxlength="160"></div>
        <div class="field col-4"><label class="required" for="utilizador">Utilizador</label><input type="text" id="utilizador" name="utilizador" value="<?= e($u['utilizador']) ?>" required maxlength="40" autocomplete="off"></div>
        <div class="field col-4"><label for="perfil">Perfil</label>
          <select id="perfil" name="perfil"><?php foreach ($perfis as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($u['perfil'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="field col-4"><label for="senha"><?= $u['id'] ? 'Nova palavra-passe (opcional)' : 'Palavra-passe' ?></label><input type="password" id="senha" name="senha" minlength="8" <?= $u['id'] ? '' : 'required' ?> autocomplete="new-password" placeholder="Mínimo 8 caracteres"></div>
        <div class="col-12"><label class="check"><input type="checkbox" name="ativo" value="1"<?= chk((int) $u['ativo'] === 1) ?>> Conta ativa</label></div>
        <div class="col-12"><div class="summary-box">
          <div class="stat-row"><span><b>Administrador</b></span><span>Acesso total, incluindo utilizadores e configurações.</span></div>
          <div class="stat-row"><span><b>Gestor</b></span><span>Vendas, stock, clientes, fornecedores, dropshipping, despesas, finanças e relatórios.</span></div>
          <div class="stat-row"><span><b>Vendedor</b></span><span>Painel, vendas, consulta de produtos e clientes.</span></div>
        </div></div>
      </div>
      <div class="form-actions"><a class="btn" href="utilizadores.php">Cancelar</a><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar</button></div>
    </form>
    <?php
    page_footer();
    exit;
}

$rows = fetch_all('SELECT id, nome, email, utilizador, perfil, ativo, ultimo_login FROM utilizadores ORDER BY nome');
page_header('Utilizadores', 'utilizadores', [
    'subtitle' => 'Quem pode entrar no sistema e o que pode fazer.',
    'actions' => '<a class="btn btn-primary" href="utilizadores.php?acao=novo">' . icon('plus', 18) . ' Novo utilizador</a>',
]);
?>
<div class="card">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Nome</th><th>Utilizador</th><th>Perfil</th><th>Último acesso</th><th>Estado</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><span class="cell-main"><?= e($r['nome']) ?></span><span class="cell-sub"><?= e($r['email']) ?></span></td>
        <td><?= e($r['utilizador']) ?></td>
        <td><?= badge($perfis[$r['perfil']], $r['perfil'] === 'admin' ? 'primary' : ($r['perfil'] === 'gestor' ? 'info' : 'neutral')) ?></td>
        <td class="nowrap"><?= e(fdatetime($r['ultimo_login'])) ?></td>
        <td><?= (int) $r['ativo'] ? badge('Ativo', 'success') : badge('Inativo', 'danger') ?></td>
        <td><div class="row-actions">
          <a class="btn btn-sm btn-icon" title="Editar" href="utilizadores.php?acao=editar&id=<?= (int) $r['id'] ?>"><?= icon('edit', 16) ?></a>
          <?php if ((int) $r['id'] !== (int) $user['id']): ?>
          <form class="inline-form" method="post" data-confirm="Eliminar este utilizador?"><?= csrf_field() ?><input type="hidden" name="op" value="eliminar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-icon btn-danger" title="Eliminar" type="submit"><?= icon('trash', 16) ?></button></form>
          <?php endif; ?>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php page_footer(); ?>
