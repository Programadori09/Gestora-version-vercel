<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';

// Base de dados ligada mas sem tabelas -> primeira utilização: vai para o instalador.
if (!gt_is_installed()) {
    redirect('install.php');
}

redirect(current_user() ? 'dashboard.php' : 'login.php');
