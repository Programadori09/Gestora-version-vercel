<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('utilizadores');

if (is_post()) {
    csrf_verify();
    $op = post('op');
    if ($op === 'empresa') {
        $iva = parse_decimal(post('iva_taxa'));
        $email = post('empresa_email');
        if ($iva < 0 || $iva > 100) {
            flash('error', 'A taxa de IVA deve estar entre 0 e 100.');
        } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'O email da empresa não é válido.');
        } elseif (post('empresa_nome') === '') {
            flash('error', 'O nome da empresa é obrigatório.');
        } else {
            set_setting('empresa_nome', post('empresa_nome'));
            set_setting('empresa_nif', post('empresa_nif'));
            set_setting('empresa_telefone', post('empresa_telefone'));
            set_setting('empresa_email', $email);
            set_setting('empresa_endereco', post('empresa_endereco'));
            set_setting('moeda', post('moeda') !== '' ? post('moeda') : 'Kz');
            set_setting('iva_taxa', (string) $iva);
            set_setting('precos_incluem_iva', post('precos_incluem_iva') === '1' ? '1' : '0');
            set_setting('rodape_fatura', post('rodape_fatura'));
            log_activity('configuracoes', 'Dados da empresa atualizados');
            flash('success', 'Configurações guardadas.');
        }
        redirect('configuracoes.php');
    }
}

$s = fn(string $k, string $d = '') => setting($k, $d);
page_header('Configurações', 'configuracoes', ['subtitle' => 'Dados da empresa, moeda, IVA e texto das faturas.']);
?>
<form class="card" method="post" data-once>
  <?= csrf_field() ?><input type="hidden" name="op" value="empresa">
  <div class="card-head"><h2>Empresa</h2></div>
  <div class="form-grid">
    <div class="field col-6"><label class="required" for="empresa_nome">Nome da empresa</label><input type="text" id="empresa_nome" name="empresa_nome" value="<?= e($s('empresa_nome')) ?>" required maxlength="140"></div>
    <div class="field col-3"><label for="empresa_nif">NIF</label><input type="text" id="empresa_nif" name="empresa_nif" value="<?= e($s('empresa_nif')) ?>" maxlength="30"></div>
    <div class="field col-3"><label for="empresa_telefone">Telefone</label><input type="tel" id="empresa_telefone" name="empresa_telefone" value="<?= e($s('empresa_telefone')) ?>" maxlength="40"></div>
    <div class="field col-6"><label for="empresa_email">Email</label><input type="email" id="empresa_email" name="empresa_email" value="<?= e($s('empresa_email')) ?>" maxlength="160"></div>
    <div class="field col-6"><label for="empresa_endereco">Morada</label><input type="text" id="empresa_endereco" name="empresa_endereco" value="<?= e($s('empresa_endereco')) ?>" maxlength="255"></div>
  </div>
  <div class="card-head" style="margin-top:26px"><h2>Faturação</h2></div>
  <div class="form-grid">
    <div class="field col-3"><label for="moeda">Moeda (símbolo)</label><input type="text" id="moeda" name="moeda" value="<?= e($s('moeda', 'Kz')) ?>" maxlength="8"></div>
    <div class="field col-3"><label for="iva_taxa">Taxa de IVA (%)</label><input type="text" inputmode="decimal" id="iva_taxa" name="iva_taxa" value="<?= e($s('iva_taxa', '0')) ?>"><span class="hint">Usa 0 se não cobras IVA.</span></div>
    <div class="col-6" style="display:flex;align-items:center"><label class="check"><input type="checkbox" name="precos_incluem_iva" value="1"<?= chk($s('precos_incluem_iva', '1') === '1') ?>> Os preços dos produtos já incluem IVA</label></div>
    <div class="field col-12"><label for="rodape_fatura">Mensagem no rodapé da fatura</label><input type="text" id="rodape_fatura" name="rodape_fatura" value="<?= e($s('rodape_fatura')) ?>" maxlength="200"></div>
  </div>
  <div class="form-actions"><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar configurações</button></div>
</form>
<?php page_footer(); ?>
