-- GesTora - O teu negócio, sob controlo
-- Esquema da base de dados (MySQL 5.7+ / MariaDB 10.3+)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS utilizadores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL,
  utilizador VARCHAR(60) NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  perfil ENUM('admin','gestor','vendedor') NOT NULL DEFAULT 'vendedor',
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  ultimo_login DATETIME NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_utilizador (utilizador),
  UNIQUE KEY uq_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS configuracoes (
  chave VARCHAR(60) PRIMARY KEY,
  valor TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categorias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(80) NOT NULL,
  UNIQUE KEY uq_cat_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fornecedores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  nif VARCHAR(30) NULL,
  telefone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  endereco VARCHAR(255) NULL,
  notas TEXT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_forn_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clientes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  nif VARCHAR(30) NULL,
  telefone VARCHAR(40) NULL,
  email VARCHAR(160) NULL,
  endereco VARCHAR(255) NULL,
  notas TEXT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_cli_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS produtos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(40) NULL,
  nome VARCHAR(160) NOT NULL,
  categoria_id INT UNSIGNED NULL,
  fornecedor_id INT UNSIGNED NULL,
  tipo ENUM('stock','dropshipping','servico') NOT NULL DEFAULT 'stock',
  preco_custo DECIMAL(14,2) NOT NULL DEFAULT 0,
  preco_venda DECIMAL(14,2) NOT NULL DEFAULT 0,
  stock_atual INT NOT NULL DEFAULT 0,
  stock_minimo INT NOT NULL DEFAULT 0,
  unidade VARCHAR(20) NOT NULL DEFAULT 'un',
  descricao TEXT NULL,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_prod_codigo (codigo),
  KEY idx_prod_nome (nome),
  CONSTRAINT fk_prod_cat FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL,
  CONSTRAINT fk_prod_forn FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS movimentos_stock (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produto_id INT UNSIGNED NOT NULL,
  tipo ENUM('entrada','saida','ajuste') NOT NULL,
  quantidade INT NOT NULL,
  stock_apos INT NOT NULL DEFAULT 0,
  motivo VARCHAR(160) NULL,
  referencia VARCHAR(60) NULL,
  utilizador_id INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_mov_prod (produto_id, criado_em),
  CONSTRAINT fk_mov_prod FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
  CONSTRAINT fk_mov_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vendas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero VARCHAR(30) NOT NULL,
  cliente_id INT UNSIGNED NULL,
  utilizador_id INT UNSIGNED NULL,
  data_venda DATE NOT NULL,
  canal ENUM('loja','online','outro') NOT NULL DEFAULT 'loja',
  metodo_pagamento VARCHAR(40) NOT NULL DEFAULT 'Numerário',
  subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
  desconto DECIMAL(14,2) NOT NULL DEFAULT 0,
  base_tributavel DECIMAL(14,2) NOT NULL DEFAULT 0,
  iva_taxa DECIMAL(5,2) NOT NULL DEFAULT 0,
  iva_valor DECIMAL(14,2) NOT NULL DEFAULT 0,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  valor_pago DECIMAL(14,2) NOT NULL DEFAULT 0,
  estado ENUM('emitida','anulada') NOT NULL DEFAULT 'emitida',
  notas TEXT NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_venda_numero (numero),
  KEY idx_venda_data (data_venda),
  CONSTRAINT fk_venda_cli FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
  CONSTRAINT fk_venda_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS venda_itens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  venda_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NULL,
  descricao VARCHAR(200) NOT NULL,
  quantidade DECIMAL(12,2) NOT NULL DEFAULT 1,
  preco_unitario DECIMAL(14,2) NOT NULL DEFAULT 0,
  custo_unitario DECIMAL(14,2) NOT NULL DEFAULT 0,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  movimenta_stock TINYINT(1) NOT NULL DEFAULT 0,
  KEY idx_item_venda (venda_id),
  KEY idx_item_prod (produto_id),
  CONSTRAINT fk_item_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
  CONSTRAINT fk_item_prod FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pagamentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  venda_id INT UNSIGNED NOT NULL,
  valor DECIMAL(14,2) NOT NULL,
  metodo VARCHAR(40) NOT NULL DEFAULT 'Numerário',
  data_pagamento DATE NOT NULL,
  utilizador_id INT UNSIGNED NULL,
  notas VARCHAR(200) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_pag_venda (venda_id),
  KEY idx_pag_data (data_pagamento),
  CONSTRAINT fk_pag_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
  CONSTRAINT fk_pag_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS encomendas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  referencia VARCHAR(30) NOT NULL,
  data_encomenda DATE NOT NULL,
  loja_origem VARCHAR(80) NULL,
  cliente_id INT UNSIGNED NULL,
  cliente_nome VARCHAR(140) NOT NULL,
  cliente_contacto VARCHAR(80) NULL,
  endereco_entrega VARCHAR(255) NULL,
  produto_id INT UNSIGNED NULL,
  produto_nome VARCHAR(200) NOT NULL,
  fornecedor_id INT UNSIGNED NULL,
  quantidade INT NOT NULL DEFAULT 1,
  preco_venda DECIMAL(14,2) NOT NULL DEFAULT 0,
  custo_fornecedor DECIMAL(14,2) NOT NULL DEFAULT 0,
  custo_envio DECIMAL(14,2) NOT NULL DEFAULT 0,
  taxas DECIMAL(14,2) NOT NULL DEFAULT 0,
  estado ENUM('nova','encomendada','enviada','entregue','cancelada','devolvida') NOT NULL DEFAULT 'nova',
  pagamento_cliente ENUM('pendente','pago','reembolsado') NOT NULL DEFAULT 'pendente',
  pagamento_fornecedor ENUM('pendente','pago') NOT NULL DEFAULT 'pendente',
  rastreio VARCHAR(80) NULL,
  notas TEXT NULL,
  utilizador_id INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_enc_ref (referencia),
  KEY idx_enc_data (data_encomenda),
  KEY idx_enc_estado (estado),
  CONSTRAINT fk_enc_cli FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
  CONSTRAINT fk_enc_prod FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL,
  CONSTRAINT fk_enc_forn FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL,
  CONSTRAINT fk_enc_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS despesas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  data_despesa DATE NOT NULL,
  descricao VARCHAR(200) NOT NULL,
  categoria VARCHAR(60) NOT NULL DEFAULT 'Outras',
  valor DECIMAL(14,2) NOT NULL,
  metodo VARCHAR(40) NOT NULL DEFAULT 'Numerário',
  fornecedor_id INT UNSIGNED NULL,
  notas TEXT NULL,
  utilizador_id INT UNSIGNED NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_desp_data (data_despesa),
  CONSTRAINT fk_desp_forn FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL,
  CONSTRAINT fk_desp_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS atividades (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  utilizador_id INT UNSIGNED NULL,
  acao VARCHAR(60) NOT NULL,
  detalhe VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ativ_data (criado_em),
  CONSTRAINT fk_ativ_user FOREIGN KEY (utilizador_id) REFERENCES utilizadores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessões (guardadas na base de dados porque a Vercel não tem disco persistente)
CREATE TABLE IF NOT EXISTS sessoes (
  id VARCHAR(128) NOT NULL PRIMARY KEY,
  dados MEDIUMBLOB NOT NULL,
  atualizado_em INT UNSIGNED NOT NULL,
  KEY idx_sess_data (atualizado_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT IGNORE INTO configuracoes (chave, valor) VALUES
  ('empresa_nome', 'A Minha Empresa'),
  ('empresa_nif', ''),
  ('empresa_telefone', ''),
  ('empresa_email', ''),
  ('empresa_endereco', ''),
  ('moeda', 'Kz'),
  ('iva_taxa', '14'),
  ('precos_incluem_iva', '1'),
  ('rodape_fatura', 'Obrigado pela preferência.');

INSERT IGNORE INTO categorias (nome) VALUES ('Geral'), ('Acessórios'), ('Eletrónicos'), ('Serviços');
