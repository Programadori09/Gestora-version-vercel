<?php
declare(strict_types=1);

/**
 * Dados de demonstração (opcionais) para experimentar a GesTora.
 * Chamada pelo instalador depois de a base de dados e a conta de admin existirem.
 */
function gt_seed_demo(): void
{
    mt_srand(2026);
    $pdo = db();

    // Fornecedores
    $forn = [
        ['TecnoAngola Importações', '5417002831', '923 100 200', 'vendas@tecnoangola.example', 'Rua da Missão, Luanda'],
        ['Global Gadgets Ltd', null, '+86 755 1234 5678', 'sales@globalgadgets.example', 'Shenzhen, China'],
        ['Vida Natural Suplementos', '5000118842', '934 220 118', 'comercial@vidanatural.example', 'Viana, Luanda'],
        ['Distribuidora Kandengue', '5417990044', '912 887 301', 'geral@kandengue.example', 'Cazenga, Luanda'],
    ];
    $fid = [];
    foreach ($forn as $f) {
        q('INSERT INTO fornecedores (nome, nif, telefone, email, endereco) VALUES (?,?,?,?,?)', $f);
        $fid[] = last_id();
    }

    // Clientes
    $cli = [
        ['Ana Beatriz Costa', '934 120 556', 'ana.costa@example.com', 'Talatona, Luanda'],
        ['Carlos Mendes', '923 445 018', 'carlos.mendes@example.com', 'Maianga, Luanda'],
        ['Mercearia Esperança, Lda', '912 300 777', 'geral@esperanca.example', 'Viana, Luanda'],
        ['Joana Fernandes', '945 667 120', null, 'Cacuaco, Luanda'],
        ['Pedro Quissanga', '927 004 391', 'pedro.q@example.com', 'Kilamba, Luanda'],
        ['Salão Beleza Real', '931 552 874', 'contacto@belezareal.example', 'Benfica, Luanda'],
        ['Miguel Tavares', '922 810 034', null, 'Futungo de Belas, Luanda'],
        ['Sofia Lourenço', '936 207 665', 'sofia.l@example.com', 'Alvalade, Luanda'],
    ];
    $cid = [];
    foreach ($cli as $c) {
        q('INSERT INTO clientes (nome, telefone, email, endereco) VALUES (?,?,?,?)', $c);
        $cid[] = last_id();
    }

    // Categorias
    $cat = [];
    foreach (fetch_all('SELECT id, nome FROM categorias') as $r) {
        $cat[$r['nome']] = (int) $r['id'];
    }
    foreach (['Relógios', 'Suplementos', 'Telemóveis'] as $n) {
        q('INSERT IGNORE INTO categorias (nome) VALUES (?)', [$n]);
        $cat[$n] = (int) fetch_val('SELECT id FROM categorias WHERE nome = ?', [$n]);
    }

    // Produtos: codigo, nome, categoria, fornecedor idx, tipo, custo, venda, stock, minimo
    $prod = [
        ['SMT-001', 'Smartphone Android 128GB', 'Telemóveis', 0, 'stock', 85000, 120000, 18, 5],
        ['SMT-002', 'iPhone usado 11 (64GB)', 'Telemóveis', 0, 'stock', 150000, 210000, 6, 3],
        ['ACE-010', 'Fones de ouvido Bluetooth', 'Acessórios', 1, 'stock', 6500, 14500, 42, 10],
        ['ACE-011', 'Carregador rápido 20W', 'Acessórios', 1, 'stock', 2800, 7500, 60, 15],
        ['ACE-012', 'Capa de telemóvel (genérica)', 'Acessórios', 1, 'stock', 900, 3500, 120, 25],
        ['ACE-013', 'Cabo USB-C 1m', 'Acessórios', 1, 'stock', 700, 2500, 8, 20],
        ['REL-001', 'Relógio desportivo digital', 'Relógios', 1, 'stock', 9000, 22000, 14, 5],
        ['REL-002', 'Relógio clássico aço inox', 'Relógios', 1, 'stock', 18000, 39000, 4, 5],
        ['SUP-001', 'Multivitamínico natural (60 cáps.)', 'Suplementos', 2, 'stock', 6000, 13500, 30, 8],
        ['SUP-002', 'Ómega 3 (90 cáps.)', 'Suplementos', 2, 'stock', 8500, 18000, 22, 8],
        ['DRP-001', 'Smartwatch fitness (dropshipping)', 'Relógios', 1, 'dropshipping', 12000, 29000, 0, 0],
        ['DRP-002', 'Coluna Bluetooth portátil (dropshipping)', 'Acessórios', 1, 'dropshipping', 7500, 18500, 0, 0],
        ['SRV-001', 'Configuração de telemóvel', 'Serviços', null, 'servico', 0, 5000, 0, 0],
    ];
    $pid = [];
    foreach ($prod as $p) {
        q('INSERT INTO produtos (codigo, nome, categoria_id, fornecedor_id, tipo, preco_custo, preco_venda, stock_atual, stock_minimo) VALUES (?,?,?,?,?,?,?,0,?)', [
            $p[0], $p[1], $cat[$p[2]] ?? null, $p[3] === null ? null : $fid[$p[3]], $p[4], $p[5], $p[6], $p[8],
        ]);
        $id = last_id();
        $pid[$p[0]] = $id;
        if ($p[4] === 'stock' && $p[7] > 0) {
            // Stock inicial acima do necessário; as vendas vão baixando
            stock_move($id, 'entrada', $p[7] + 25, 'Stock inicial', null);
        }
    }

    // Vendas dos últimos 30 dias
    $stockCodes = array_filter(array_keys($pid), static fn($c) => !str_starts_with($c, 'DRP') && !str_starts_with($c, 'SRV'));
    $metodos = PAYMENT_METHODS;
    for ($i = 0; $i < 42; $i++) {
        $daysAgo = mt_rand(0, 29);
        $date = date('Y-m-d', strtotime("-{$daysAgo} days"));
        $items = [];
        $n = mt_rand(1, 3);
        $picked = array_rand(array_flip($stockCodes), $n);
        foreach ((array) $picked as $code) {
            $row = fetch_one('SELECT id, nome, preco_venda FROM produtos WHERE id = ?', [$pid[$code]]);
            $items[] = ['produto_id' => (int) $row['id'], 'descricao' => $row['nome'], 'quantidade' => mt_rand(1, 2), 'preco' => (float) $row['preco_venda']];
        }
        if (mt_rand(1, 6) === 1) {
            $items[] = ['produto_id' => $pid['SRV-001'], 'descricao' => 'Configuração de telemóvel', 'quantidade' => 1, 'preco' => 5000.0];
        }
        $sub = 0.0;
        foreach ($items as $it) {
            $sub += $it['quantidade'] * $it['preco'];
        }
        $r = mt_rand(1, 10);
        $pago = $r <= 7 ? $sub : ($r <= 9 ? round($sub * 0.5, 2) : 0.0);
        try {
            create_sale([
                'cliente_id' => mt_rand(1, 3) === 1 ? 0 : $cid[array_rand($cid)],
                'data_venda' => $date,
                'canal' => ['loja', 'online', 'loja'][mt_rand(0, 2)],
                'metodo_pagamento' => $metodos[mt_rand(0, 3)],
                'desconto' => mt_rand(1, 8) === 1 ? 1000 : 0,
                'pago' => $pago,
            ], $items);
        } catch (Throwable $e) {
            // ignora vendas de demonstração que falhem por stock
        }
    }

    // Encomendas de dropshipping
    $enc = [
        ['Loja Online Instagram', 'Helena Domingos', '931 004 220', 'Camama, Luanda', 'DRP-001', 1, 'entregue', 'pago', 'pago', 'LD2026001', 2, 1500, 500],
        ['Loja Online Instagram', 'Rui Pascoal', '925 330 118', 'Viana, Luanda', 'DRP-002', 2, 'entregue', 'pago', 'pago', 'LD2026002', 6, 3000, 900],
        ['Loja Online Facebook', 'Teresa Gaspar', '944 120 007', 'Benguela', 'DRP-001', 1, 'enviada', 'pago', 'pago', 'LD2026003', 1, 1500, 500],
        ['Loja Online Instagram', 'Edson Lima', '917 889 330', 'Lubango', 'DRP-002', 1, 'encomendada', 'pago', 'pendente', null, 1, 1500, 450],
        ['Loja Online Facebook', 'Nádia Cabral', '938 770 010', 'Talatona, Luanda', 'DRP-001', 1, 'nova', 'pendente', 'pendente', null, 0, 1500, 0],
        ['Loja Online Instagram', 'Bruno Samuel', '921 330 459', 'Cazenga, Luanda', 'DRP-002', 1, 'devolvida', 'reembolsado', 'pago', 'LD2026004', 14, 3000, 0],
    ];
    foreach ($enc as $e) {
        $prodRow = fetch_one('SELECT id, nome, fornecedor_id, preco_custo, preco_venda FROM produtos WHERE codigo = ?', [$e[4]]);
        $ref = next_number('ENC', 'encomendas', 'referencia');
        q('INSERT INTO encomendas (referencia, data_encomenda, loja_origem, cliente_nome, cliente_contacto, endereco_entrega, produto_id, produto_nome, fornecedor_id, quantidade, preco_venda, custo_fornecedor, custo_envio, taxas, estado, pagamento_cliente, pagamento_fornecedor, rastreio)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
            $ref, date('Y-m-d', strtotime('-' . $e[10] . ' days')), $e[0], $e[1], $e[2], $e[3], $prodRow['id'], $prodRow['nome'], $prodRow['fornecedor_id'],
            $e[5], $prodRow['preco_venda'], $prodRow['preco_custo'], $e[11], $e[12], $e[6], $e[7], $e[8], $e[9],
        ]);
    }

    // Despesas
    $desp = [
        ['Renda da loja', 'Renda', 120000, 28], ['Salário de funcionário', 'Salários', 85000, 27], ['Internet e eletricidade', 'Água, luz e internet', 24500, 20],
        ['Transporte de mercadoria', 'Transporte', 12000, 16], ['Anúncios Instagram/Facebook', 'Marketing', 30000, 14], ['Embalagens e sacos', 'Outras', 6500, 11],
        ['Manutenção do ar condicionado', 'Manutenção', 15000, 9], ['Compra de impressora de recibos', 'Equipamento', 38000, 7], ['Anúncios Instagram/Facebook', 'Marketing', 20000, 3],
    ];
    foreach ($desp as $d) {
        q('INSERT INTO despesas (data_despesa, descricao, categoria, valor, metodo, utilizador_id) VALUES (?,?,?,?,?,?)', [
            date('Y-m-d', strtotime('-' . $d[3] . ' days')), $d[0], $d[1], $d[2], $d[1] === 'Renda' ? 'Transferência' : 'Numerário', $_SESSION['uid'] ?? null,
        ]);
    }

    set_setting('empresa_telefone', '923 000 000');
    set_setting('empresa_endereco', 'Luanda, Angola');
}
