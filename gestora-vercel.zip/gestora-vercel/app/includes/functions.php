<?php
declare(strict_types=1);

/* ---------- Saída segura e formatação ---------- */

function e($v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function setting(string $key, string $default = ''): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (fetch_all('SELECT chave, valor FROM configuracoes') as $r) {
                $cache[$r['chave']] = (string) $r['valor'];
            }
        } catch (Throwable $e) {
            $cache = [];
        }
    }
    return $cache[$key] ?? $default;
}

function set_setting(string $key, string $value): void
{
    q('INSERT INTO configuracoes (chave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)', [$key, $value]);
}

function money($v, bool $symbol = true): string
{
    $v = (float) $v;
    $dec = abs($v - round($v)) < 0.005 ? 0 : 2;
    $s = number_format($v, $dec, ',', '.');
    return $symbol ? $s . ' ' . setting('moeda', 'Kz') : $s;
}

function num($v, int $dec = 0): string
{
    return number_format((float) $v, $dec, ',', '.');
}

function fdate(?string $d): string
{
    if (!$d) {
        return '—';
    }
    $t = strtotime($d);
    return $t ? date('d/m/Y', $t) : '—';
}

function fdatetime(?string $d): string
{
    if (!$d) {
        return '—';
    }
    $t = strtotime($d);
    return $t ? date('d/m/Y H:i', $t) : '—';
}

/** Converte "1.234,56" ou "1234.56" em float. */
function parse_decimal($s): float
{
    $s = trim((string) $s);
    if ($s === '') {
        return 0.0;
    }
    $s = str_replace(["\xc2\xa0", ' '], '', $s);
    if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
        $s = str_replace('.', '', $s);
        $s = str_replace(',', '.', $s);
    } elseif (strpos($s, ',') !== false) {
        $s = str_replace(',', '.', $s);
    }
    return is_numeric($s) ? (float) $s : 0.0;
}

function valid_date(string $d): bool
{
    $dt = DateTime::createFromFormat('Y-m-d', $d);
    return $dt && $dt->format('Y-m-d') === $d;
}

/* ---------- Pedido / resposta ---------- */

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function post(string $key, string $default = ''): string
{
    $v = $_POST[$key] ?? $default;
    return is_array($v) ? $default : trim((string) $v);
}

function get(string $key, string $default = ''): string
{
    $v = $_GET[$key] ?? $default;
    return is_array($v) ? $default : trim((string) $v);
}

/** true se o pedido chegou por HTTPS (a Vercel termina o TLS e envia X-Forwarded-Proto). */
function is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

/**
 * IP do cliente. Só confia nos cabeçalhos de proxy quando corre na Vercel (que os define de forma fiável);
 * fora dela usa REMOTE_ADDR para que ninguém consiga falsificar o IP e contornar o limite de tentativas de login.
 */
function client_ip(): string
{
    if (env_val('VERCEL') !== null) {
        foreach (['HTTP_X_VERCEL_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR'] as $h) {
            $v = trim((string) ($_SERVER[$h] ?? ''));
            if ($v !== '') {
                $ip = trim(explode(',', $v)[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
    }
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/** Constrói uma query string a partir do pedido actual, com substituições. */
function qs(array $override = []): string
{
    $p = array_merge($_GET, $override);
    foreach ($p as $k => $v) {
        if ($v === null || $v === '') {
            unset($p[$k]);
        }
    }
    return $p ? '?' . http_build_query($p) : '';
}

function opt_null($v): ?int
{
    $v = (int) $v;
    return $v > 0 ? $v : null;
}

function str_or_null(string $s): ?string
{
    return $s === '' ? null : $s;
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void
{
    $sent = (string) ($_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if (!hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('Sessão expirada ou pedido inválido. Volta atrás, atualiza a página e tenta novamente.');
    }
}

/* ---------- Mensagens flash ---------- */

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['t' => $type, 'm' => $msg];
}

function flash_render(): string
{
    if (empty($_SESSION['flash'])) {
        return '';
    }
    $out = '<div class="flashes">';
    foreach ($_SESSION['flash'] as $f) {
        $cls = in_array($f['t'], ['success', 'error', 'warning', 'info'], true) ? $f['t'] : 'info';
        $ic = $cls === 'success' ? 'check' : ($cls === 'error' ? 'alert' : 'info');
        $out .= '<div class="flash flash-' . $cls . '" role="status">' . icon($ic, 18) . '<span>' . e($f['m']) . '</span>'
              . '<button type="button" class="flash-x" aria-label="Fechar">' . icon('x', 16) . '</button></div>';
    }
    unset($_SESSION['flash']);
    return $out . '</div>';
}

/* ---------- Paginação ---------- */

function paginate(int $total, int $perPage = 15): array
{
    $pages = max(1, (int) ceil($total / $perPage));
    $page = max(1, min($pages, (int) get('p', '1')));
    return ['page' => $page, 'pages' => $pages, 'per' => $perPage, 'offset' => ($page - 1) * $perPage, 'total' => $total];
}

function pagination_html(array $pg): string
{
    if ($pg['pages'] <= 1) {
        return '<div class="pager"><span class="muted">' . num($pg['total']) . ' registo(s)</span></div>';
    }
    $out = '<div class="pager"><span class="muted">' . num($pg['total']) . ' registo(s)</span><div class="pager-links">';
    $link = function (int $p, string $label, bool $active = false, bool $disabled = false) {
        if ($disabled) {
            return '<span class="pg disabled">' . $label . '</span>';
        }
        return '<a class="pg' . ($active ? ' active' : '') . '" href="' . e(qs(['p' => $p])) . '">' . $label . '</a>';
    };
    $out .= $link($pg['page'] - 1, '&lsaquo;', false, $pg['page'] <= 1);
    $start = max(1, $pg['page'] - 2);
    $end = min($pg['pages'], $pg['page'] + 2);
    if ($start > 1) {
        $out .= $link(1, '1') . ($start > 2 ? '<span class="pg disabled">…</span>' : '');
    }
    for ($i = $start; $i <= $end; $i++) {
        $out .= $link($i, (string) $i, $i === $pg['page']);
    }
    if ($end < $pg['pages']) {
        $out .= ($end < $pg['pages'] - 1 ? '<span class="pg disabled">…</span>' : '') . $link($pg['pages'], (string) $pg['pages']);
    }
    $out .= $link($pg['page'] + 1, '&rsaquo;', false, $pg['page'] >= $pg['pages']);
    return $out . '</div></div>';
}

/* ---------- Pequenos utilitários de UI ---------- */

function sel($a, $b): string
{
    return (string) $a === (string) $b ? ' selected' : '';
}

function chk($cond): string
{
    return $cond ? ' checked' : '';
}

function badge(string $text, string $cls = 'neutral'): string
{
    return '<span class="badge badge-' . e($cls) . '">' . e($text) . '</span>';
}

function empty_state(string $msg, string $ic = 'box'): string
{
    return '<div class="empty">' . icon($ic, 36) . '<p>' . e($msg) . '</p></div>';
}

function log_activity(string $acao, string $detalhe = ''): void
{
    try {
        $uid = $_SESSION['uid'] ?? null;
        q('INSERT INTO atividades (utilizador_id, acao, detalhe, ip) VALUES (?, ?, ?, ?)', [
            $uid, $acao, mb_substr($detalhe, 0, 250), client_ip() ?: null,
        ]);
    } catch (Throwable $e) {
        // O registo de atividade nunca deve impedir a operação principal.
    }
}

/** Gera o próximo número sequencial por ano, ex.: "FT 2026/0001". */
function next_number(string $prefix, string $table, string $column): string
{
    $year = date('Y');
    $like = $prefix . ' ' . $year . '/%';
    $max = fetch_val("SELECT MAX(CAST(SUBSTRING_INDEX($column, '/', -1) AS UNSIGNED)) FROM $table WHERE $column LIKE ?", [$like]);
    return sprintf('%s %s/%04d', $prefix, $year, ((int) $max) + 1);
}

const PAYMENT_METHODS = ['Numerário', 'Transferência', 'Multicaixa / TPA', 'Referência', 'Carteira móvel', 'Outro'];
const EXPENSE_CATEGORIES = ['Renda', 'Salários', 'Transporte', 'Marketing', 'Fornecedores', 'Água, luz e internet', 'Impostos e taxas', 'Equipamento', 'Manutenção', 'Outras'];

function recompute_sale_payment(int $vendaId): void
{
    $paid = (float) fetch_val('SELECT COALESCE(SUM(valor),0) FROM pagamentos WHERE venda_id = ?', [$vendaId]);
    q('UPDATE vendas SET valor_pago = ? WHERE id = ?', [$paid, $vendaId]);
}

function sale_payment_state(array $v): array
{
    if (($v['estado'] ?? '') === 'anulada') {
        return ['Anulada', 'danger'];
    }
    $total = (float) $v['total'];
    $paid = (float) $v['valor_pago'];
    if ($total <= 0.004 || $paid + 0.004 >= $total) {
        return ['Paga', 'success'];
    }
    if ($paid > 0.004) {
        return ['Parcial', 'warning'];
    }
    return ['Pendente', 'warning'];
}

/** Aplica um movimento de stock e atualiza o produto (deve correr dentro de transação). */
function stock_move(int $produtoId, string $tipo, int $qtd, string $motivo, ?string $ref = null): void
{
    $row = fetch_one('SELECT stock_atual FROM produtos WHERE id = ? FOR UPDATE', [$produtoId]);
    if (!$row) {
        return;
    }
    $atual = (int) $row['stock_atual'];
    if ($tipo === 'entrada') {
        $novo = $atual + $qtd;
    } elseif ($tipo === 'saida') {
        $novo = $atual - $qtd;
    } else { // ajuste: $qtd é o novo valor absoluto
        $novo = $qtd;
        $qtd = $novo - $atual;
    }
    q('UPDATE produtos SET stock_atual = ? WHERE id = ?', [$novo, $produtoId]);
    q('INSERT INTO movimentos_stock (produto_id, tipo, quantidade, stock_apos, motivo, referencia, utilizador_id) VALUES (?,?,?,?,?,?,?)', [
        $produtoId, $tipo, $qtd, $novo, $motivo, $ref, $_SESSION['uid'] ?? null,
    ]);
}

/** Lucro de uma encomenda dropshipping. */
function order_profit(array $o): float
{
    return ((float) $o['preco_venda'] - (float) $o['custo_fornecedor']) * (int) $o['quantidade']
        - (float) $o['custo_envio'] - (float) $o['taxas'];
}

function order_state_badge(string $estado): string
{
    $map = [
        'nova' => ['Nova', 'info'], 'encomendada' => ['Encomendada ao fornecedor', 'warning'],
        'enviada' => ['Enviada', 'primary'], 'entregue' => ['Entregue', 'success'],
        'cancelada' => ['Cancelada', 'danger'], 'devolvida' => ['Devolvida', 'danger'],
    ];
    [$t, $c] = $map[$estado] ?? [$estado, 'neutral'];
    return badge($t, $c);
}
