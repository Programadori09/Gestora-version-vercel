<?php
declare(strict_types=1);

/**
 * Sessões, autenticação e permissões por perfil.
 */
function gt_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('gestora_sid');
    // Sessões na base de dados (a Vercel não tem disco persistente).
    ini_set('session.gc_maxlifetime', (string) GtSessionHandler::LIFETIME);
    ini_set('session.use_strict_mode', '1');
    session_set_save_handler(new GtSessionHandler(), true);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function current_user(bool $refresh = false): ?array
{
    static $user = false;
    if ($refresh) {
        $user = false;
    }
    if ($user !== false) {
        return $user;
    }
    $user = null;
    if (!empty($_SESSION['uid'])) {
        $row = fetch_one('SELECT id, nome, email, utilizador, perfil, ativo FROM utilizadores WHERE id = ?', [(int) $_SESSION['uid']]);
        if ($row && (int) $row['ativo'] === 1) {
            $user = $row;
        } else {
            unset($_SESSION['uid']);
        }
    }
    return $user;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        redirect('login.php');
    }
    return $u;
}

/** Permissões: admin = tudo; gestor = tudo menos administração; vendedor = operação de vendas. */
function role_can(string $perfil, string $area): bool
{
    $map = [
        'admin'    => ['*'],
        'gestor'   => ['dashboard', 'financeiro', 'produtos', 'produtos_edit', 'clientes', 'fornecedores', 'vendas', 'encomendas', 'despesas', 'relatorios', 'pesquisa'],
        'vendedor' => ['dashboard', 'produtos', 'clientes', 'vendas', 'pesquisa'],
    ];
    $allowed = $map[$perfil] ?? [];
    return in_array('*', $allowed, true) || in_array($area, $allowed, true);
}

function can(string $area): bool
{
    $u = current_user();
    return $u ? role_can($u['perfil'], $area) : false;
}

function require_area(string $area): array
{
    $u = require_login();
    if (!role_can($u['perfil'], $area)) {
        http_response_code(403);
        page_header('Acesso negado', '');
        echo '<div class="card empty">' . icon('lock', 40) . '<h2>Acesso negado</h2><p>O teu perfil não tem permissão para aceder a esta área.</p>'
           . '<a class="btn btn-primary" href="dashboard.php">Voltar ao painel</a></div>';
        page_footer();
        exit;
    }
    return $u;
}

function login_blocked(): bool
{
    $ip = client_ip();
    $n = (int) fetch_val(
        "SELECT COUNT(*) FROM atividades WHERE acao = 'login_falhou' AND ip = ? AND criado_em > (NOW() - INTERVAL 15 MINUTE)",
        [$ip]
    );
    return $n >= 8;
}

function attempt_login(string $login, string $senha): bool
{
    $u = fetch_one('SELECT * FROM utilizadores WHERE (utilizador = ? OR email = ?) LIMIT 1', [$login, $login]);
    // Compara sempre um hash para não revelar se o utilizador existe pelo tempo de resposta.
    $hash = $u['senha_hash'] ?? '$2y$10$usesomesillystringforsaleeOZlXq7nVj1o2yZq8e9p4xH5tqWw1y6';
    $ok = password_verify($senha, $hash);
    if ($u && $ok && (int) $u['ativo'] === 1) {
        session_regenerate_id(true);
        $_SESSION['uid'] = (int) $u['id'];
        q('UPDATE utilizadores SET ultimo_login = NOW() WHERE id = ?', [$u['id']]);
        if (password_needs_rehash($u['senha_hash'], PASSWORD_DEFAULT)) {
            q('UPDATE utilizadores SET senha_hash = ? WHERE id = ?', [password_hash($senha, PASSWORD_DEFAULT), $u['id']]);
        }
        log_activity('login', 'Sessão iniciada');
        return true;
    }
    log_activity('login_falhou', 'Tentativa para: ' . mb_substr($login, 0, 60));
    return false;
}

function do_logout(): void
{
    log_activity('logout', 'Sessão terminada');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool) $p['secure'], true);
    }
    session_destroy();
}
