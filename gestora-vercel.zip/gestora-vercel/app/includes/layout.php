<?php
declare(strict_types=1);

/**
 * Estrutura comum das páginas (barra lateral, topo, rodapé).
 */
function gt_menu(): array
{
    return [
        ['dashboard.php', 'Painel', 'home', 'dashboard', 'dashboard'],
        ['vendas.php', 'Vendas e faturas', 'cart', 'vendas', 'vendas'],
        ['produtos.php', 'Produtos e stock', 'box', 'produtos', 'produtos'],
        ['clientes.php', 'Clientes', 'users', 'clientes', 'clientes'],
        ['fornecedores.php', 'Fornecedores', 'truck', 'fornecedores', 'fornecedores'],
        ['encomendas.php', 'Dropshipping', 'cube', 'encomendas', 'encomendas'],
        ['despesas.php', 'Despesas', 'wallet', 'despesas', 'despesas'],
        ['financas.php', 'Finanças', 'dollar', 'financeiro', 'financas'],
        ['relatorios.php', 'Relatórios', 'chart', 'relatorios', 'relatorios'],
    ];
}

function page_header(string $title, string $active = '', array $opts = []): void
{
    $user = current_user();
    $company = setting('empresa_nome', APP_NAME);
    $bodyClass = $opts['bodyClass'] ?? '';
    $GLOBALS['gt_bare'] = !($user && empty($opts['bare']));
    ?>
<!doctype html>
<html lang="pt-PT" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title) ?> · <?= e(APP_NAME) ?></title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;0,800;1,500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css?v=<?= e(APP_VERSION) ?>">
<script>try{var t=localStorage.getItem('gt-theme');if(t==='light'||t==='dark'){document.documentElement.setAttribute('data-theme',t);}}catch(e){}</script>
</head>
<body class="app <?= e($bodyClass) ?>">
<?php if ($user && empty($opts['bare'])) { ?>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a class="side-logo" href="dashboard.php" aria-label="GesTora - Painel"><?= logo_html(30) ?></a>
    <nav class="side-nav" aria-label="Menu principal">
      <?php foreach (gt_menu() as [$href, $label, $ic, $area, $key]):
          if (!role_can($user['perfil'], $area)) { continue; } ?>
        <a class="nav-item<?= $active === $key ? ' active' : '' ?>" href="<?= e($href) ?>">
          <?= icon($ic, 20) ?><span><?= e($label) ?></span><?= $active === $key ? icon('chevron-right', 16, 'nav-arrow') : '' ?>
        </a>
      <?php endforeach; ?>
      <?php if (role_can($user['perfil'], 'utilizadores')): ?>
        <div class="nav-sep">Administração</div>
        <a class="nav-item<?= $active === 'utilizadores' ? ' active' : '' ?>" href="utilizadores.php"><?= icon('shield', 20) ?><span>Utilizadores</span></a>
        <a class="nav-item<?= $active === 'configuracoes' ? ' active' : '' ?>" href="configuracoes.php"><?= icon('sliders', 20) ?><span>Configurações</span></a>
      <?php endif; ?>
    </nav>
    <div class="side-foot">
      <div class="side-company"><?= icon('building', 16) ?><span><?= e($company) ?></span></div>
      <small>GesTora v<?= e(APP_VERSION) ?></small>
    </div>
  </aside>
  <div class="scrim" id="scrim"></div>
  <div class="main-col">
    <header class="topbar">
      <button class="icon-btn menu-btn" type="button" id="menuBtn" aria-label="Abrir menu"><?= icon('menu', 22) ?></button>
      <form class="search" action="pesquisa.php" method="get" role="search">
        <?= icon('search', 18) ?>
        <input type="search" name="q" placeholder="Pesquisar produto, cliente ou documento…" value="<?= e(get('q')) ?>" aria-label="Pesquisar">
      </form>
      <div class="top-actions">
        <?php
        $lowCount = 0; $low = [];
        if (role_can($user['perfil'], 'produtos')) {
            $lowCount = (int) fetch_val("SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND tipo = 'stock' AND stock_atual <= stock_minimo");
            if ($lowCount) {
                $low = fetch_all("SELECT id, nome, stock_atual, stock_minimo FROM produtos WHERE ativo = 1 AND tipo = 'stock' AND stock_atual <= stock_minimo ORDER BY stock_atual ASC, nome LIMIT 6");
            }
        }
        ?>
        <div class="dropdown">
          <button class="icon-btn" type="button" data-dropdown aria-label="Notificações" aria-haspopup="true">
            <?= icon('bell', 20) ?><?php if ($lowCount): ?><span class="dot"></span><?php endif; ?>
          </button>
          <div class="dropdown-menu notif">
            <div class="dd-title">Notificações</div>
            <?php if (!$lowCount): ?>
              <div class="dd-empty">Sem alertas de momento. Tudo em ordem.</div>
            <?php else: ?>
              <div class="dd-sub"><?= num($lowCount) ?> produto(s) com stock baixo</div>
              <?php foreach ($low as $p): ?>
                <a class="dd-item" href="produtos.php?acao=editar&id=<?= (int) $p['id'] ?>">
                  <?= icon('alert', 16) ?><span><?= e($p['nome']) ?></span><b><?= num($p['stock_atual']) ?>/<?= num($p['stock_minimo']) ?></b>
                </a>
              <?php endforeach; ?>
              <a class="dd-more" href="produtos.php?filtro=baixo">Ver todos</a>
            <?php endif; ?>
          </div>
        </div>
        <button class="icon-btn" type="button" id="themeBtn" aria-label="Alternar tema claro/escuro">
          <span class="th-moon"><?= icon('moon', 20) ?></span><span class="th-sun"><?= icon('sun', 20) ?></span>
        </button>
        <div class="dropdown">
          <button class="user-chip" type="button" data-dropdown aria-haspopup="true">
            <span class="avatar"><?= e(mb_strtoupper(mb_substr($user['nome'], 0, 1))) ?></span>
            <span class="u-name"><?= e(explode(' ', $user['nome'])[0]) ?><small><?= e(ucfirst($user['perfil'])) ?></small></span>
            <?= icon('chevron-down', 16) ?>
          </button>
          <div class="dropdown-menu">
            <div class="dd-title"><?= e($user['nome']) ?><small><?= e($user['email']) ?></small></div>
            <a class="dd-item" href="perfil.php"><?= icon('user', 16) ?><span>O meu perfil</span></a>
            <a class="dd-item" href="logout.php"><?= icon('logout', 16) ?><span>Terminar sessão</span></a>
          </div>
        </div>
      </div>
    </header>
    <main class="content" id="main">
      <div class="page-head">
        <div>
          <h1><?= e($title) ?></h1>
          <?php if (!empty($opts['subtitle'])): ?><p class="muted"><?= e($opts['subtitle']) ?></p><?php endif; ?>
        </div>
        <?php if (!empty($opts['actions'])): ?><div class="page-actions"><?= $opts['actions'] ?></div><?php endif; ?>
      </div>
      <?= flash_render() ?>
<?php
    } else {
        // Página sem estrutura (ex.: fatura para impressão)
        echo '<main class="bare-content">' . flash_render();
    }
}

function page_footer(array $scripts = []): void
{
    ?>
    </main>
<?php if (empty($GLOBALS['gt_bare'])): ?>
  </div><!-- /main-col -->
</div><!-- /shell -->
<?php endif; ?>
<script src="assets/js/app.js?v=<?= e(APP_VERSION) ?>"></script>
<?php foreach ($scripts as $s): ?>
<script src="<?= e($s) ?>?v=<?= e(APP_VERSION) ?>"></script>
<?php endforeach; ?>
</body>
</html>
<?php
}
