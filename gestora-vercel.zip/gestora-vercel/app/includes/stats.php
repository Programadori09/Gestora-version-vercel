<?php
declare(strict_types=1);

/**
 * Indicadores usados no painel, finanças e relatórios.
 * Convenções:
 *  - Vendas contam apenas faturas "emitidas" (as anuladas ficam de fora).
 *  - Lucro de vendas = base tributável (sem IVA, após desconto) - custo das mercadorias.
 *  - Dropshipping (lucro) conta encomendas que não estão canceladas nem devolvidas.
 *  - Caixa (entradas/saídas) só conta dinheiro efetivamente pago.
 */

const DROP_ACTIVE = "estado NOT IN ('cancelada','devolvida') AND pagamento_cliente <> 'reembolsado'";

function period_range(string $kind): array
{
    $today = date('Y-m-d');
    switch ($kind) {
        case 'hoje':
            return [$today, $today];
        case 'ontem':
            $y = date('Y-m-d', strtotime('-1 day'));
            return [$y, $y];
        case 'mes':
            return [date('Y-m-01'), $today];
        case 'mes_ant':
            return [date('Y-m-01', strtotime('first day of last month')), date('Y-m-t', strtotime('first day of last month'))];
        case 'ano':
            return [date('Y-01-01'), $today];
        default:
            return [$today, $today];
    }
}

function sales_summary(string $from, string $to): array
{
    $r = fetch_one(
        "SELECT COUNT(*) n, COALESCE(SUM(total),0) total, COALESCE(SUM(base_tributavel),0) base,
                COALESCE(SUM(iva_valor),0) iva, COALESCE(SUM(desconto),0) desconto
         FROM vendas WHERE estado = 'emitida' AND data_venda BETWEEN ? AND ?",
        [$from, $to]
    ) ?? ['n' => 0, 'total' => 0, 'base' => 0, 'iva' => 0, 'desconto' => 0];
    $cogs = (float) fetch_val(
        "SELECT COALESCE(SUM(vi.quantidade * vi.custo_unitario),0) FROM venda_itens vi
         JOIN vendas v ON v.id = vi.venda_id WHERE v.estado = 'emitida' AND v.data_venda BETWEEN ? AND ?",
        [$from, $to]
    );
    $r['cogs'] = $cogs;
    $r['lucro'] = (float) $r['base'] - $cogs;
    return $r;
}

function dropship_summary(string $from, string $to): array
{
    $r = fetch_one(
        'SELECT COUNT(*) n,
                COALESCE(SUM(preco_venda * quantidade),0) receita,
                COALESCE(SUM(custo_fornecedor * quantidade + custo_envio + taxas),0) custos
         FROM encomendas WHERE ' . DROP_ACTIVE . ' AND data_encomenda BETWEEN ? AND ?',
        [$from, $to]
    ) ?? ['n' => 0, 'receita' => 0, 'custos' => 0];
    $r['lucro'] = (float) $r['receita'] - (float) $r['custos'];
    return $r;
}

function expenses_sum(string $from, string $to): float
{
    return (float) fetch_val('SELECT COALESCE(SUM(valor),0) FROM despesas WHERE data_despesa BETWEEN ? AND ?', [$from, $to]);
}

/** Dinheiro recebido no período (pagamentos de faturas + encomendas dropshipping pagas). */
function cash_in(string $from, string $to): array
{
    $sales = (float) fetch_val(
        "SELECT COALESCE(SUM(p.valor),0) FROM pagamentos p JOIN vendas v ON v.id = p.venda_id
         WHERE v.estado = 'emitida' AND p.data_pagamento BETWEEN ? AND ?",
        [$from, $to]
    );
    $drop = (float) fetch_val(
        "SELECT COALESCE(SUM(preco_venda * quantidade),0) FROM encomendas
         WHERE pagamento_cliente = 'pago' AND estado NOT IN ('cancelada','devolvida') AND data_encomenda BETWEEN ? AND ?",
        [$from, $to]
    );
    return ['vendas' => $sales, 'dropshipping' => $drop, 'total' => $sales + $drop];
}

/** Dinheiro pago no período (despesas + custos de dropshipping já pagos ao fornecedor). */
function cash_out(string $from, string $to): array
{
    $exp = expenses_sum($from, $to);
    $drop = (float) fetch_val(
        "SELECT COALESCE(SUM(custo_fornecedor * quantidade + custo_envio + taxas),0) FROM encomendas
         WHERE pagamento_fornecedor = 'pago' AND estado <> 'cancelada' AND data_encomenda BETWEEN ? AND ?",
        [$from, $to]
    );
    return ['despesas' => $exp, 'dropshipping' => $drop, 'total' => $exp + $drop];
}

/** Valores por receber de clientes (faturas em aberto + encomendas por cobrar). */
function receivables(): array
{
    $v = fetch_one("SELECT COUNT(*) n, COALESCE(SUM(total - valor_pago),0) val FROM vendas WHERE estado = 'emitida' AND total - valor_pago > 0.004") ?? ['n' => 0, 'val' => 0];
    $o = fetch_one("SELECT COUNT(*) n, COALESCE(SUM(preco_venda * quantidade),0) val FROM encomendas WHERE pagamento_cliente = 'pendente' AND estado NOT IN ('cancelada','devolvida')") ?? ['n' => 0, 'val' => 0];
    return ['vendas_n' => (int) $v['n'], 'vendas' => (float) $v['val'], 'drop_n' => (int) $o['n'], 'drop' => (float) $o['val'], 'total' => (float) $v['val'] + (float) $o['val']];
}

/** Valores a pagar a fornecedores de dropshipping. */
function payables(): array
{
    $o = fetch_one("SELECT COUNT(*) n, COALESCE(SUM(custo_fornecedor * quantidade + custo_envio + taxas),0) val FROM encomendas
                    WHERE pagamento_fornecedor = 'pendente' AND estado IN ('encomendada','enviada','entregue')") ?? ['n' => 0, 'val' => 0];
    return ['n' => (int) $o['n'], 'total' => (float) $o['val']];
}

/** Totais diários de vendas num intervalo, com zeros nos dias sem vendas. */
function sales_daily(string $from, string $to): array
{
    $rows = fetch_all(
        "SELECT data_venda d, SUM(total) t FROM vendas WHERE estado = 'emitida' AND data_venda BETWEEN ? AND ? GROUP BY data_venda",
        [$from, $to]
    );
    $map = [];
    foreach ($rows as $r) {
        $map[$r['d']] = (float) $r['t'];
    }
    $out = [];
    for ($t = strtotime($from); $t <= strtotime($to); $t += 86400) {
        $d = date('Y-m-d', $t);
        $out[$d] = $map[$d] ?? 0.0;
    }
    return $out;
}

function pct_change(float $now, float $before): ?float
{
    if ($before <= 0.0) {
        return $now > 0 ? null : 0.0;
    }
    return ($now - $before) / $before * 100;
}

function pct_html(?float $p): string
{
    if ($p === null) {
        return '<span class="muted">novo período</span>';
    }
    $cls = $p >= 0 ? 'up' : 'down';
    $arrow = $p >= 0 ? '▲' : '▼';
    return '<span class="' . $cls . '">' . $arrow . ' ' . number_format(abs($p), 0, ',', '.') . '%</span>';
}

const WEEKDAYS_PT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const MONTHS_PT = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
