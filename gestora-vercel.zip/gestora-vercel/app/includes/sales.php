<?php
declare(strict_types=1);

/**
 * Lógica de vendas/faturação: criação de faturas, cálculo de IVA, stock e anulação.
 */

/**
 * Calcula totais a partir do subtotal (soma das linhas), desconto e regras de IVA.
 * @return array{subtotal:float,desconto:float,base:float,taxa:float,iva:float,total:float}
 */
function sale_totals(float $subtotal, float $desconto, ?float $taxa = null, ?bool $incluiIva = null): array
{
    $taxa = $taxa ?? (float) setting('iva_taxa', '0');
    $incluiIva = $incluiIva ?? (setting('precos_incluem_iva', '1') === '1');
    $subtotal = round($subtotal, 2);
    $desconto = max(0.0, min(round($desconto, 2), $subtotal));
    $liquido = round($subtotal - $desconto, 2);

    if ($incluiIva) {
        $total = $liquido;
        $base = $taxa > 0 ? round($total / (1 + $taxa / 100), 2) : $total;
        $iva = round($total - $base, 2);
    } else {
        $base = $liquido;
        $iva = round($base * $taxa / 100, 2);
        $total = round($base + $iva, 2);
    }
    return ['subtotal' => $subtotal, 'desconto' => $desconto, 'base' => $base, 'taxa' => $taxa, 'iva' => $iva, 'total' => $total];
}

/**
 * Cria uma venda/fatura com os seus itens, movimenta stock e regista pagamento inicial.
 *
 * @param array $d     cliente_id, data_venda (Y-m-d), canal, metodo_pagamento, desconto, notas, pago
 * @param array $items cada item: ['produto_id' => ?int, 'descricao' => string, 'quantidade' => float, 'preco' => float]
 * @throws RuntimeException com mensagem apresentável ao utilizador
 */
function create_sale(array $d, array $items): int
{
    $pdo = db();
    if (!$items) {
        throw new RuntimeException('Adiciona pelo menos um item à venda.');
    }
    $data = (string) ($d['data_venda'] ?? date('Y-m-d'));
    if (!valid_date($data)) {
        throw new RuntimeException('Data da venda inválida.');
    }
    $canal = in_array(($d['canal'] ?? 'loja'), ['loja', 'online', 'outro'], true) ? $d['canal'] : 'loja';
    $metodo = (string) ($d['metodo_pagamento'] ?? 'Numerário');

    $pdo->beginTransaction();
    try {
        $lines = [];
        $subtotal = 0.0;
        $sold = []; // produto_id => qtd acumulada (valida stock por produto)
        foreach ($items as $it) {
            $qtd = (float) $it['quantidade'];
            $preco = (float) $it['preco'];
            $desc = trim((string) $it['descricao']);
            if ($qtd <= 0) {
                throw new RuntimeException('A quantidade de cada item deve ser maior que zero.');
            }
            if ($preco < 0) {
                throw new RuntimeException('O preço de um item não pode ser negativo.');
            }
            $pid = !empty($it['produto_id']) ? (int) $it['produto_id'] : null;
            $custo = 0.0;
            $move = 0;
            if ($pid) {
                $p = fetch_one('SELECT id, nome, tipo, preco_custo, stock_atual, ativo FROM produtos WHERE id = ? FOR UPDATE', [$pid]);
                if (!$p || (int) $p['ativo'] !== 1) {
                    throw new RuntimeException('Um dos produtos já não está disponível.');
                }
                $custo = (float) $p['preco_custo'];
                if ($desc === '') {
                    $desc = $p['nome'];
                }
                if ($p['tipo'] === 'stock') {
                    if (abs($qtd - round($qtd)) > 0.0001) {
                        throw new RuntimeException('"' . $p['nome'] . '": produtos em stock só podem ser vendidos em quantidades inteiras.');
                    }
                    $sold[$pid] = ($sold[$pid] ?? 0) + (int) round($qtd);
                    if ($sold[$pid] > (int) $p['stock_atual']) {
                        throw new RuntimeException('Stock insuficiente para "' . $p['nome'] . '" (disponível: ' . (int) $p['stock_atual'] . ').');
                    }
                    $move = 1;
                }
            }
            if ($desc === '') {
                throw new RuntimeException('Cada item precisa de uma descrição ou de um produto.');
            }
            $total = round($qtd * $preco, 2);
            $subtotal += $total;
            $lines[] = [$pid, mb_substr($desc, 0, 200), $qtd, $preco, $custo, $total, $move];
        }

        $t = sale_totals($subtotal, (float) ($d['desconto'] ?? 0));

        $vendaId = 0;
        for ($try = 0; $try < 4; $try++) {
            $numero = next_number('FT', 'vendas', 'numero');
            try {
                q('INSERT INTO vendas (numero, cliente_id, utilizador_id, data_venda, canal, metodo_pagamento, subtotal, desconto, base_tributavel, iva_taxa, iva_valor, total, valor_pago, estado, notas)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,\'emitida\',?)', [
                    $numero, opt_null($d['cliente_id'] ?? 0), $_SESSION['uid'] ?? null, $data, $canal, $metodo,
                    $t['subtotal'], $t['desconto'], $t['base'], $t['taxa'], $t['iva'], $t['total'], str_or_null((string) ($d['notas'] ?? '')),
                ]);
                $vendaId = last_id();
                break;
            } catch (PDOException $e) {
                if ((int) ($e->errorInfo[1] ?? 0) !== 1062 || $try === 3) {
                    throw $e;
                }
            }
        }

        foreach ($lines as [$pid, $desc, $qtd, $preco, $custo, $total, $move]) {
            q('INSERT INTO venda_itens (venda_id, produto_id, descricao, quantidade, preco_unitario, custo_unitario, total, movimenta_stock) VALUES (?,?,?,?,?,?,?,?)',
                [$vendaId, $pid, $desc, $qtd, $preco, $custo, $total, $move]);
            if ($move && $pid) {
                stock_move($pid, 'saida', (int) round($qtd), 'Venda ' . $numero, $numero);
            }
        }

        $pago = round((float) ($d['pago'] ?? 0), 2);
        if ($pago > 0.004) {
            $pago = min($pago, $t['total']);
            q('INSERT INTO pagamentos (venda_id, valor, metodo, data_pagamento, utilizador_id, notas) VALUES (?,?,?,?,?,?)',
                [$vendaId, $pago, $metodo, $data, $_SESSION['uid'] ?? null, 'Pagamento na emissão']);
            recompute_sale_payment($vendaId);
        }

        $pdo->commit();
        return $vendaId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/** Anula uma fatura e repõe o stock dos itens que o movimentaram. */
function cancel_sale(int $vendaId): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $v = fetch_one('SELECT * FROM vendas WHERE id = ? FOR UPDATE', [$vendaId]);
        if (!$v) {
            throw new RuntimeException('Venda não encontrada.');
        }
        if ($v['estado'] === 'anulada') {
            throw new RuntimeException('Esta fatura já está anulada.');
        }
        foreach (fetch_all('SELECT produto_id, quantidade FROM venda_itens WHERE venda_id = ? AND movimenta_stock = 1 AND produto_id IS NOT NULL', [$vendaId]) as $it) {
            stock_move((int) $it['produto_id'], 'entrada', (int) round((float) $it['quantidade']), 'Anulação de ' . $v['numero'], $v['numero']);
        }
        q("UPDATE vendas SET estado = 'anulada' WHERE id = ?", [$vendaId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}
