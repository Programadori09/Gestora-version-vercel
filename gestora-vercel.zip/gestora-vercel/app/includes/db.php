<?php
declare(strict_types=1);

/**
 * Ligação PDO à base de dados + pequenos atalhos de consulta.
 * Configuração vinda de variáveis de ambiente (ver config/config.php).
 */

/** Procura o certificado CA para ligações TLS. */
function gt_find_ca(): ?string
{
    $appRoot = dirname(__DIR__);
    $candidates = [];

    $custom = (string) cfg('db_ssl_ca', '');
    if ($custom !== '') {
        $candidates[] = ($custom[0] === '/') ? $custom : $appRoot . '/' . $custom;
    }
    $candidates[] = $appRoot . '/config/ca.pem';
    // Bundles de certificados do sistema (Amazon Linux / Debian / Alpine)
    $candidates[] = '/etc/pki/tls/certs/ca-bundle.crt';
    $candidates[] = '/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem';
    $candidates[] = '/etc/ssl/certs/ca-certificates.crt';
    $candidates[] = '/etc/ssl/cert.pem';

    foreach ($candidates as $c) {
        if (is_file($c) && is_readable($c)) {
            return $c;
        }
    }
    return null;
}

/** Cria uma ligação nova. Lança excepção se falhar (usado por db() e pelo instalador). */
function db_connect(): PDO
{
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        cfg('db_host'),
        (int) cfg('db_port'),
        cfg('db_name')
    );

    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 10,
    ];

    if (cfg('db_ssl')) {
        $ca = gt_find_ca();
        if ($ca === null) {
            throw new RuntimeException('DB_SSL está ativo mas não encontrei o certificado CA. Guarda o certificado do teu fornecedor em app/config/ca.pem (ou define DB_SSL_CA).');
        }
        $opts[PDO::MYSQL_ATTR_SSL_CA] = $ca;
        $opts[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = true;
    }

    $pdo = new PDO($dsn, (string) cfg('db_user'), (string) cfg('db_pass'), $opts);
    $pdo->exec("SET time_zone = '" . date('P') . "'");
    return $pdo;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    try {
        $pdo = db_connect();
    } catch (Throwable $e) {
        http_response_code(500);
        $msg = !empty(cfg('debug'))
            ? htmlspecialchars($e->getMessage())
            : 'Verifica as variáveis de ambiente DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS e DB_SSL no painel da Vercel. Para ver o erro detalhado, define APP_DEBUG=1 temporariamente.';
        echo '<!doctype html><meta charset="utf-8"><title>GesTora</title>'
           . '<body style="font-family:system-ui;background:#060d24;color:#e8eeff;display:grid;place-items:center;min-height:100vh;margin:0">'
           . '<div style="max-width:460px;padding:32px;background:#0b1738;border-radius:16px;border:1px solid #1f3a8a">'
           . '<h2 style="margin-top:0">Não foi possível ligar à base de dados</h2><p>' . $msg . '</p></div></body>';
        exit;
    }

    return $pdo;
}

/** true se o esquema da GesTora já existe (tabela de utilizadores criada). */
function gt_is_installed(): bool
{
    try {
        db()->query('SELECT 1 FROM utilizadores LIMIT 1');
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function fetch_all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function fetch_one(string $sql, array $params = []): ?array
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

function fetch_val(string $sql, array $params = [])
{
    $v = q($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function last_id(): int
{
    return (int) db()->lastInsertId();
}
