<?php
declare(strict_types=1);

/**
 * CRUD partilhado por Clientes e Fornecedores (tabelas com a mesma estrutura).
 * $cfg: table, area, active (chave do menu), singular, plural, file, icon, sale_link (bool)
 */
function render_contacts(array $cfg): void
{
    $user = require_area($cfg['area']);
    $t = $cfg['table'];
    $file = $cfg['file'];
    $acao = get('acao');

    if (is_post()) {
        csrf_verify();
        $op = post('op');
        if ($op === 'guardar') {
            $id = (int) post('id');
            $nome = post('nome');
            $email = post('email');
            if ($nome === '') {
                flash('error', 'O nome é obrigatório.');
                redirect($id ? "$file?acao=editar&id=$id" : "$file?acao=novo");
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                flash('error', 'O email indicado não é válido.');
                redirect($id ? "$file?acao=editar&id=$id" : "$file?acao=novo");
            }
            $vals = [$nome, str_or_null(post('nif')), str_or_null(post('telefone')), str_or_null($email), str_or_null(post('endereco')), str_or_null(post('notas')), post('ativo') === '1' ? 1 : 0];
            if ($id) {
                q("UPDATE $t SET nome=?, nif=?, telefone=?, email=?, endereco=?, notas=?, ativo=? WHERE id=?", array_merge($vals, [$id]));
                flash('success', $cfg['singular'] . ' atualizado.');
            } else {
                q("INSERT INTO $t (nome, nif, telefone, email, endereco, notas, ativo) VALUES (?,?,?,?,?,?,?)", $vals);
                flash('success', $cfg['singular'] . ' criado.');
            }
            log_activity($t . '_guardado', $nome);
            redirect($file);
        }
        if ($op === 'eliminar') {
            $id = (int) post('id');
            // As chaves estrangeiras usam ON DELETE SET NULL; o histórico das vendas mantém-se.
            q("DELETE FROM $t WHERE id = ?", [$id]);
            log_activity($t . '_removido', '#' . $id);
            flash('success', $cfg['singular'] . ' eliminado.');
            redirect($file);
        }
    }

    if ($acao === 'novo' || $acao === 'editar') {
        $r = ['id' => 0, 'nome' => '', 'nif' => '', 'telefone' => '', 'email' => '', 'endereco' => '', 'notas' => '', 'ativo' => 1];
        if ($acao === 'editar') {
            $row = fetch_one("SELECT * FROM $t WHERE id = ?", [(int) get('id')]);
            if (!$row) {
                flash('error', 'Registo não encontrado.');
                redirect($file);
            }
            $r = $row;
        }
        page_header(($r['id'] ? 'Editar ' : 'Novo ') . mb_strtolower($cfg['singular']), $cfg['active'], ['actions' => '<a class="btn" href="' . e($file) . '">Voltar</a>']);
        ?>
        <form class="card" method="post" data-once>
          <?= csrf_field() ?><input type="hidden" name="op" value="guardar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <div class="form-grid">
            <div class="field col-8"><label class="required" for="nome">Nome</label><input type="text" id="nome" name="nome" value="<?= e($r['nome']) ?>" required maxlength="140"></div>
            <div class="field col-4"><label for="nif">NIF</label><input type="text" id="nif" name="nif" value="<?= e($r['nif']) ?>" maxlength="30"></div>
            <div class="field col-4"><label for="telefone">Telefone</label><input type="tel" id="telefone" name="telefone" value="<?= e($r['telefone']) ?>" maxlength="40"></div>
            <div class="field col-8"><label for="email">Email</label><input type="email" id="email" name="email" value="<?= e($r['email']) ?>" maxlength="160"></div>
            <div class="field col-12"><label for="endereco">Morada</label><input type="text" id="endereco" name="endereco" value="<?= e($r['endereco']) ?>" maxlength="255"></div>
            <div class="field col-12"><label for="notas">Notas</label><textarea id="notas" name="notas"><?= e($r['notas']) ?></textarea></div>
            <div class="col-12"><label class="check"><input type="checkbox" name="ativo" value="1"<?= chk((int) $r['ativo'] === 1) ?>> Ativo</label></div>
          </div>
          <div class="form-actions"><a class="btn" href="<?= e($file) ?>">Cancelar</a><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar</button></div>
        </form>
        <?php
        page_footer();
        return;
    }

    $qText = get('q');
    $where = '1=1';
    $params = [];
    if ($qText !== '') {
        $where = '(nome LIKE ? OR telefone LIKE ? OR email LIKE ? OR nif LIKE ?)';
        $params = array_fill(0, 4, '%' . $qText . '%');
    }
    $pg = paginate((int) fetch_val("SELECT COUNT(*) FROM $t WHERE $where", $params), 15);

    if ($t === 'clientes') {
        $extra = "(SELECT COALESCE(SUM(v.total),0) FROM vendas v WHERE v.cliente_id = $t.id AND v.estado = 'emitida') AS movimento,
                  (SELECT COALESCE(SUM(v.total - v.valor_pago),0) FROM vendas v WHERE v.cliente_id = $t.id AND v.estado = 'emitida' AND v.total - v.valor_pago > 0.004) AS divida";
        $colA = 'Total comprado';
        $colB = 'Em dívida';
    } else {
        $extra = "(SELECT COUNT(*) FROM produtos p WHERE p.fornecedor_id = $t.id) AS movimento,
                  (SELECT COALESCE(SUM(e.custo_fornecedor * e.quantidade + e.custo_envio + e.taxas),0) FROM encomendas e WHERE e.fornecedor_id = $t.id AND e.pagamento_fornecedor = 'pendente' AND e.estado IN ('encomendada','enviada','entregue')) AS divida";
        $colA = 'Produtos';
        $colB = 'A pagar (dropshipping)';
    }
    $rows = fetch_all("SELECT $t.*, $extra FROM $t WHERE $where ORDER BY nome LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params);

    page_header($cfg['plural'], $cfg['active'], [
        'subtitle' => $cfg['subtitle'],
        'actions' => '<a class="btn btn-primary" href="' . e($file) . '?acao=novo">' . icon('plus', 18) . ' Novo ' . e(mb_strtolower($cfg['singular'])) . '</a>',
    ]);
    ?>
    <div class="card">
      <form class="filters" method="get">
        <input type="search" name="q" value="<?= e($qText) ?>" placeholder="Pesquisar por nome, telefone, email ou NIF…" aria-label="Pesquisar">
        <button class="btn" type="submit"><?= icon('search', 16) ?> Pesquisar</button>
        <?php if ($qText !== ''): ?><a class="btn btn-sm" href="<?= e($file) ?>">Limpar</a><?php endif; ?>
      </form>
      <?php if (!$rows): echo empty_state('Nenhum registo encontrado.', $cfg['icon']); else: ?>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Nome</th><th>Contacto</th><th class="num"><?= e($colA) ?></th><th class="num"><?= e($colB) ?></th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><span class="cell-main"><?= e($r['nome']) ?></span><?= (int) $r['ativo'] ? '' : ' ' . badge('Inativo', 'danger') ?><span class="cell-sub"><?= e($r['nif'] ? 'NIF ' . $r['nif'] : '') ?></span></td>
            <td><?= e($r['telefone'] ?? '—') ?><span class="cell-sub"><?= e($r['email'] ?? '') ?></span></td>
            <td class="num"><?= $t === 'clientes' ? e(money($r['movimento'])) : num($r['movimento']) ?></td>
            <td class="num"><?= (float) $r['divida'] > 0.004 ? '<span style="color:var(--warning);font-weight:600">' . e(money($r['divida'])) . '</span>' : '<span class="muted">—</span>' ?></td>
            <td><div class="row-actions">
              <?php if (!empty($cfg['sale_link']) && can('vendas')): ?><a class="btn btn-sm btn-icon" title="Nova venda" href="venda_nova.php?cliente=<?= (int) $r['id'] ?>"><?= icon('cart', 16) ?></a><?php endif; ?>
              <a class="btn btn-sm btn-icon" title="Editar" href="<?= e($file) ?>?acao=editar&id=<?= (int) $r['id'] ?>"><?= icon('edit', 16) ?></a>
              <?php if (can('utilizadores') || $user['perfil'] === 'gestor'): ?>
              <form class="inline-form" method="post" data-confirm="Eliminar este registo? O histórico de vendas é mantido."><?= csrf_field() ?><input type="hidden" name="op" value="eliminar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                <button class="btn btn-sm btn-icon btn-danger" title="Eliminar" type="submit"><?= icon('trash', 16) ?></button></form>
              <?php endif; ?>
            </div></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?= pagination_html($pg) ?>
      <?php endif; ?>
    </div>
    <?php
    page_footer();
}
