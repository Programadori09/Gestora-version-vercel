<?php
declare(strict_types=1);

/**
 * Sessões guardadas na base de dados.
 * Na Vercel cada pedido pode correr numa instância diferente e o disco não persiste,
 * por isso as sessões em ficheiro (comportamento normal do PHP) não funcionam.
 */
final class GtSessionHandler implements SessionHandlerInterface, SessionUpdateTimestampHandlerInterface
{
    public const LIFETIME = 2592000; // 30 dias (cobre a opção "lembrar")

    private ?int $readTs = null;
    private bool $tableEnsured = false;

    public function open(string $path, string $name): bool
    {
        return true;
    }

    public function close(): bool
    {
        return true;
    }

    public function read(string $id): string|false
    {
        $row = $this->selectRow($id);
        if (!$row) {
            $this->readTs = null;
            return '';
        }
        if ((int) $row['atualizado_em'] < time() - self::LIFETIME) {
            $this->readTs = null;
            return '';
        }
        $this->readTs = (int) $row['atualizado_em'];
        return (string) $row['dados'];
    }

    public function write(string $id, string $data): bool
    {
        q(
            'INSERT INTO sessoes (id, dados, atualizado_em) VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE dados = VALUES(dados), atualizado_em = VALUES(atualizado_em)',
            [$id, $data, time()]
        );
        return true;
    }

    public function destroy(string $id): bool
    {
        q('DELETE FROM sessoes WHERE id = ?', [$id]);
        return true;
    }

    public function gc(int $max_lifetime): int|false
    {
        try {
            return q('DELETE FROM sessoes WHERE atualizado_em < ?', [time() - self::LIFETIME])->rowCount();
        } catch (PDOException $e) {
            return 0; // tabela ainda não existe; será criada no primeiro read()
        }
    }

    public function validateId(string $id): bool
    {
        $row = $this->selectRow($id);
        return $row !== null && (int) $row['atualizado_em'] >= time() - self::LIFETIME;
    }

    /** Chamado quando os dados não mudaram: só renova o carimbo de tempo (no máximo a cada 5 min). */
    public function updateTimestamp(string $id, string $data): bool
    {
        if ($this->readTs !== null && time() - $this->readTs < 300) {
            return true;
        }
        q('UPDATE sessoes SET atualizado_em = ? WHERE id = ?', [time(), $id]);
        return true;
    }

    private function selectRow(string $id): ?array
    {
        try {
            return fetch_one('SELECT dados, atualizado_em FROM sessoes WHERE id = ?', [$id]);
        } catch (PDOException $e) {
            // Tabela ainda não existe (base de dados nova): cria-a e continua.
            if (!$this->tableEnsured) {
                $this->tableEnsured = true;
                gt_ensure_sessions_table();
                return fetch_one('SELECT dados, atualizado_em FROM sessoes WHERE id = ?', [$id]);
            }
            throw $e;
        }
    }
}

function gt_ensure_sessions_table(): void
{
    db()->exec(
        'CREATE TABLE IF NOT EXISTS sessoes (
           id VARCHAR(128) NOT NULL PRIMARY KEY,
           dados MEDIUMBLOB NOT NULL,
           atualizado_em INT UNSIGNED NOT NULL,
           KEY idx_sess_data (atualizado_em)
         ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}
