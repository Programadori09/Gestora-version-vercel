<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/contacts.php';

render_contacts([
    'table' => 'fornecedores', 'area' => 'fornecedores', 'active' => 'fornecedores', 'singular' => 'Fornecedor', 'plural' => 'Fornecedores',
    'file' => 'fornecedores.php', 'icon' => 'truck', 'sale_link' => false,
    'subtitle' => 'Quem te fornece mercadoria, incluindo parceiros de dropshipping.',
]);
