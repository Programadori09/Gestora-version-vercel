<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('relatorios');

$tipos = [
    'vendas' => 'Vendas por fatura',
    'produtos' => 'Vendas por produto',
    'clientes' => 'Vendas por cliente',
    'stock' => 'Inventário (stock atual)',
    'dropshipping' => 'Encomendas dropshipping',
    'despesas' => 'Despesas',
];
$tipo = array_key_exists(get('tipo'), $tipos) ? get('tipo') : 'vendas';
$de = valid_date(get('de')) ? get('de') : date('Y-m-01');
$ate = valid_date(get('ate')) ? get('ate') : date('Y-m-d');
if ($de > $ate) {
    [$de, $ate] = [$ate, $de];
}

/** Cada relatório devolve: colunas [titulo, tipo(text|money|num|date)], linhas, linha de totais opcional. */
function build_report(string $tipo, string $de, string $ate): array
{
    switch ($tipo) {
        case 'vendas':
            $r = fetch_all("SELECT v.numero, v.data_venda, COALESCE(c.nome,'Consumidor final') cliente, v.canal, v.base_tributavel, v.iva_valor, v.total, v.valor_pago
                            FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id
                            WHERE v.estado = 'emitida' AND v.data_venda BETWEEN ? AND ? ORDER BY v.data_venda, v.id", [$de, $ate]);
            $cols = [['Fatura', 'text'], ['Data', 'date'], ['Cliente', 'text'], ['Canal', 'text'], ['Base', 'money'], ['IVA', 'money'], ['Total', 'money'], ['Pago', 'money']];
            $rows = array_map(fn($x) => [$x['numero'], $x['data_venda'], $x['cliente'], ucfirst($x['canal']), $x['base_tributavel'], $x['iva_valor'], $x['total'], $x['valor_pago']], $r);
            return [$cols, $rows, [4, 5, 6, 7]];
        case 'produtos':
            $r = fetch_all("SELECT vi.descricao, SUM(vi.quantidade) qtd, SUM(vi.total) receita, SUM(vi.quantidade * vi.custo_unitario) custo
                            FROM venda_itens vi JOIN vendas v ON v.id = vi.venda_id
                            WHERE v.estado = 'emitida' AND v.data_venda BETWEEN ? AND ? GROUP BY vi.descricao ORDER BY receita DESC", [$de, $ate]);
            $cols = [['Produto', 'text'], ['Quantidade', 'num'], ['Receita (c/ IVA)', 'money'], ['Custo', 'money']];
            $rows = array_map(fn($x) => [$x['descricao'], $x['qtd'], $x['receita'], $x['custo']], $r);
            return [$cols, $rows, [1, 2, 3]];
        case 'clientes':
            $r = fetch_all("SELECT COALESCE(c.nome,'Consumidor final') nome, COUNT(*) n, SUM(v.total) total, SUM(v.total - v.valor_pago) aberto
                            FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id
                            WHERE v.estado = 'emitida' AND v.data_venda BETWEEN ? AND ? GROUP BY c.id, c.nome ORDER BY total DESC", [$de, $ate]);
            $cols = [['Cliente', 'text'], ['Faturas', 'num'], ['Total comprado', 'money'], ['Em aberto', 'money']];
            $rows = array_map(fn($x) => [$x['nome'], $x['n'], $x['total'], $x['aberto']], $r);
            return [$cols, $rows, [1, 2, 3]];
        case 'stock':
            $r = fetch_all("SELECT p.codigo, p.nome, COALESCE(c.nome,'—') categoria, p.stock_atual, p.stock_minimo, p.preco_custo, p.preco_venda, p.stock_atual * p.preco_custo valor
                            FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE p.ativo = 1 AND p.tipo = 'stock' ORDER BY p.nome");
            $cols = [['Código', 'text'], ['Produto', 'text'], ['Categoria', 'text'], ['Stock', 'num'], ['Mínimo', 'num'], ['Custo', 'money'], ['Venda', 'money'], ['Valor em stock', 'money']];
            $rows = array_map(fn($x) => [$x['codigo'] ?? '', $x['nome'], $x['categoria'], $x['stock_atual'], $x['stock_minimo'], $x['preco_custo'], $x['preco_venda'], $x['valor']], $r);
            return [$cols, $rows, [3, 7]];
        case 'dropshipping':
            $r = fetch_all('SELECT * FROM encomendas WHERE data_encomenda BETWEEN ? AND ? ORDER BY data_encomenda, id', [$de, $ate]);
            $cols = [['Referência', 'text'], ['Data', 'date'], ['Cliente', 'text'], ['Produto', 'text'], ['Estado', 'text'], ['Receita', 'money'], ['Custos', 'money'], ['Lucro', 'money']];
            $rows = [];
            foreach ($r as $x) {
                $valida = !in_array($x['estado'], ['cancelada', 'devolvida'], true) && $x['pagamento_cliente'] !== 'reembolsado';
                $rec = (float) $x['preco_venda'] * (int) $x['quantidade'];
                $cus = (float) $x['custo_fornecedor'] * (int) $x['quantidade'] + (float) $x['custo_envio'] + (float) $x['taxas'];
                $rows[] = [$x['referencia'], $x['data_encomenda'], $x['cliente_nome'], $x['produto_nome'], ucfirst($x['estado']), $valida ? $rec : 0, $valida ? $cus : 0, $valida ? $rec - $cus : 0];
            }
            return [$cols, $rows, [5, 6, 7]];
        default: // despesas
            $r = fetch_all('SELECT data_despesa, descricao, categoria, metodo, valor FROM despesas WHERE data_despesa BETWEEN ? AND ? ORDER BY data_despesa, id', [$de, $ate]);
            $cols = [['Data', 'date'], ['Descrição', 'text'], ['Categoria', 'text'], ['Método', 'text'], ['Valor', 'money']];
            $rows = array_map(fn($x) => [$x['data_despesa'], $x['descricao'], $x['categoria'], $x['metodo'], $x['valor']], $r);
            return [$cols, $rows, [4]];
    }
}

[$cols, $rows, $sumCols] = build_report($tipo, $de, $ate);

/* ---------- Exportação CSV (compatível com Excel) ---------- */
if (get('export') === 'csv') {
    $name = 'gestora-' . $tipo . '-' . $de . '_' . $ate . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array_map(fn($c) => $c[0], $cols), ';');
    foreach ($rows as $r) {
        $line = [];
        foreach ($r as $i => $v) {
            $t = $cols[$i][1];
            if ($t === 'date') {
                $v = fdate((string) $v);
            } elseif ($t === 'money' || $t === 'num') {
                $v = number_format((float) $v, $t === 'money' ? 2 : (fmod((float) $v, 1) ? 2 : 0), ',', '');
            } else {
                $v = (string) $v;
                if ($v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) {
                    $v = "'" . $v; // evita injeção de fórmulas no Excel
                }
            }
            $line[] = $v;
        }
        fputcsv($out, $line, ';');
    }
    fclose($out);
    exit;
}

$totais = [];
foreach ($sumCols as $i) {
    $s = 0.0;
    foreach ($rows as $r) {
        $s += (float) $r[$i];
    }
    $totais[$i] = $s;
}
$usaPeriodo = $tipo !== 'stock';
$csvUrl = 'relatorios.php' . qs(['export' => 'csv', 'p' => null]);

page_header('Relatórios', 'relatorios', [
    'subtitle' => 'Consulta, imprime ou exporta os dados do teu negócio.',
    'actions' => '<a class="btn" href="' . e($csvUrl) . '">' . icon('download', 18) . ' Exportar CSV</a>'
        . '<button class="btn btn-primary no-print" type="button" onclick="window.print()">' . icon('printer', 18) . ' Imprimir</button>',
]);

function fmt_cell($v, string $t): string
{
    switch ($t) {
        case 'money':
            return e(money($v));
        case 'num':
            return num($v, fmod((float) $v, 1) ? 2 : 0);
        case 'date':
            return e(fdate((string) $v));
        default:
            return e($v);
    }
}
?>
<div class="card">
  <form class="filters no-print" method="get">
    <select name="tipo" aria-label="Tipo de relatório"><?php foreach ($tipos as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($tipo, $k) ?>><?= e($l) ?></option><?php endforeach; ?></select>
    <?php if ($usaPeriodo): ?>
      <div class="field"><input type="date" name="de" value="<?= e($de) ?>" aria-label="De"></div>
      <div class="field"><input type="date" name="ate" value="<?= e($ate) ?>" aria-label="Até"></div>
    <?php endif; ?>
    <button class="btn" type="submit"><?= icon('search', 16) ?> Gerar</button>
  </form>
  <h2 style="margin:4px 0 14px;font-size:16px"><?= e($tipos[$tipo]) ?><?= $usaPeriodo ? ' <span class="muted" style="font-weight:400">· ' . e(fdate($de)) . ' a ' . e(fdate($ate)) . '</span>' : '' ?></h2>
  <?php if (!$rows): echo empty_state('Sem dados para este relatório e período.', 'chart'); else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><?php foreach ($cols as $c): ?><th class="<?= in_array($c[1], ['money', 'num'], true) ? 'num' : '' ?>"><?= e($c[0]) ?></th><?php endforeach; ?></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr><?php foreach ($r as $i => $v): $t = $cols[$i][1]; ?><td class="<?= in_array($t, ['money', 'num'], true) ? 'num' : '' ?>"><?= fmt_cell($v, $t) ?></td><?php endforeach; ?></tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot><tr>
      <?php foreach ($cols as $i => $c): ?>
        <td class="<?= in_array($c[1], ['money', 'num'], true) ? 'num' : '' ?>"><?= $i === 0 ? 'Total (' . num(count($rows)) . ')' : (isset($totais[$i]) ? fmt_cell($totais[$i], $c[1]) : '') ?></td>
      <?php endforeach; ?>
    </tr></tfoot>
  </table></div>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
