<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('pesquisa');

$qt = get('q');
$like = '%' . $qt . '%';
$prod = $cli = $vend = $enc = [];

if (mb_strlen($qt) >= 2) {
    $prod = fetch_all('SELECT id, nome, codigo, preco_venda, stock_atual, tipo FROM produtos WHERE nome LIKE ? OR codigo LIKE ? ORDER BY nome LIMIT 8', [$like, $like]);
    $cli = fetch_all('SELECT id, nome, telefone, email FROM clientes WHERE nome LIKE ? OR telefone LIKE ? OR email LIKE ? ORDER BY nome LIMIT 8', [$like, $like, $like]);
    $vend = fetch_all('SELECT v.id, v.numero, v.data_venda, v.total, c.nome cliente FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id WHERE v.numero LIKE ? OR c.nome LIKE ? ORDER BY v.data_venda DESC LIMIT 8', [$like, $like]);
    if (can('encomendas')) {
        $enc = fetch_all('SELECT id, referencia, cliente_nome, produto_nome FROM encomendas WHERE referencia LIKE ? OR cliente_nome LIKE ? OR produto_nome LIKE ? OR rastreio LIKE ? ORDER BY id DESC LIMIT 8', [$like, $like, $like, $like]);
    }
}
$nada = !$prod && !$cli && !$vend && !$enc;

page_header('Pesquisa', '', ['subtitle' => $qt !== '' ? 'Resultados para “' . $qt . '”' : 'Escreve na barra de pesquisa para procurar.']);
if (mb_strlen($qt) < 2): echo '<div class="card">' . empty_state('Escreve pelo menos 2 letras para pesquisar.', 'search') . '</div>';
elseif ($nada): echo '<div class="card">' . empty_state('Nada encontrado para “' . $qt . '”.', 'search') . '</div>';
else: ?>
<div class="grid g-2">
  <?php if ($prod): ?><div class="card"><div class="card-head"><h2>Produtos</h2></div><div class="list">
    <?php foreach ($prod as $p): ?><a class="list-item" style="color:inherit;text-decoration:none" href="<?= can('produtos_edit') ? 'produtos.php?acao=editar&id=' . (int) $p['id'] : 'produtos.php?q=' . urlencode($p['nome']) ?>">
      <div class="thumb"><?= icon('box', 18) ?></div><div class="grow"><b><?= e($p['nome']) ?></b><span><?= e($p['codigo'] ?? '') ?><?= $p['tipo'] === 'stock' ? ' · ' . num($p['stock_atual']) . ' em stock' : '' ?></span></div><div class="val"><?= e(money($p['preco_venda'])) ?></div></a>
    <?php endforeach; ?></div></div><?php endif; ?>
  <?php if ($cli): ?><div class="card"><div class="card-head"><h2>Clientes</h2></div><div class="list">
    <?php foreach ($cli as $c): ?><a class="list-item" style="color:inherit;text-decoration:none" href="clientes.php?acao=editar&id=<?= (int) $c['id'] ?>">
      <div class="thumb"><?= icon('user', 18) ?></div><div class="grow"><b><?= e($c['nome']) ?></b><span><?= e(implode(' · ', array_filter([$c['telefone'], $c['email']]))) ?></span></div></a>
    <?php endforeach; ?></div></div><?php endif; ?>
  <?php if ($vend): ?><div class="card"><div class="card-head"><h2>Faturas</h2></div><div class="list">
    <?php foreach ($vend as $v): ?><a class="list-item" style="color:inherit;text-decoration:none" href="venda_ver.php?id=<?= (int) $v['id'] ?>">
      <div class="thumb"><?= icon('file', 18) ?></div><div class="grow"><b><?= e($v['numero']) ?></b><span><?= e(fdate($v['data_venda'])) ?> · <?= e($v['cliente'] ?? 'Consumidor final') ?></span></div><div class="val"><?= e(money($v['total'])) ?></div></a>
    <?php endforeach; ?></div></div><?php endif; ?>
  <?php if ($enc): ?><div class="card"><div class="card-head"><h2>Encomendas</h2></div><div class="list">
    <?php foreach ($enc as $o): ?><a class="list-item" style="color:inherit;text-decoration:none" href="encomendas.php?acao=editar&id=<?= (int) $o['id'] ?>">
      <div class="thumb"><?= icon('cube', 18) ?></div><div class="grow"><b><?= e($o['referencia']) ?></b><span><?= e($o['cliente_nome']) ?> · <?= e($o['produto_nome']) ?></span></div></a>
    <?php endforeach; ?></div></div><?php endif; ?>
</div>
<?php endif;
page_footer();
