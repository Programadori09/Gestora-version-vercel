<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('vendas');

$id = (int) get('id');
$v = fetch_one('SELECT v.*, c.nome cliente, c.telefone cli_tel, c.email cli_email, c.endereco cli_end, c.nif cli_nif
                FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id WHERE v.id = ?', [$id]);
if (!$v) {
    redirect('vendas.php');
}
$items = fetch_all('SELECT * FROM venda_itens WHERE venda_id = ? ORDER BY id', [$id]);
[$lbl, $cls] = sale_payment_state($v);
$stamp = $cls === 'success' ? 'ok' : ($cls === 'danger' ? 'void' : 'pend');
$emAberto = max(0.0, round((float) $v['total'] - (float) $v['valor_pago'], 2));

page_header('Fatura ' . $v['numero'], 'vendas', ['bare' => true]);
?>
<div class="invoice-bar no-print">
  <a class="btn" href="venda_ver.php?id=<?= $id ?>"><?= icon('arrow-right', 16, '') ?> Voltar à fatura</a>
  <button class="btn btn-primary" type="button" onclick="window.print()"><?= icon('printer', 18) ?> Imprimir / Guardar PDF</button>
</div>

<article class="invoice">
  <div class="inv-top">
    <div>
      <?= logo_html(34) ?>
      <p style="margin:14px 0 0"><b><?= e(setting('empresa_nome', APP_NAME)) ?></b><br>
        <?php if (setting('empresa_nif') !== ''): ?>NIF <?= e(setting('empresa_nif')) ?><br><?php endif; ?>
        <?= e(setting('empresa_endereco')) ?><?= setting('empresa_endereco') !== '' ? '<br>' : '' ?>
        <?= e(implode(' · ', array_filter([setting('empresa_telefone'), setting('empresa_email')]))) ?></p>
    </div>
    <div class="inv-meta">
      <h2>Fatura / Recibo</h2>
      <div class="num"><?= e($v['numero']) ?></div>
      <div style="margin-top:6px">Data: <b><?= e(fdate($v['data_venda'])) ?></b></div>
      <div style="margin-top:8px"><span class="stamp <?= $stamp ?>"><?= e($lbl) ?></span></div>
    </div>
  </div>

  <div class="inv-parties">
    <div>
      <h4>Cliente</h4>
      <?php if ($v['cliente']): ?>
        <b><?= e($v['cliente']) ?></b><br>
        <?= e(implode(' · ', array_filter([$v['cli_tel'], $v['cli_email']]))) ?><?= ($v['cli_tel'] || $v['cli_email']) ? '<br>' : '' ?>
        <?= e($v['cli_end'] ?? '') ?><?= $v['cli_nif'] ? '<br>NIF ' . e($v['cli_nif']) : '' ?>
      <?php else: ?>Consumidor final<?php endif; ?>
    </div>
    <div>
      <h4>Pagamento</h4>
      Método: <b><?= e($v['metodo_pagamento']) ?></b><br>
      Pago: <b><?= e(money($v['valor_pago'])) ?></b><?= $emAberto > 0.004 && $v['estado'] === 'emitida' ? '<br>Em aberto: <b>' . e(money($emAberto)) . '</b>' : '' ?>
    </div>
  </div>

  <table>
    <thead><tr><th>Descrição</th><th class="r">Qtd.</th><th class="r">Preço unit.</th><th class="r">Total</th></tr></thead>
    <tbody>
    <?php foreach ($items as $it): ?>
      <tr><td><?= e($it['descricao']) ?></td><td class="r"><?= num($it['quantidade'], fmod((float) $it['quantidade'], 1) ? 2 : 0) ?></td><td class="r"><?= e(money($it['preco_unitario'])) ?></td><td class="r"><?= e(money($it['total'])) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <div class="totals">
    <div><span>Subtotal</span><span><?= e(money($v['subtotal'])) ?></span></div>
    <?php if ((float) $v['desconto'] > 0): ?><div><span>Desconto</span><span>− <?= e(money($v['desconto'])) ?></span></div><?php endif; ?>
    <div><span>Base tributável</span><span><?= e(money($v['base_tributavel'])) ?></span></div>
    <div><span>IVA (<?= num($v['iva_taxa'], 0) ?>%)</span><span><?= e(money($v['iva_valor'])) ?></span></div>
    <div class="grand"><span>Total</span><span><?= e(money($v['total'])) ?></span></div>
  </div>

  <?php if ($v['notas']): ?><p style="margin-top:24px"><b>Notas:</b> <?= e($v['notas']) ?></p><?php endif; ?>
  <div class="inv-foot">
    <?= e(setting('rodape_fatura')) ?><br>
    Documento processado por GesTora · <?= e(APP_TAGLINE) ?>.
  </div>
</article>
<?php page_footer(); ?>
