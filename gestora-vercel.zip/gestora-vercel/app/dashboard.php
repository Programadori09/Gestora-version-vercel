<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('dashboard');
$isSeller = $user['perfil'] === 'vendedor';
$money = fn($v) => money($v);

/* ---------- Indicadores ---------- */
[$hoF, $hoT] = period_range('hoje');
[$ontF, $ontT] = period_range('ontem');
$today = sales_summary($hoF, $hoT);
$yest = sales_summary($ontF, $ontT);

[$mF, $mT] = period_range('mes');
$month = sales_summary($mF, $mT);
// Período anterior equivalente (mesmos dias do mês anterior)
$prevStart = date('Y-m-01', strtotime('first day of last month'));
$prevEnd = date('Y-m-d', strtotime($prevStart . ' +' . ((int) date('j') - 1) . ' days'));
if ($prevEnd > date('Y-m-t', strtotime($prevStart))) {
    $prevEnd = date('Y-m-t', strtotime($prevStart));
}
$monthPrev = sales_summary($prevStart, $prevEnd);

$stockUnits = (int) fetch_val("SELECT COALESCE(SUM(stock_atual),0) FROM produtos WHERE ativo = 1 AND tipo = 'stock'");
$stockProducts = (int) fetch_val("SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND tipo = 'stock'");
$clientsActive = (int) fetch_val('SELECT COUNT(*) FROM clientes WHERE ativo = 1');

if (!$isSeller) {
    $drop = dropship_summary($mF, $mT);
    $expMonth = expenses_sum($mF, $mT);
    $profitMonth = $month['lucro'] + $drop['lucro'] - $expMonth;
    $rec = receivables();
    $pay = payables();
}

/* ---------- Gráfico de vendas ---------- */
$days = get('dias') === '30' ? 30 : 7;
$series = sales_daily(date('Y-m-d', strtotime('-' . ($days - 1) . ' days')), date('Y-m-d'));
$labels = [];
foreach (array_keys($series) as $d) {
    $labels[] = $days === 7 ? WEEKDAYS_PT[(int) date('w', strtotime($d))] : date('d/m', strtotime($d));
}
$chart = ['labels' => $labels, 'series' => [['name' => 'Vendas', 'values' => array_values($series)]]];

/* ---------- Listas ---------- */
$from30 = date('Y-m-d', strtotime('-29 days'));
$top = fetch_all(
    "SELECT vi.descricao nome, SUM(vi.quantidade) qtd, SUM(vi.total) val
     FROM venda_itens vi JOIN vendas v ON v.id = vi.venda_id
     WHERE v.estado = 'emitida' AND v.data_venda >= ?
     GROUP BY vi.descricao ORDER BY qtd DESC, val DESC LIMIT 5",
    [$from30]
);
$low = fetch_all("SELECT id, nome, stock_atual, stock_minimo FROM produtos WHERE ativo = 1 AND tipo = 'stock' AND stock_atual <= stock_minimo ORDER BY stock_atual ASC LIMIT 5");
$recent = fetch_all(
    "SELECT v.id, v.numero, v.data_venda, v.total, v.valor_pago, v.estado, c.nome cliente
     FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id
     ORDER BY v.data_venda DESC, v.id DESC LIMIT 6"
);
$pendingOrders = $isSeller || !can('encomendas') ? 0 : (int) fetch_val("SELECT COUNT(*) FROM encomendas WHERE estado IN ('nova','encomendada','enviada')");
$activity = $user['perfil'] === 'admin'
    ? fetch_all('SELECT a.acao, a.detalhe, a.criado_em, u.nome FROM atividades a LEFT JOIN utilizadores u ON u.id = a.utilizador_id ORDER BY a.id DESC LIMIT 6')
    : [];

$d = (int) date('j');
$dateLabel = 'Hoje · ' . $d . ' ' . MONTHS_PT[(int) date('n') - 1] . ' ' . date('Y');

page_header('Olá, ' . explode(' ', $user['nome'])[0] . '!', 'dashboard', [
    'subtitle' => 'Aqui está um resumo do seu negócio.',
    'actions' => '<span class="badge badge-neutral nowrap">' . icon('calendar', 14) . ' ' . e($dateLabel) . '</span>'
        . '<a class="btn btn-primary" href="venda_nova.php">' . icon('plus', 18) . ' Nova venda</a>',
]);
?>

<div class="grid g-4 mb">
  <div class="card kpi">
    <div class="k-ic"><?= icon('cart', 22) ?></div>
    <div class="k-label">Vendas hoje</div>
    <div class="k-value"><?= e(money($today['total'], false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note"><?= pct_html(pct_change((float) $today['total'], (float) $yest['total'])) ?> face a ontem · <?= num($today['n']) ?> venda(s)</div>
  </div>
  <div class="card kpi">
    <div class="k-ic"><?= icon('box', 22) ?></div>
    <div class="k-label">Stock total</div>
    <div class="k-value"><?= num($stockUnits) ?><small>unidades</small></div>
    <div class="k-note"><?= num($stockProducts) ?> produto(s) em stock</div>
  </div>
  <div class="card kpi">
    <div class="k-ic"><?= icon('users', 22) ?></div>
    <div class="k-label">Clientes ativos</div>
    <div class="k-value"><?= num($clientsActive) ?></div>
    <div class="k-note"><a href="clientes.php">Ver clientes</a></div>
  </div>
  <div class="card kpi">
    <div class="k-ic"><?= icon('trend', 22) ?></div>
    <div class="k-label">Faturação (mês)</div>
    <div class="k-value"><?= e(money($month['total'], false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note"><?= pct_html(pct_change((float) $month['total'], (float) $monthPrev['total'])) ?> face ao mesmo período do mês anterior</div>
  </div>
</div>

<?php if (!$isSeller): ?>
<div class="grid g-4 mb">
  <div class="card kpi <?= $profitMonth >= 0 ? 'good' : 'bad' ?>">
    <div class="k-ic"><?= icon('dollar', 22) ?></div>
    <div class="k-label">Lucro estimado (mês)</div>
    <div class="k-value"><?= e(money($profitMonth, false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note">Vendas + dropshipping − despesas</div>
  </div>
  <div class="card kpi warn">
    <div class="k-ic"><?= icon('file', 22) ?></div>
    <div class="k-label">A receber</div>
    <div class="k-value"><?= e(money($rec['total'], false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note"><?= num($rec['vendas_n']) ?> fatura(s) · <?= num($rec['drop_n']) ?> encomenda(s)</div>
  </div>
  <div class="card kpi bad">
    <div class="k-ic"><?= icon('wallet', 22) ?></div>
    <div class="k-label">Despesas (mês)</div>
    <div class="k-value"><?= e(money($expMonth, false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note"><a href="despesas.php">Ver despesas</a></div>
  </div>
  <div class="card kpi">
    <div class="k-ic"><?= icon('cube', 22) ?></div>
    <div class="k-label">Dropshipping (mês)</div>
    <div class="k-value"><?= e(money($drop['lucro'], false)) ?><small><?= e(setting('moeda', 'Kz')) ?></small></div>
    <div class="k-note">Lucro de <?= num($drop['n']) ?> encomenda(s)<?= $pendingOrders ? ' · ' . num($pendingOrders) . ' em curso' : '' ?></div>
  </div>
</div>
<?php endif; ?>

<div class="grid g-main mb">
  <div class="card">
    <div class="card-head">
      <h2>Vendas <span class="muted" style="font-weight:400">(últimos <?= $days ?> dias)</span></h2>
      <div class="tabs" style="margin:0">
        <a class="tab<?= $days === 7 ? ' active' : '' ?>" href="dashboard.php">7 dias</a>
        <a class="tab<?= $days === 30 ? ' active' : '' ?>" href="dashboard.php?dias=30">30 dias</a>
      </div>
    </div>
    <div class="chart" data-chart="<?= e(json_encode($chart, JSON_UNESCAPED_UNICODE)) ?>" data-currency="<?= e(setting('moeda', 'Kz')) ?>"></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Produtos mais vendidos</h2><span class="muted">30 dias</span></div>
    <?php if (!$top): echo empty_state('Ainda sem vendas neste período.', 'cart'); else: ?>
      <div class="list">
        <?php foreach ($top as $t): ?>
          <div class="list-item">
            <div class="thumb"><?= icon('box', 18) ?></div>
            <div class="grow"><b><?= e($t['nome']) ?></b><span><?= e(money($t['val'])) ?></span></div>
            <div class="val"><?= num($t['qtd'], fmod((float) $t['qtd'], 1) ? 2 : 0) ?> un.</div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="grid g-main">
  <div class="card">
    <div class="card-head"><h2>Últimas vendas</h2><a href="vendas.php">Ver todas</a></div>
    <?php if (!$recent): echo empty_state('Ainda não há vendas registadas.', 'cart'); else: ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>Fatura</th><th>Cliente</th><th>Data</th><th class="num">Total</th><th>Estado</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $r): [$lbl, $cls] = sale_payment_state($r); ?>
        <tr>
          <td><a class="cell-main" href="venda_ver.php?id=<?= (int) $r['id'] ?>"><?= e($r['numero']) ?></a></td>
          <td><?= e($r['cliente'] ?? 'Consumidor final') ?></td>
          <td><?= e(fdate($r['data_venda'])) ?></td>
          <td class="num"><?= e(money($r['total'])) ?></td>
          <td><?= badge($lbl, $cls) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <div class="grid" style="align-content:start">
    <div class="card">
      <div class="card-head"><h2>Stock baixo</h2><a href="produtos.php?filtro=baixo">Ver todos</a></div>
      <?php if (!$low): echo empty_state('Nenhum produto abaixo do stock mínimo.', 'check'); else: ?>
        <div class="list">
          <?php foreach ($low as $p): ?>
            <a class="list-item" href="produtos.php?acao=editar&id=<?= (int) $p['id'] ?>" style="color:inherit;text-decoration:none">
              <div class="thumb" style="color:var(--warning);background:var(--warning-soft)"><?= icon('alert', 18) ?></div>
              <div class="grow"><b><?= e($p['nome']) ?></b><span>Mínimo: <?= num($p['stock_minimo']) ?></span></div>
              <div class="val" style="color:var(--warning)"><?= num($p['stock_atual']) ?> un.</div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($activity): ?>
    <div class="card">
      <div class="card-head"><h2>Atividade recente</h2></div>
      <div class="list">
        <?php foreach ($activity as $a): ?>
          <div class="list-item">
            <div class="thumb"><?= icon('user', 16) ?></div>
            <div class="grow"><b><?= e($a['nome'] ?? 'Sistema') ?></b><span><?= e($a['detalhe'] ?: $a['acao']) ?></span></div>
            <div class="muted" style="font-size:12px"><?= e(date('H:i', strtotime($a['criado_em']))) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php page_footer(); ?>
