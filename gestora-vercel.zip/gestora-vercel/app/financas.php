<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('financeiro');

$periodos = ['hoje' => 'Hoje', 'mes' => 'Este mês', 'mes_ant' => 'Mês anterior', 'ano' => 'Este ano'];
$per = array_key_exists(get('p'), $periodos) ? get('p') : 'mes';
[$from, $to] = period_range($per);

$vendas = sales_summary($from, $to);
$drop = dropship_summary($from, $to);
$desp = expenses_sum($from, $to);
$entradas = cash_in($from, $to);
$saidas = cash_out($from, $to);
$rec = receivables();
$pay = payables();

$receita = (float) $vendas['base'] + (float) $drop['receita'];
$custosMerc = (float) $vendas['cogs'] + (float) $drop['custos'];
$lucroBruto = $receita - $custosMerc;
$lucroLiq = $lucroBruto - $desp;
$margem = $receita > 0 ? $lucroLiq / $receita * 100 : 0;
$saldo = $entradas['total'] - $saidas['total'];

$despCat = fetch_all('SELECT categoria, SUM(valor) t FROM despesas WHERE data_despesa BETWEEN ? AND ? GROUP BY categoria ORDER BY t DESC', [$from, $to]);

// Evolução dos últimos 6 meses (vendas, dropshipping e despesas)
$labels = [];
$sVendas = [];
$sLucro = [];
for ($i = 5; $i >= 0; $i--) {
    $ini = date('Y-m-01', strtotime("first day of -$i month"));
    $fim = date('Y-m-t', strtotime($ini));
    $a = sales_summary($ini, $fim);
    $b = dropship_summary($ini, $fim);
    $labels[] = MONTHS_PT[(int) date('n', strtotime($ini)) - 1];
    $sVendas[] = round((float) $a['base'] + (float) $b['receita'], 2);
    $sLucro[] = round((float) $a['lucro'] + (float) $b['lucro'] - expenses_sum($ini, $fim), 2);
}
$chart = ['type' => 'bar', 'labels' => $labels, 'series' => [['name' => 'Receita', 'values' => $sVendas], ['name' => 'Lucro líquido', 'values' => $sLucro]]];

$tabs = '';
foreach ($periodos as $k => $l) {
    $tabs .= '<a class="tab' . ($per === $k ? ' active' : '') . '" href="financas.php?p=' . e($k) . '">' . e($l) . '</a>';
}
page_header('Finanças', 'financas', [
    'subtitle' => 'De ' . fdate($from) . ' a ' . fdate($to) . '. Receita sem IVA; lucro após custos e despesas.',
    'actions' => '<div class="tabs" style="margin:0">' . $tabs . '</div>',
]);
?>
<div class="grid g-4 mb">
  <div class="card kpi"><div class="k-ic"><?= icon('trend', 22) ?></div><div class="k-label">Receita</div><div class="k-value"><?= e(money($receita)) ?></div><div class="k-note">Vendas + dropshipping (sem IVA)</div></div>
  <div class="card kpi bad"><div class="k-ic"><?= icon('wallet', 22) ?></div><div class="k-label">Despesas</div><div class="k-value"><?= e(money($desp)) ?></div><div class="k-note"><a href="despesas.php?de=<?= e($from) ?>&ate=<?= e($to) ?>">Ver despesas</a></div></div>
  <div class="card kpi <?= $lucroLiq >= 0 ? 'good' : 'bad' ?>"><div class="k-ic"><?= icon('dollar', 22) ?></div><div class="k-label">Lucro líquido</div><div class="k-value"><?= e(money($lucroLiq)) ?></div><div class="k-note">Margem: <b><?= num($margem, 1) ?>%</b></div></div>
  <div class="card kpi <?= $saldo >= 0 ? 'good' : 'bad' ?>"><div class="k-ic"><?= icon('card', 22) ?></div><div class="k-label">Fluxo de caixa</div><div class="k-value"><?= e(money($saldo)) ?></div><div class="k-note">Entradas − saídas efetivas</div></div>
</div>

<div class="grid g-main mb">
  <div class="card">
    <div class="card-head"><h2>Evolução (6 meses)</h2><div class="legend"><span><i style="background:#0a8dff"></i>Receita</span><span><i style="background:var(--danger)"></i>Lucro líquido</span></div></div>
    <div class="chart" data-chart="<?= e(json_encode($chart, JSON_UNESCAPED_UNICODE)) ?>" data-currency="<?= e(setting('moeda', 'Kz')) ?>"></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Demonstração de resultados</h2></div>
    <div class="stat-row"><span>Receita de vendas (base)</span><b><?= e(money($vendas['base'])) ?></b></div>
    <div class="stat-row"><span>Receita de dropshipping</span><b><?= e(money($drop['receita'])) ?></b></div>
    <div class="stat-row"><span>Custo das mercadorias vendidas</span><b>− <?= e(money($vendas['cogs'])) ?></b></div>
    <div class="stat-row"><span>Custos de dropshipping</span><b>− <?= e(money($drop['custos'])) ?></b></div>
    <div class="stat-row"><span><b>Lucro bruto</b></span><b><?= e(money($lucroBruto)) ?></b></div>
    <div class="stat-row"><span>Despesas operacionais</span><b>− <?= e(money($desp)) ?></b></div>
    <div class="stat-row total"><span>Lucro líquido</span><b style="color:<?= $lucroLiq >= 0 ? 'var(--success)' : 'var(--danger)' ?>"><?= e(money($lucroLiq)) ?></b></div>
    <p class="muted" style="margin:10px 0 0;font-size:12px">IVA cobrado no período: <?= e(money($vendas['iva'])) ?> (não incluído na receita).</p>
  </div>
</div>

<div class="grid g-3">
  <div class="card">
    <div class="card-head"><h2>Caixa</h2></div>
    <div class="stat-row"><span>Recebido de faturas</span><b style="color:var(--success)">+ <?= e(money($entradas['vendas'])) ?></b></div>
    <div class="stat-row"><span>Recebido (dropshipping)</span><b style="color:var(--success)">+ <?= e(money($entradas['dropshipping'])) ?></b></div>
    <div class="stat-row"><span>Despesas pagas</span><b style="color:var(--danger)">− <?= e(money($saidas['despesas'])) ?></b></div>
    <div class="stat-row"><span>Pago a fornecedores (dropshipping)</span><b style="color:var(--danger)">− <?= e(money($saidas['dropshipping'])) ?></b></div>
    <div class="stat-row total"><span>Saldo do período</span><b><?= e(money($saldo)) ?></b></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Contas a receber e pagar</h2></div>
    <div class="stat-row"><span>Faturas em aberto (<?= num($rec['vendas_n']) ?>)</span><b><?= e(money($rec['vendas'])) ?></b></div>
    <div class="stat-row"><span>Encomendas por cobrar (<?= num($rec['drop_n']) ?>)</span><b><?= e(money($rec['drop'])) ?></b></div>
    <div class="stat-row"><span><b>Total a receber</b></span><b style="color:var(--warning)"><?= e(money($rec['total'])) ?></b></div>
    <div class="stat-row"><span>A pagar a fornecedores (<?= num($pay['n']) ?>)</span><b style="color:var(--danger)"><?= e(money($pay['total'])) ?></b></div>
    <p style="margin:12px 0 0"><a href="vendas.php?estado=pendente">Ver faturas em aberto</a> · <a href="encomendas.php?estado=curso">Encomendas</a></p>
  </div>
  <div class="card">
    <div class="card-head"><h2>Despesas por categoria</h2></div>
    <?php if (!$despCat): echo empty_state('Sem despesas neste período.', 'wallet'); else: foreach ($despCat as $c): ?>
      <div class="stat-row"><span><?= e($c['categoria']) ?></span><b><?= e(money($c['t'])) ?></b></div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php page_footer(); ?>
