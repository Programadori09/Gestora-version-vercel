<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('encomendas');
$acao = get('acao');

$estados = ['nova' => 'Nova', 'encomendada' => 'Encomendada ao fornecedor', 'enviada' => 'Enviada', 'entregue' => 'Entregue', 'cancelada' => 'Cancelada', 'devolvida' => 'Devolvida'];
$pagCli = ['pendente' => 'Pendente', 'pago' => 'Pago', 'reembolsado' => 'Reembolsado'];
$pagForn = ['pendente' => 'Pendente', 'pago' => 'Pago'];

if (is_post()) {
    csrf_verify();
    $op = post('op');

    if ($op === 'guardar') {
        $id = (int) post('id');
        $data = post('data_encomenda', date('Y-m-d'));
        $cliente = post('cliente_nome');
        $prodNome = post('produto_nome');
        $pid = opt_null(post('produto_id'));
        $qtd = max(1, (int) post('quantidade'));
        $precoV = parse_decimal(post('preco_venda'));
        $custo = parse_decimal(post('custo_fornecedor'));
        $envio = parse_decimal(post('custo_envio'));
        $taxas = parse_decimal(post('taxas'));
        $estado = array_key_exists(post('estado'), $estados) ? post('estado') : 'nova';
        $pc = array_key_exists(post('pagamento_cliente'), $pagCli) ? post('pagamento_cliente') : 'pendente';
        $pf = array_key_exists(post('pagamento_fornecedor'), $pagForn) ? post('pagamento_fornecedor') : 'pendente';

        $err = '';
        if ($cliente === '' || $prodNome === '') {
            $err = 'Indica o nome do cliente e o produto.';
        } elseif (!valid_date($data)) {
            $err = 'Data inválida.';
        } elseif ($precoV < 0 || $custo < 0 || $envio < 0 || $taxas < 0) {
            $err = 'Os valores não podem ser negativos.';
        }
        if ($err) {
            flash('error', $err);
            redirect($id ? 'encomendas.php?acao=editar&id=' . $id : 'encomendas.php?acao=novo');
        }
        $vals = [
            $data, str_or_null(post('loja_origem')), opt_null(post('cliente_id')), $cliente, str_or_null(post('cliente_contacto')),
            str_or_null(post('endereco_entrega')), $pid, $prodNome, opt_null(post('fornecedor_id')), $qtd, $precoV, $custo, $envio, $taxas,
            $estado, $pc, $pf, str_or_null(post('rastreio')), str_or_null(post('notas')),
        ];
        if ($id) {
            q('UPDATE encomendas SET data_encomenda=?, loja_origem=?, cliente_id=?, cliente_nome=?, cliente_contacto=?, endereco_entrega=?, produto_id=?, produto_nome=?, fornecedor_id=?, quantidade=?, preco_venda=?, custo_fornecedor=?, custo_envio=?, taxas=?, estado=?, pagamento_cliente=?, pagamento_fornecedor=?, rastreio=?, notas=? WHERE id=?', array_merge($vals, [$id]));
            flash('success', 'Encomenda atualizada.');
        } else {
            $ref = next_number('ENC', 'encomendas', 'referencia');
            q('INSERT INTO encomendas (data_encomenda, loja_origem, cliente_id, cliente_nome, cliente_contacto, endereco_entrega, produto_id, produto_nome, fornecedor_id, quantidade, preco_venda, custo_fornecedor, custo_envio, taxas, estado, pagamento_cliente, pagamento_fornecedor, rastreio, notas, referencia, utilizador_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', array_merge($vals, [$ref, $user['id']]));
            flash('success', 'Encomenda ' . $ref . ' registada.');
        }
        log_activity('encomenda_guardada', $cliente . ' · ' . $prodNome);
        redirect('encomendas.php');
    }

    if ($op === 'estado') {
        $id = (int) post('id');
        $novo = post('estado');
        if (array_key_exists($novo, $estados)) {
            q('UPDATE encomendas SET estado = ? WHERE id = ?', [$novo, $id]);
            if ($novo === 'devolvida') {
                q("UPDATE encomendas SET pagamento_cliente = 'reembolsado' WHERE id = ? AND pagamento_cliente = 'pago'", [$id]);
            }
            flash('success', 'Estado atualizado.');
        }
        redirect('encomendas.php' . (post('voltar') !== '' ? '?' . post('voltar') : ''));
    }

    if ($op === 'pagamento') {
        $id = (int) post('id');
        $campo = post('campo') === 'fornecedor' ? 'pagamento_fornecedor' : 'pagamento_cliente';
        q("UPDATE encomendas SET $campo = 'pago' WHERE id = ?", [$id]);
        flash('success', 'Pagamento marcado como recebido/efetuado.');
        redirect('encomendas.php' . (post('voltar') !== '' ? '?' . post('voltar') : ''));
    }

    if ($op === 'eliminar') {
        if (!in_array($user['perfil'], ['admin', 'gestor'], true)) {
            http_response_code(403);
            exit('Sem permissão.');
        }
        q('DELETE FROM encomendas WHERE id = ?', [(int) post('id')]);
        flash('success', 'Encomenda eliminada.');
        redirect('encomendas.php');
    }
}

$forns = fetch_all('SELECT id, nome FROM fornecedores WHERE ativo = 1 ORDER BY nome');
$clientes = fetch_all('SELECT id, nome FROM clientes WHERE ativo = 1 ORDER BY nome');
$produtos = fetch_all("SELECT id, nome, fornecedor_id, preco_custo, preco_venda FROM produtos WHERE ativo = 1 AND tipo = 'dropshipping' ORDER BY nome");

/* ---------- Formulário ---------- */
if ($acao === 'novo' || $acao === 'editar') {
    $o = [
        'id' => 0, 'data_encomenda' => date('Y-m-d'), 'loja_origem' => '', 'cliente_id' => '', 'cliente_nome' => '', 'cliente_contacto' => '', 'endereco_entrega' => '',
        'produto_id' => '', 'produto_nome' => '', 'fornecedor_id' => '', 'quantidade' => 1, 'preco_venda' => '', 'custo_fornecedor' => '', 'custo_envio' => '', 'taxas' => '',
        'estado' => 'nova', 'pagamento_cliente' => 'pendente', 'pagamento_fornecedor' => 'pendente', 'rastreio' => '', 'notas' => '', 'referencia' => '',
    ];
    if ($acao === 'editar') {
        $row = fetch_one('SELECT * FROM encomendas WHERE id = ?', [(int) get('id')]);
        if (!$row) {
            flash('error', 'Encomenda não encontrada.');
            redirect('encomendas.php');
        }
        $o = $row;
    }
    $dec = static fn($v) => $v === '' ? '' : (float) $v;
    page_header($o['id'] ? 'Encomenda ' . $o['referencia'] : 'Nova encomenda', 'encomendas', ['actions' => '<a class="btn" href="encomendas.php">Voltar</a>']);
    ?>
    <form class="card" method="post" data-once id="ordForm">
      <?= csrf_field() ?><input type="hidden" name="op" value="guardar"><input type="hidden" name="id" value="<?= (int) $o['id'] ?>">
      <div class="form-grid">
        <div class="field col-3"><label for="data_encomenda">Data</label><input type="date" id="data_encomenda" name="data_encomenda" value="<?= e($o['data_encomenda']) ?>" required></div>
        <div class="field col-3"><label for="loja_origem">Loja / canal de origem</label><input type="text" id="loja_origem" name="loja_origem" value="<?= e($o['loja_origem']) ?>" placeholder="Ex.: Instagram, Shopify…" maxlength="80"></div>
        <div class="field col-3"><label for="estado">Estado</label><select id="estado" name="estado"><?php foreach ($estados as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($o['estado'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="field col-3"><label for="rastreio">Código de rastreio</label><input type="text" id="rastreio" name="rastreio" value="<?= e($o['rastreio']) ?>" maxlength="80"></div>

        <div class="field col-4"><label class="required" for="cliente_nome">Cliente</label><input type="text" id="cliente_nome" name="cliente_nome" value="<?= e($o['cliente_nome']) ?>" required maxlength="140" list="cliList"></div>
        <div class="field col-4"><label for="cliente_contacto">Contacto</label><input type="text" id="cliente_contacto" name="cliente_contacto" value="<?= e($o['cliente_contacto']) ?>" maxlength="80"></div>
        <div class="field col-4"><label for="cliente_id">Ligar a cliente existente</label><select id="cliente_id" name="cliente_id"><option value="">—</option><?php foreach ($clientes as $c): ?><option value="<?= (int) $c['id'] ?>" data-nome="<?= e($c['nome']) ?>"<?= sel($o['cliente_id'], $c['id']) ?>><?= e($c['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="field col-12"><label for="endereco_entrega">Morada de entrega</label><input type="text" id="endereco_entrega" name="endereco_entrega" value="<?= e($o['endereco_entrega']) ?>" maxlength="255"></div>

        <div class="field col-6"><label class="required" for="produto_nome">Produto</label><input type="text" id="produto_nome" name="produto_nome" value="<?= e($o['produto_nome']) ?>" required maxlength="200"></div>
        <div class="field col-3"><label for="produto_id">Produto do catálogo</label>
          <select id="produto_id" name="produto_id"><option value="">—</option>
            <?php foreach ($produtos as $p): ?><option value="<?= (int) $p['id'] ?>" data-nome="<?= e($p['nome']) ?>" data-forn="<?= (int) $p['fornecedor_id'] ?>" data-custo="<?= (float) $p['preco_custo'] ?>" data-venda="<?= (float) $p['preco_venda'] ?>"<?= sel($o['produto_id'], $p['id']) ?>><?= e($p['nome']) ?></option><?php endforeach; ?>
          </select><span class="hint">Preenche preços e fornecedor.</span></div>
        <div class="field col-3"><label for="fornecedor_id">Fornecedor</label><select id="fornecedor_id" name="fornecedor_id"><option value="">—</option><?php foreach ($forns as $f): ?><option value="<?= (int) $f['id'] ?>"<?= sel($o['fornecedor_id'], $f['id']) ?>><?= e($f['nome']) ?></option><?php endforeach; ?></select></div>

        <div class="field col-2"><label for="quantidade">Qtd.</label><input type="number" min="1" id="quantidade" name="quantidade" value="<?= (int) $o['quantidade'] ?>"></div>
        <div class="field col-3"><label for="preco_venda">Preço de venda (unit.)</label><input type="text" inputmode="decimal" id="preco_venda" name="preco_venda" value="<?= e($dec($o['preco_venda'])) ?>"></div>
        <div class="field col-3"><label for="custo_fornecedor">Custo no fornecedor (unit.)</label><input type="text" inputmode="decimal" id="custo_fornecedor" name="custo_fornecedor" value="<?= e($dec($o['custo_fornecedor'])) ?>"></div>
        <div class="field col-2"><label for="custo_envio">Envio</label><input type="text" inputmode="decimal" id="custo_envio" name="custo_envio" value="<?= e($dec($o['custo_envio'])) ?>"></div>
        <div class="field col-2"><label for="taxas">Taxas</label><input type="text" inputmode="decimal" id="taxas" name="taxas" value="<?= e($dec($o['taxas'])) ?>"></div>

        <div class="field col-4"><label for="pagamento_cliente">Pagamento do cliente</label><select id="pagamento_cliente" name="pagamento_cliente"><?php foreach ($pagCli as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($o['pagamento_cliente'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="field col-4"><label for="pagamento_fornecedor">Pagamento ao fornecedor</label><select id="pagamento_fornecedor" name="pagamento_fornecedor"><?php foreach ($pagForn as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($o['pagamento_fornecedor'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
        <div class="col-4"><div class="summary-box" style="margin-top:22px"><div class="stat-row total" style="margin:0;border:0;padding:0"><span>Lucro estimado</span><b id="lucro">0</b></div></div></div>

        <div class="field col-12"><label for="notas">Notas</label><textarea id="notas" name="notas" style="min-height:70px"><?= e($o['notas']) ?></textarea></div>
      </div>
      <div class="form-actions"><a class="btn" href="encomendas.php">Cancelar</a><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar</button></div>
    </form>
    <script>
    (function(){
      var f=document.getElementById('ordForm'),cur=<?= json_encode(setting('moeda', 'Kz')) ?>;
      function d(s){s=String(s||'').replace(/\s/g,'');if(s.indexOf(',')>-1&&s.indexOf('.')>-1)s=s.replace(/\./g,'').replace(',','.');else if(s.indexOf(',')>-1)s=s.replace(',','.');var n=parseFloat(s);return isFinite(n)?n:0;}
      function calc(){var q=Math.max(1,parseInt(f.quantidade.value,10)||1);var l=(d(f.preco_venda.value)-d(f.custo_fornecedor.value))*q-d(f.custo_envio.value)-d(f.taxas.value);
        var el=document.getElementById('lucro');el.textContent=GT.fmt(Math.round(l*100)/100,cur);el.style.color=l<0?'var(--danger)':'var(--success)';}
      f.addEventListener('input',calc);calc();
      f.produto_id.addEventListener('change',function(){var o=this.options[this.selectedIndex];if(!o.value)return;
        f.produto_nome.value=o.dataset.nome;f.preco_venda.value=o.dataset.venda;f.custo_fornecedor.value=o.dataset.custo;if(o.dataset.forn&&o.dataset.forn!=='0')f.fornecedor_id.value=o.dataset.forn;calc();});
      f.cliente_id.addEventListener('change',function(){var o=this.options[this.selectedIndex];if(o.value&&!f.cliente_nome.value)f.cliente_nome.value=o.dataset.nome;});
    })();
    </script>
    <?php
    page_footer();
    exit;
}

/* ---------- Listagem ---------- */
$qText = get('q');
$estF = get('estado');
$where = ['1=1'];
$params = [];
if ($qText !== '') {
    $where[] = '(e.referencia LIKE ? OR e.cliente_nome LIKE ? OR e.produto_nome LIKE ? OR e.rastreio LIKE ?)';
    $params = array_merge($params, array_fill(0, 4, '%' . $qText . '%'));
}
if ($estF === 'curso') {
    $where[] = "e.estado IN ('nova','encomendada','enviada')";
} elseif (array_key_exists($estF, $estados)) {
    $where[] = 'e.estado = ?';
    $params[] = $estF;
}
$W = implode(' AND ', $where);
$pg = paginate((int) fetch_val("SELECT COUNT(*) FROM encomendas e WHERE $W", $params), 15);
$rows = fetch_all("SELECT e.*, f.nome fornecedor FROM encomendas e LEFT JOIN fornecedores f ON f.id = e.fornecedor_id WHERE $W ORDER BY e.data_encomenda DESC, e.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params);

[$mF, $mT] = period_range('mes');
$ds = dropship_summary($mF, $mT);
$pay = payables();
$rec = receivables();
$emCurso = (int) fetch_val("SELECT COUNT(*) FROM encomendas WHERE estado IN ('nova','encomendada','enviada')");
$voltar = ltrim(qs(), '?');

page_header('Dropshipping', 'encomendas', [
    'subtitle' => 'Encomendas, pagamentos a fornecedores e lucro por pedido, sem precisares de stock.',
    'actions' => '<a class="btn btn-primary" href="encomendas.php?acao=novo">' . icon('plus', 18) . ' Nova encomenda</a>',
]);
?>
<div class="grid g-4 mb">
  <div class="card kpi"><div class="k-ic"><?= icon('cube', 22) ?></div><div class="k-label">Encomendas em curso</div><div class="k-value"><?= num($emCurso) ?></div><div class="k-note"><a href="encomendas.php?estado=curso">Ver em curso</a></div></div>
  <div class="card kpi good"><div class="k-ic"><?= icon('trend', 22) ?></div><div class="k-label">Lucro (mês)</div><div class="k-value"><?= e(money($ds['lucro'])) ?></div><div class="k-note"><?= num($ds['n']) ?> encomenda(s) válidas</div></div>
  <div class="card kpi warn"><div class="k-ic"><?= icon('wallet', 22) ?></div><div class="k-label">Por cobrar a clientes</div><div class="k-value"><?= e(money($rec['drop'])) ?></div><div class="k-note"><?= num($rec['drop_n']) ?> encomenda(s)</div></div>
  <div class="card kpi bad"><div class="k-ic"><?= icon('truck', 22) ?></div><div class="k-label">Por pagar a fornecedores</div><div class="k-value"><?= e(money($pay['total'])) ?></div><div class="k-note"><?= num($pay['n']) ?> encomenda(s)</div></div>
</div>

<div class="card">
  <form class="filters" method="get">
    <input type="search" name="q" value="<?= e($qText) ?>" placeholder="Referência, cliente, produto ou rastreio…" aria-label="Pesquisar">
    <select name="estado" aria-label="Estado"><option value="">Todos os estados</option><option value="curso"<?= sel($estF, 'curso') ?>>Em curso</option>
      <?php foreach ($estados as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($estF, $k) ?>><?= e($l) ?></option><?php endforeach; ?></select>
    <button class="btn" type="submit"><?= icon('search', 16) ?> Filtrar</button>
    <?php if ($qText !== '' || $estF !== ''): ?><a class="btn btn-sm" href="encomendas.php">Limpar</a><?php endif; ?>
  </form>
  <?php if (!$rows): echo empty_state('Nenhuma encomenda encontrada.', 'cube'); else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Encomenda</th><th>Cliente / produto</th><th>Estado</th><th>Pagamentos</th><th class="num">Lucro</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): $lucro = order_profit($r); $fora = in_array($r['estado'], ['cancelada', 'devolvida'], true); ?>
      <tr<?= $fora ? ' style="opacity:.65"' : '' ?>>
        <td><a class="cell-main" href="encomendas.php?acao=editar&id=<?= (int) $r['id'] ?>"><?= e($r['referencia']) ?></a><span class="cell-sub"><?= e(fdate($r['data_encomenda'])) ?><?= $r['loja_origem'] ? ' · ' . e($r['loja_origem']) : '' ?></span></td>
        <td><span class="cell-main"><?= e($r['cliente_nome']) ?></span><span class="cell-sub"><?= e($r['produto_nome']) ?> × <?= (int) $r['quantidade'] ?> · <?= e(money((float) $r['preco_venda'] * (int) $r['quantidade'])) ?></span></td>
        <td>
          <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="op" value="estado"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="voltar" value="<?= e($voltar) ?>">
            <select name="estado" onchange="this.form.submit()" aria-label="Estado da encomenda" style="height:34px;min-width:150px;font-size:13px"><?php foreach ($estados as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($r['estado'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select>
          </form>
          <?php if ($r['rastreio']): ?><span class="cell-sub">Rastreio: <?= e($r['rastreio']) ?></span><?php endif; ?>
        </td>
        <td>
          <span class="cell-sub" style="display:flex;gap:6px;align-items:center;margin:0 0 4px">Cliente: <?= badge($pagCli[$r['pagamento_cliente']], $r['pagamento_cliente'] === 'pago' ? 'success' : ($r['pagamento_cliente'] === 'pendente' ? 'warning' : 'danger')) ?>
            <?php if ($r['pagamento_cliente'] === 'pendente' && !$fora): ?><form class="inline-form" method="post"><?= csrf_field() ?><input type="hidden" name="op" value="pagamento"><input type="hidden" name="campo" value="cliente"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="voltar" value="<?= e($voltar) ?>"><button class="btn btn-sm btn-icon btn-success" title="Marcar como recebido" type="submit" style="height:26px;width:26px"><?= icon('check', 14) ?></button></form><?php endif; ?></span>
          <span class="cell-sub" style="display:flex;gap:6px;align-items:center;margin:0">Fornecedor: <?= badge($pagForn[$r['pagamento_fornecedor']], $r['pagamento_fornecedor'] === 'pago' ? 'success' : 'warning') ?>
            <?php if ($r['pagamento_fornecedor'] === 'pendente' && !$fora): ?><form class="inline-form" method="post"><?= csrf_field() ?><input type="hidden" name="op" value="pagamento"><input type="hidden" name="campo" value="fornecedor"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="voltar" value="<?= e($voltar) ?>"><button class="btn btn-sm btn-icon btn-success" title="Marcar como pago" type="submit" style="height:26px;width:26px"><?= icon('check', 14) ?></button></form><?php endif; ?></span>
        </td>
        <td class="num" style="font-weight:600;color:<?= $fora ? 'var(--muted)' : ($lucro < 0 ? 'var(--danger)' : 'var(--success)') ?>"><?= $fora ? '—' : e(money($lucro)) ?></td>
        <td><div class="row-actions">
          <a class="btn btn-sm btn-icon" title="Editar" href="encomendas.php?acao=editar&id=<?= (int) $r['id'] ?>"><?= icon('edit', 16) ?></a>
          <?php if (in_array($user['perfil'], ['admin', 'gestor'], true)): ?>
          <form class="inline-form" method="post" data-confirm="Eliminar esta encomenda?"><?= csrf_field() ?><input type="hidden" name="op" value="eliminar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-icon btn-danger" title="Eliminar" type="submit"><?= icon('trash', 16) ?></button></form>
          <?php endif; ?>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= pagination_html($pg) ?>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
