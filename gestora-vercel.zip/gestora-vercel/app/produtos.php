<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('produtos');
$canEdit = can('produtos_edit');
$acao = get('acao');

$tipos = ['stock' => 'Em stock', 'dropshipping' => 'Dropshipping', 'servico' => 'Serviço'];

/* ---------- Ações POST ---------- */
if (is_post()) {
    csrf_verify();
    if (!$canEdit) {
        http_response_code(403);
        exit('Sem permissão.');
    }
    $op = post('op');

    if ($op === 'guardar') {
        $id = (int) post('id');
        $nome = post('nome');
        $tipo = array_key_exists(post('tipo'), $tipos) ? post('tipo') : 'stock';
        $codigo = str_or_null(post('codigo'));
        $custo = parse_decimal(post('preco_custo'));
        $venda = parse_decimal(post('preco_venda'));
        $min = max(0, (int) post('stock_minimo'));
        $err = '';
        if ($nome === '') {
            $err = 'O nome do produto é obrigatório.';
        } elseif ($custo < 0 || $venda < 0) {
            $err = 'Os preços não podem ser negativos.';
        } elseif ($codigo !== null && fetch_val('SELECT id FROM produtos WHERE codigo = ? AND id <> ?', [$codigo, $id])) {
            $err = 'Já existe um produto com esse código.';
        }
        if ($err) {
            flash('error', $err);
            redirect($id ? 'produtos.php?acao=editar&id=' . $id : 'produtos.php?acao=novo');
        }
        $params = [
            $codigo, $nome, opt_null(post('categoria_id')), opt_null(post('fornecedor_id')), $tipo, $custo, $venda, $min,
            str_or_null(post('unidade', 'un')) ?? 'un', str_or_null(post('descricao')), post('ativo') === '1' ? 1 : 0,
        ];
        if ($id) {
            q('UPDATE produtos SET codigo=?, nome=?, categoria_id=?, fornecedor_id=?, tipo=?, preco_custo=?, preco_venda=?, stock_minimo=?, unidade=?, descricao=?, ativo=? WHERE id=?', array_merge($params, [$id]));
            log_activity('produto_editado', $nome);
            flash('success', 'Produto atualizado.');
        } else {
            q('INSERT INTO produtos (codigo, nome, categoria_id, fornecedor_id, tipo, preco_custo, preco_venda, stock_minimo, unidade, descricao, ativo) VALUES (?,?,?,?,?,?,?,?,?,?,?)', $params);
            $id = last_id();
            $ini = (int) post('stock_inicial');
            if ($tipo === 'stock' && $ini > 0) {
                $pdo = db();
                $pdo->beginTransaction();
                try {
                    stock_move($id, 'entrada', $ini, 'Stock inicial');
                    $pdo->commit();
                } catch (Throwable $e) {
                    $pdo->rollBack();
                    throw $e;
                }
            }
            log_activity('produto_criado', $nome);
            flash('success', 'Produto criado.');
        }
        redirect('produtos.php');
    }

    if ($op === 'movimento') {
        $id = (int) post('id');
        $tipoMov = post('tipo_mov');
        $qtd = (int) post('quantidade');
        $motivo = post('motivo');
        $p = fetch_one('SELECT id, nome, tipo, stock_atual FROM produtos WHERE id = ?', [$id]);
        if (!$p || $p['tipo'] !== 'stock') {
            flash('error', 'Só é possível movimentar stock de produtos do tipo "Em stock".');
        } elseif (!in_array($tipoMov, ['entrada', 'saida', 'ajuste'], true) || ($tipoMov === 'ajuste' ? $qtd < 0 : $qtd <= 0)) {
            flash('error', 'Indica uma quantidade válida.');
        } elseif ($tipoMov === 'saida' && $qtd > (int) $p['stock_atual']) {
            flash('error', 'Saída superior ao stock disponível (' . (int) $p['stock_atual'] . ').');
        } else {
            $pdo = db();
            $pdo->beginTransaction();
            try {
                stock_move($id, $tipoMov, $qtd, $motivo !== '' ? $motivo : ucfirst($tipoMov) . ' manual');
                $pdo->commit();
                log_activity('stock_movimento', $p['nome'] . ' (' . $tipoMov . ' ' . $qtd . ')');
                flash('success', 'Movimento de stock registado.');
            } catch (Throwable $e) {
                $pdo->rollBack();
                flash('error', 'Não foi possível registar o movimento.');
            }
        }
        redirect('produtos.php?acao=stock&id=' . $id);
    }

    if ($op === 'eliminar') {
        $id = (int) post('id');
        $usado = (int) fetch_val('SELECT COUNT(*) FROM venda_itens WHERE produto_id = ?', [$id])
               + (int) fetch_val('SELECT COUNT(*) FROM encomendas WHERE produto_id = ?', [$id]);
        if ($usado > 0) {
            q('UPDATE produtos SET ativo = 0 WHERE id = ?', [$id]);
            flash('warning', 'Este produto tem vendas associadas, por isso foi apenas desativado.');
        } else {
            q('DELETE FROM produtos WHERE id = ?', [$id]);
            flash('success', 'Produto eliminado.');
        }
        log_activity('produto_removido', '#' . $id);
        redirect('produtos.php');
    }
}

$cats = fetch_all('SELECT id, nome FROM categorias ORDER BY nome');
$forns = fetch_all('SELECT id, nome FROM fornecedores WHERE ativo = 1 ORDER BY nome');

/* ---------- Formulário (novo / editar) ---------- */
if ($acao === 'novo' || $acao === 'editar') {
    if (!$canEdit) {
        require_area('produtos_edit');
    }
    $p = ['id' => 0, 'codigo' => '', 'nome' => '', 'categoria_id' => '', 'fornecedor_id' => '', 'tipo' => 'stock', 'preco_custo' => '', 'preco_venda' => '', 'stock_minimo' => 0, 'unidade' => 'un', 'descricao' => '', 'ativo' => 1];
    if ($acao === 'editar') {
        $row = fetch_one('SELECT * FROM produtos WHERE id = ?', [(int) get('id')]);
        if (!$row) {
            flash('error', 'Produto não encontrado.');
            redirect('produtos.php');
        }
        $p = $row;
    }
    page_header($p['id'] ? 'Editar produto' : 'Novo produto', 'produtos', ['actions' => '<a class="btn" href="produtos.php">Voltar</a>']);
    ?>
    <form class="card" method="post" data-once>
      <?= csrf_field() ?>
      <input type="hidden" name="op" value="guardar"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
      <div class="form-grid">
        <div class="field col-8"><label class="required" for="nome">Nome</label><input type="text" id="nome" name="nome" value="<?= e($p['nome']) ?>" required maxlength="160"></div>
        <div class="field col-4"><label for="codigo">Código / SKU</label><input type="text" id="codigo" name="codigo" value="<?= e($p['codigo']) ?>" maxlength="40"></div>
        <div class="field col-4"><label for="tipo">Tipo</label>
          <select id="tipo" name="tipo"><?php foreach ($tipos as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($p['tipo'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select>
          <span class="hint">Dropshipping e serviços não controlam stock.</span></div>
        <div class="field col-4"><label for="categoria_id">Categoria</label>
          <select id="categoria_id" name="categoria_id"><option value="">—</option><?php foreach ($cats as $c): ?><option value="<?= (int) $c['id'] ?>"<?= sel($p['categoria_id'], $c['id']) ?>><?= e($c['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="field col-4"><label for="fornecedor_id">Fornecedor</label>
          <select id="fornecedor_id" name="fornecedor_id"><option value="">—</option><?php foreach ($forns as $f): ?><option value="<?= (int) $f['id'] ?>"<?= sel($p['fornecedor_id'], $f['id']) ?>><?= e($f['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="field col-3"><label for="preco_custo">Preço de custo</label><input type="text" inputmode="decimal" id="preco_custo" name="preco_custo" value="<?= e($p['preco_custo'] === '' ? '' : (float) $p['preco_custo']) ?>" placeholder="0"></div>
        <div class="field col-3"><label for="preco_venda">Preço de venda</label><input type="text" inputmode="decimal" id="preco_venda" name="preco_venda" value="<?= e($p['preco_venda'] === '' ? '' : (float) $p['preco_venda']) ?>" placeholder="0"></div>
        <div class="field col-3"><label for="stock_minimo">Stock mínimo (alerta)</label><input type="number" min="0" id="stock_minimo" name="stock_minimo" value="<?= (int) $p['stock_minimo'] ?>"></div>
        <div class="field col-3"><label for="unidade">Unidade</label><input type="text" id="unidade" name="unidade" value="<?= e($p['unidade']) ?>" maxlength="20"></div>
        <?php if (!$p['id']): ?>
        <div class="field col-3" id="iniWrap"><label for="stock_inicial">Stock inicial</label><input type="number" min="0" id="stock_inicial" name="stock_inicial" value="0"></div>
        <?php endif; ?>
        <div class="field col-12"><label for="descricao">Descrição</label><textarea id="descricao" name="descricao"><?= e($p['descricao']) ?></textarea></div>
        <div class="col-12"><label class="check"><input type="checkbox" name="ativo" value="1"<?= chk((int) $p['ativo'] === 1) ?>> Produto ativo (disponível para venda)</label></div>
      </div>
      <div class="form-actions"><a class="btn" href="produtos.php">Cancelar</a><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar</button></div>
    </form>
    <script>
    (function(){var t=document.getElementById('tipo'),w=document.getElementById('iniWrap');if(!t||!w)return;
    function s(){w.style.display=t.value==='stock'?'':'none';}t.addEventListener('change',s);s();})();
    </script>
    <?php
    page_footer();
    exit;
}

/* ---------- Movimentos de stock de um produto ---------- */
if ($acao === 'stock') {
    $p = fetch_one('SELECT p.*, c.nome categoria FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE p.id = ?', [(int) get('id')]);
    if (!$p) {
        redirect('produtos.php');
    }
    $movs = fetch_all('SELECT m.*, u.nome utilizador FROM movimentos_stock m LEFT JOIN utilizadores u ON u.id = m.utilizador_id WHERE m.produto_id = ? ORDER BY m.id DESC LIMIT 100', [$p['id']]);
    page_header('Stock: ' . $p['nome'], 'produtos', ['actions' => '<a class="btn" href="produtos.php">Voltar</a>']);
    ?>
    <div class="grid g-main">
      <div class="card">
        <div class="card-head"><h2>Histórico de movimentos</h2><span class="muted">Últimos 100</span></div>
        <?php if (!$movs): echo empty_state('Sem movimentos registados.', 'box'); else: ?>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>Data</th><th>Tipo</th><th class="num">Qtd.</th><th class="num">Stock após</th><th>Motivo</th><th>Por</th></tr></thead>
          <tbody>
          <?php foreach ($movs as $m): $cls = $m['tipo'] === 'entrada' ? 'success' : ($m['tipo'] === 'saida' ? 'danger' : 'info'); ?>
            <tr><td class="nowrap"><?= e(fdatetime($m['criado_em'])) ?></td><td><?= badge(ucfirst($m['tipo']), $cls) ?></td>
              <td class="num"><?= ((int) $m['quantidade'] > 0 ? '+' : '') . num($m['quantidade']) ?></td><td class="num"><?= num($m['stock_apos']) ?></td>
              <td><?= e($m['motivo'] ?? '') ?></td><td><?= e($m['utilizador'] ?? '—') ?></td></tr>
          <?php endforeach; ?>
          </tbody></table></div>
        <?php endif; ?>
      </div>
      <div class="grid" style="align-content:start">
        <div class="card kpi">
          <div class="k-label">Stock atual</div>
          <div class="k-value"><?= num($p['stock_atual']) ?><small><?= e($p['unidade']) ?></small></div>
          <div class="k-note">Mínimo: <?= num($p['stock_minimo']) ?><?= (int) $p['stock_atual'] <= (int) $p['stock_minimo'] ? ' · ' . badge('Stock baixo', 'warning') : '' ?></div>
        </div>
        <?php if ($canEdit && $p['tipo'] === 'stock'): ?>
        <form class="card" method="post" data-once>
          <?= csrf_field() ?><input type="hidden" name="op" value="movimento"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
          <div class="card-head"><h2>Novo movimento</h2></div>
          <div class="form-grid">
            <div class="field col-12"><label for="tipo_mov">Tipo</label>
              <select id="tipo_mov" name="tipo_mov"><option value="entrada">Entrada (compra / reposição)</option><option value="saida">Saída (perda, uso interno)</option><option value="ajuste">Ajuste (definir stock exato)</option></select></div>
            <div class="field col-12"><label for="quantidade">Quantidade</label><input type="number" min="0" id="quantidade" name="quantidade" required></div>
            <div class="field col-12"><label for="motivo">Motivo</label><input type="text" id="motivo" name="motivo" maxlength="160" placeholder="Ex.: Reposição do fornecedor"></div>
          </div>
          <div class="form-actions"><button class="btn btn-primary" type="submit">Registar</button></div>
        </form>
        <?php endif; ?>
      </div>
    </div>
    <?php
    page_footer();
    exit;
}

/* ---------- Listagem ---------- */
$qText = get('q');
$filtro = get('filtro');
$catF = (int) get('cat');
$where = ['1=1'];
$params = [];
if ($qText !== '') {
    $where[] = '(p.nome LIKE ? OR p.codigo LIKE ?)';
    $params[] = '%' . $qText . '%';
    $params[] = '%' . $qText . '%';
}
if ($catF) {
    $where[] = 'p.categoria_id = ?';
    $params[] = $catF;
}
if ($filtro === 'baixo') {
    $where[] = "p.ativo = 1 AND p.tipo = 'stock' AND p.stock_atual <= p.stock_minimo";
} elseif ($filtro === 'inativos') {
    $where[] = 'p.ativo = 0';
} elseif (isset($tipos[$filtro])) {
    $where[] = 'p.tipo = ?';
    $params[] = $filtro;
}
$W = implode(' AND ', $where);
$pg = paginate((int) fetch_val("SELECT COUNT(*) FROM produtos p WHERE $W", $params), 15);
$rows = fetch_all(
    "SELECT p.*, c.nome categoria FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id WHERE $W ORDER BY p.nome LIMIT {$pg['per']} OFFSET {$pg['offset']}",
    $params
);
$valorStock = (float) fetch_val("SELECT COALESCE(SUM(stock_atual * preco_custo),0) FROM produtos WHERE ativo = 1 AND tipo = 'stock'");
$valorVenda = (float) fetch_val("SELECT COALESCE(SUM(stock_atual * preco_venda),0) FROM produtos WHERE ativo = 1 AND tipo = 'stock'");

page_header('Produtos e stock', 'produtos', [
    'subtitle' => 'Catálogo, preços e controlo de inventário.',
    'actions' => $canEdit ? '<a class="btn btn-primary" href="produtos.php?acao=novo">' . icon('plus', 18) . ' Novo produto</a>' : '',
]);
?>
<div class="grid g-3 mb">
  <div class="card kpi"><div class="k-ic"><?= icon('box', 22) ?></div><div class="k-label">Valor do stock (a custo)</div><div class="k-value"><?= e(money($valorStock)) ?></div></div>
  <div class="card kpi good"><div class="k-ic"><?= icon('tag', 22) ?></div><div class="k-label">Valor do stock (a preço de venda)</div><div class="k-value"><?= e(money($valorVenda)) ?></div></div>
  <div class="card kpi warn"><div class="k-ic"><?= icon('alert', 22) ?></div><div class="k-label">Produtos com stock baixo</div>
    <div class="k-value"><?= num((int) fetch_val("SELECT COUNT(*) FROM produtos WHERE ativo = 1 AND tipo = 'stock' AND stock_atual <= stock_minimo")) ?></div>
    <div class="k-note"><a href="produtos.php?filtro=baixo">Ver lista</a></div></div>
</div>

<div class="card">
  <form class="filters" method="get">
    <input type="search" name="q" value="<?= e($qText) ?>" placeholder="Pesquisar por nome ou código…" aria-label="Pesquisar">
    <select name="cat" aria-label="Categoria"><option value="">Todas as categorias</option><?php foreach ($cats as $c): ?><option value="<?= (int) $c['id'] ?>"<?= sel($catF, $c['id']) ?>><?= e($c['nome']) ?></option><?php endforeach; ?></select>
    <select name="filtro" aria-label="Filtro">
      <option value="">Todos</option><option value="baixo"<?= sel($filtro, 'baixo') ?>>Stock baixo</option>
      <?php foreach ($tipos as $k => $l): ?><option value="<?= e($k) ?>"<?= sel($filtro, $k) ?>><?= e($l) ?></option><?php endforeach; ?>
      <option value="inativos"<?= sel($filtro, 'inativos') ?>>Inativos</option>
    </select>
    <button class="btn" type="submit"><?= icon('search', 16) ?> Filtrar</button>
    <?php if ($qText !== '' || $catF || $filtro !== ''): ?><a class="btn btn-sm" href="produtos.php">Limpar</a><?php endif; ?>
  </form>

  <?php if (!$rows): echo empty_state('Nenhum produto encontrado.', 'box'); else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Produto</th><th>Tipo</th><th class="num">Custo</th><th class="num">Venda</th><th class="num">Margem</th><th class="num">Stock</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r):
        $margem = (float) $r['preco_venda'] > 0 ? ((float) $r['preco_venda'] - (float) $r['preco_custo']) / (float) $r['preco_venda'] * 100 : 0;
        $baixo = $r['tipo'] === 'stock' && (int) $r['stock_atual'] <= (int) $r['stock_minimo']; ?>
      <tr>
        <td><span class="cell-main"><?= e($r['nome']) ?></span><span class="cell-sub"><?= e(trim(($r['codigo'] ?? '') . ($r['categoria'] ? ' · ' . $r['categoria'] : ''), ' ·')) ?></span></td>
        <td><?= badge($tipos[$r['tipo']], $r['tipo'] === 'stock' ? 'primary' : ($r['tipo'] === 'dropshipping' ? 'info' : 'neutral')) ?><?= (int) $r['ativo'] ? '' : ' ' . badge('Inativo', 'danger') ?></td>
        <td class="num"><?= e(money($r['preco_custo'])) ?></td>
        <td class="num"><?= e(money($r['preco_venda'])) ?></td>
        <td class="num"><?= num($margem, 0) ?>%</td>
        <td class="num"><?php if ($r['tipo'] === 'stock'): ?><a href="produtos.php?acao=stock&id=<?= (int) $r['id'] ?>" style="color:<?= $baixo ? 'var(--warning)' : 'inherit' ?>;font-weight:600"><?= num($r['stock_atual']) ?></a><?= $baixo ? ' ' . icon('alert', 14) : '' ?><?php else: ?><span class="muted">—</span><?php endif; ?></td>
        <td><div class="row-actions">
          <?php if ($r['tipo'] === 'stock'): ?><a class="btn btn-sm btn-icon" title="Movimentos de stock" href="produtos.php?acao=stock&id=<?= (int) $r['id'] ?>"><?= icon('refresh', 16) ?></a><?php endif; ?>
          <?php if ($canEdit): ?>
            <a class="btn btn-sm btn-icon" title="Editar" href="produtos.php?acao=editar&id=<?= (int) $r['id'] ?>"><?= icon('edit', 16) ?></a>
            <form class="inline-form" method="post" data-confirm="Eliminar este produto?"><?= csrf_field() ?><input type="hidden" name="op" value="eliminar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
              <button class="btn btn-sm btn-icon btn-danger" title="Eliminar" type="submit"><?= icon('trash', 16) ?></button></form>
          <?php endif; ?>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= pagination_html($pg) ?>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
