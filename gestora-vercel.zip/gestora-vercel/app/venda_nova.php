<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('vendas');

$clientes = fetch_all('SELECT id, nome FROM clientes WHERE ativo = 1 ORDER BY nome');
$produtos = fetch_all("SELECT id, codigo, nome, tipo, preco_venda, stock_atual FROM produtos WHERE ativo = 1 ORDER BY nome LIMIT 2000");

$form = [
    'cliente_id' => (int) get('cliente'), 'data_venda' => date('Y-m-d'), 'canal' => 'loja', 'metodo' => 'Numerário',
    'desconto' => '', 'pago' => '', 'notas' => '', 'pago_total' => '1',
];
$lines = [];

if (is_post()) {
    csrf_verify();
    $form['cliente_id'] = (int) post('cliente_id');
    $form['data_venda'] = post('data_venda', date('Y-m-d'));
    $form['canal'] = post('canal', 'loja');
    $form['metodo'] = post('metodo', 'Numerário');
    $form['desconto'] = post('desconto');
    $form['notas'] = post('notas');
    $form['pago_total'] = post('pago_modo') === 'total' ? '1' : '0';
    $form['pago'] = post('pago');

    $pids = $_POST['item_pid'] ?? [];
    $descs = $_POST['item_desc'] ?? [];
    $qtds = $_POST['item_qty'] ?? [];
    $precos = $_POST['item_preco'] ?? [];
    $items = [];
    foreach ((array) $descs as $i => $d) {
        $desc = trim((string) $d);
        $pid = (int) ($pids[$i] ?? 0);
        $qtd = parse_decimal($qtds[$i] ?? '1');
        $preco = parse_decimal($precos[$i] ?? '0');
        if ($desc === '' && !$pid) {
            continue;
        }
        $lines[] = ['pid' => $pid, 'desc' => $desc, 'qty' => $qtd, 'preco' => $preco];
        $items[] = ['produto_id' => $pid ?: null, 'descricao' => $desc, 'quantidade' => $qtd, 'preco' => $preco];
    }

    try {
        $sub = 0.0;
        foreach ($items as $it) {
            $sub += $it['quantidade'] * $it['preco'];
        }
        $tot = sale_totals($sub, parse_decimal($form['desconto']));
        $pago = $form['pago_total'] === '1' ? $tot['total'] : parse_decimal($form['pago']);
        $id = create_sale([
            'cliente_id' => $form['cliente_id'], 'data_venda' => $form['data_venda'], 'canal' => $form['canal'],
            'metodo_pagamento' => $form['metodo'], 'desconto' => parse_decimal($form['desconto']), 'notas' => $form['notas'], 'pago' => $pago,
        ], $items);
        $num = fetch_val('SELECT numero FROM vendas WHERE id = ?', [$id]);
        log_activity('venda_criada', (string) $num);
        flash('success', 'Venda ' . $num . ' registada com sucesso.');
        redirect('venda_ver.php?id=' . $id);
    } catch (RuntimeException $e) {
        flash('error', $e->getMessage());
    }
}

$jsData = [
    'produtos' => array_map(static fn($p) => [
        'id' => (int) $p['id'], 'codigo' => $p['codigo'], 'nome' => $p['nome'], 'tipo' => $p['tipo'],
        'preco' => (float) $p['preco_venda'], 'stock' => (int) $p['stock_atual'],
    ], $produtos),
    'linhas' => $lines,
    'iva' => (float) setting('iva_taxa', '0'),
    'incluiIva' => setting('precos_incluem_iva', '1') === '1',
    'moeda' => setting('moeda', 'Kz'),
];

page_header('Nova venda', 'vendas', [
    'subtitle' => 'Emite uma fatura/recibo, atualiza o stock e regista o pagamento.',
    'actions' => '<a class="btn" href="vendas.php">Voltar às vendas</a>',
]);
?>
<form method="post" id="saleForm" data-once autocomplete="off">
  <?= csrf_field() ?>
  <div class="grid g-main">
    <div class="grid" style="align-content:start">
      <div class="card">
        <div class="card-head"><h2>Itens</h2><button type="button" class="btn btn-sm" id="addLine"><?= icon('plus', 16) ?> Linha livre</button></div>
        <div class="field mb">
          <label for="prodSearch">Adicionar produto</label>
          <div class="ac-wrap">
            <input type="search" id="prodSearch" placeholder="Escreve o nome ou código do produto…" autocomplete="off">
            <div class="ac-list" id="acList" role="listbox"></div>
          </div>
        </div>
        <div class="table-wrap"><table class="table lines" id="lines">
          <thead><tr><th>Descrição</th><th>Qtd.</th><th>Preço unit.</th><th class="text-right">Total</th><th></th></tr></thead>
          <tbody></tbody>
        </table></div>
        <p class="muted" id="noLines" style="margin:14px 0 0">Ainda não adicionaste itens.</p>
      </div>
      <div class="card">
        <div class="field"><label for="notas">Notas (aparecem na fatura)</label><textarea id="notas" name="notas" style="min-height:70px"><?= e($form['notas']) ?></textarea></div>
      </div>
    </div>

    <div class="grid" style="align-content:start">
      <div class="card">
        <div class="card-head"><h2>Dados da venda</h2></div>
        <div class="form-grid">
          <div class="field col-12"><label for="cliente_id">Cliente</label>
            <select id="cliente_id" name="cliente_id"><option value="">Consumidor final</option>
              <?php foreach ($clientes as $c): ?><option value="<?= (int) $c['id'] ?>"<?= sel($form['cliente_id'], $c['id']) ?>><?= e($c['nome']) ?></option><?php endforeach; ?>
            </select></div>
          <div class="field col-6"><label for="data_venda">Data</label><input type="date" id="data_venda" name="data_venda" value="<?= e($form['data_venda']) ?>" max="<?= e(date('Y-m-d')) ?>" required></div>
          <div class="field col-6"><label for="canal">Canal</label>
            <select id="canal" name="canal"><option value="loja"<?= sel($form['canal'], 'loja') ?>>Loja física</option><option value="online"<?= sel($form['canal'], 'online') ?>>Online</option><option value="outro"<?= sel($form['canal'], 'outro') ?>>Outro</option></select></div>
          <div class="field col-12"><label for="metodo">Método de pagamento</label>
            <select id="metodo" name="metodo"><?php foreach (PAYMENT_METHODS as $m): ?><option<?= sel($form['metodo'], $m) ?>><?= e($m) ?></option><?php endforeach; ?></select></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h2>Resumo</h2></div>
        <div class="field" style="margin-bottom:14px"><label for="desconto">Desconto (<?= e(setting('moeda', 'Kz')) ?>)</label><input type="text" inputmode="decimal" id="desconto" name="desconto" value="<?= e($form['desconto']) ?>" placeholder="0"></div>
        <div class="summary-box">
          <div class="stat-row"><span>Subtotal</span><b id="tSub">0</b></div>
          <div class="stat-row"><span>Desconto</span><b id="tDesc">0</b></div>
          <div class="stat-row"><span id="tBaseLbl">Base tributável</span><b id="tBase">0</b></div>
          <div class="stat-row"><span id="tIvaLbl">IVA</span><b id="tIva">0</b></div>
          <div class="stat-row total"><span>Total</span><b id="tTotal">0</b></div>
        </div>
        <div class="field" style="margin-top:16px">
          <span class="lbl">Pagamento</span>
          <label class="check"><input type="radio" name="pago_modo" value="total"<?= chk($form['pago_total'] === '1') ?>> Pago na totalidade</label>
          <label class="check"><input type="radio" name="pago_modo" value="parcial"<?= chk($form['pago_total'] !== '1') ?>> Pagamento parcial / a crédito</label>
        </div>
        <div class="field" id="pagoWrap" style="margin-top:12px"><label for="pago">Valor recebido agora</label><input type="text" inputmode="decimal" id="pago" name="pago" value="<?= e($form['pago']) ?>" placeholder="0"><span class="hint">Deixa 0 se a fatura ficar por pagar.</span></div>
        <div class="form-actions" style="margin-top:20px"><button class="btn btn-primary btn-block" type="submit" id="saveBtn"><?= icon('check', 18) ?> Emitir fatura</button></div>
      </div>
    </div>
  </div>
</form>
<script id="saleData" type="application/json"><?= json_encode($jsData, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<?php page_footer(['assets/js/venda.js']); ?>
