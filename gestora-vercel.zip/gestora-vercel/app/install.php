<?php
declare(strict_types=1);

/**
 * Instalador da GesTora (versão Vercel).
 *
 * - A ligação à base de dados vem das variáveis de ambiente (DB_*), não de um formulário.
 * - Só funciona se definires a variável SETUP_TOKEN na Vercel e a escreveres aqui.
 * - Fica bloqueado automaticamente assim que existir um utilizador na base de dados
 *   (não precisa de ficheiro de bloqueio, porque a Vercel não tem disco gravável).
 */
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/icons.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/sales.php';
require_once __DIR__ . '/database/demo.php';

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

$setupToken = (string) cfg('setup_token', '');
$errors = [];
$done = false;
$connError = null;
$locked = false;
$v = ['empresa' => '', 'nome' => '', 'email' => '', 'utilizador' => 'admin', 'demo' => '0'];

// 1) Ligação e estado atual
$pdo = null;
try {
    $pdo = db_connect();
    try {
        $locked = ((int) $pdo->query('SELECT COUNT(*) FROM utilizadores')->fetchColumn()) > 0;
    } catch (PDOException $e) {
        $locked = false; // tabela ainda não existe
    }
} catch (Throwable $e) {
    $connError = !empty(cfg('debug')) ? $e->getMessage() : 'Não consegui ligar à base de dados. Verifica DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS e DB_SSL (define APP_DEBUG=1 para ver o erro).';
}

$canInstall = $pdo !== null && !$locked && $setupToken !== '';

// 2) Instalação
if ($canInstall && is_post()) {
    foreach (['empresa', 'nome', 'email', 'utilizador'] as $k) {
        $v[$k] = post($k, $v[$k]);
    }
    $v['demo'] = post('demo') === '1' ? '1' : '0';
    $senha = (string) ($_POST['senha'] ?? '');
    $senha2 = (string) ($_POST['senha2'] ?? '');
    $tokenSent = (string) ($_POST['token'] ?? '');

    if (!hash_equals($setupToken, $tokenSent)) {
        $errors[] = 'O código de instalação (SETUP_TOKEN) está incorreto.';
    }
    if ($v['nome'] === '' || $v['utilizador'] === '' || !filter_var($v['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Preenche o nome, um email válido e o utilizador do administrador.';
    }
    if (!preg_match('/^[A-Za-z0-9._-]{3,40}$/', $v['utilizador'])) {
        $errors[] = 'O utilizador deve ter 3 a 40 caracteres (letras, números, ponto, hífen ou _).';
    }
    if (strlen($senha) < 8) {
        $errors[] = 'A palavra-passe do administrador deve ter pelo menos 8 caracteres.';
    }
    if ($senha !== $senha2) {
        $errors[] = 'As palavras-passe não coincidem.';
    }

    if (!$errors) {
        try {
            @set_time_limit(120);

            $sql = (string) file_get_contents(__DIR__ . '/database/schema.sql');
            $sql = preg_replace('/^\s*--.*$/m', '', $sql);
            foreach (preg_split('/;\s*[\r\n]+/', $sql) as $stmt) {
                $stmt = trim((string) $stmt);
                if ($stmt !== '') {
                    $pdo->exec($stmt);
                }
            }

            // Reconfirma que continua vazio (evita duas instalações em simultâneo)
            if (((int) $pdo->query('SELECT COUNT(*) FROM utilizadores')->fetchColumn()) > 0) {
                throw new RuntimeException('Esta base de dados já tem a GesTora instalada.');
            }

            $st = $pdo->prepare('INSERT INTO utilizadores (nome, email, utilizador, senha_hash, perfil, ativo) VALUES (?,?,?,?,?,1)');
            $st->execute([$v['nome'], $v['email'], $v['utilizador'], password_hash($senha, PASSWORD_DEFAULT), 'admin']);
            $adminId = (int) $pdo->lastInsertId();
            if ($v['empresa'] !== '') {
                $pdo->prepare('UPDATE configuracoes SET valor = ? WHERE chave = ?')->execute([$v['empresa'], 'empresa_nome']);
            }

            if ($v['demo'] === '1') {
                $_SESSION = ['uid' => $adminId]; // usado só para registar quem criou os dados de demonstração
                gt_seed_demo();
                $_SESSION = [];
            }
            $done = true;
        } catch (Throwable $e) {
            $errors[] = 'Falha na instalação: ' . (!empty(cfg('debug')) ? $e->getMessage() : 'verifica se a base de dados está vazia e se o utilizador tem permissões para criar tabelas (APP_DEBUG=1 mostra o detalhe).');
        }
    }
}
?>
<!doctype html>
<html lang="pt-PT" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Instalação · GesTora</title>
<link rel="icon" type="image/png" href="assets/img/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css">
<style>
  body.app { display: grid; place-items: start center; padding: 40px 16px; }
  .install { width: 100%; max-width: 760px; }
  .install .logo-wrap { text-align: center; margin-bottom: 26px; }
  .install h2 { font-size: 15px; text-transform: uppercase; letter-spacing: .08em; color: var(--primary-2); margin: 26px 0 14px; }
  .install pre { background: var(--bg); border: 1px solid var(--line); padding: 14px; border-radius: 12px; overflow: auto; font-size: 12.5px; }
</style>
</head>
<body class="app">
<div class="install">
  <div class="logo-wrap"><?= logo_html(48) ?><div class="muted" style="margin-top:8px"><?= e(APP_TAGLINE) ?></div></div>
  <div class="card">
  <?php if ($connError !== null): ?>
    <div class="empty">
      <?= icon('alert', 40) ?>
      <h2 style="color:var(--text)">Sem ligação à base de dados</h2>
      <p><?= e($connError) ?></p>
    </div>
  <?php elseif ($done): ?>
    <div class="empty">
      <?= icon('check', 44) ?>
      <h2 style="color:var(--text)">Instalação concluída!</h2>
      <p>Entra com o utilizador <b><?= e($v['utilizador']) ?></b> e a palavra-passe que definiste.</p>
      <p class="muted">O instalador ficou bloqueado automaticamente. Por segurança, remove a variável <b>SETUP_TOKEN</b> na Vercel.</p>
      <a class="btn btn-primary" href="login.php">Ir para o login</a>
    </div>
  <?php elseif ($locked): ?>
    <div class="empty">
      <?= icon('lock', 40) ?>
      <h2 style="text-transform:none;letter-spacing:0;font-size:20px;color:var(--text)">A GesTora já está instalada</h2>
      <p>Por segurança, o instalador está bloqueado.</p>
      <a class="btn btn-primary" href="login.php">Ir para o login</a>
    </div>
  <?php elseif ($setupToken === ''): ?>
    <div class="empty">
      <?= icon('lock', 40) ?>
      <h2 style="text-transform:none;letter-spacing:0;font-size:20px;color:var(--text)">Falta o código de instalação</h2>
      <p>Na Vercel, vai a <b>Settings → Environment Variables</b>, cria a variável <b>SETUP_TOKEN</b> com um segredo à tua escolha (mín. 16 caracteres) e faz <b>Redeploy</b>. Depois volta a esta página.</p>
    </div>
  <?php else: ?>
    <h1 style="font-size:22px">Instalar a GesTora</h1>
    <p class="muted">A ligação à base de dados está pronta. As tabelas são criadas automaticamente.</p>
    <?php foreach ($errors as $er): ?><div class="flash flash-error"><?= icon('alert', 18) ?><span><?= e($er) ?></span></div><?php endforeach; ?>
    <form method="post" data-once autocomplete="off">
      <h2>Segurança</h2>
      <div class="form-grid">
        <div class="field col-12"><label for="token">Código de instalação (SETUP_TOKEN)</label><input type="password" id="token" name="token" required autocomplete="off"></div>
      </div>
      <h2>Empresa e administrador</h2>
      <div class="form-grid">
        <div class="field col-12"><label for="empresa">Nome da empresa</label><input type="text" id="empresa" name="empresa" value="<?= e($v['empresa']) ?>" placeholder="Ex.: Deal Zone"></div>
        <div class="field col-6"><label for="nome">Nome completo</label><input type="text" id="nome" name="nome" value="<?= e($v['nome']) ?>" required></div>
        <div class="field col-6"><label for="email">Email</label><input type="email" id="email" name="email" value="<?= e($v['email']) ?>" required></div>
        <div class="field col-4"><label for="utilizador">Utilizador</label><input type="text" id="utilizador" name="utilizador" value="<?= e($v['utilizador']) ?>" required></div>
        <div class="field col-4"><label for="senha">Palavra-passe (mín. 8)</label><input type="password" id="senha" name="senha" required minlength="8" autocomplete="new-password"></div>
        <div class="field col-4"><label for="senha2">Confirmar palavra-passe</label><input type="password" id="senha2" name="senha2" required minlength="8" autocomplete="new-password"></div>
        <div class="col-12"><label class="check"><input type="checkbox" name="demo" value="1"<?= chk($v['demo'] === '1') ?>> Carregar dados de demonstração (demora um pouco mais; deixa desmarcado para um sistema limpo)</label></div>
      </div>
      <div class="form-actions"><button type="submit" class="btn btn-primary"><?= icon('check', 18) ?> Instalar agora</button></div>
    </form>
  <?php endif; ?>
  </div>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
