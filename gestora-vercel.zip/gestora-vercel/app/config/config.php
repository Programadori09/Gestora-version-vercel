<?php
/**
 * GesTora - Configuração geral (versão Vercel).
 *
 * Na Vercel NÃO existe disco gravável, por isso a configuração vem de VARIÁVEIS DE AMBIENTE
 * (Project Settings → Environment Variables):
 *
 *   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS   Ligação MySQL/MariaDB/TiDB
 *   DB_SSL=1                                      Ligar com TLS (obrigatório na maioria dos serviços geridos)
 *   DB_SSL_CA=config/ca.pem                       (opcional) caminho do certificado CA, relativo à pasta app/
 *   SETUP_TOKEN                                   Segredo para correr o instalador (install.php) uma vez
 *   APP_TIMEZONE=Africa/Luanda                    (opcional)
 *   APP_DEBUG=1                                   (opcional) mostra erros - usar só para diagnosticar
 *
 * Para desenvolvimento local, podes criar app/config/config.local.php a devolver um array
 * com as mesmas chaves em minúsculas (db_host, db_port, ...). Esse ficheiro não deve ir para o Git/Vercel.
 */

declare(strict_types=1);

const APP_NAME    = 'GesTora';
const APP_TAGLINE = 'O teu negócio, sob controlo';
const APP_VERSION = '1.1.0-vercel';

/** Lê uma variável de ambiente (funciona com getenv, $_ENV e $_SERVER). */
function env_val(string $key, $default = null)
{
    $v = getenv($key);
    if ($v === false || $v === '') {
        $v = $_ENV[$key] ?? $_SERVER[$key] ?? null;
    }
    return ($v === null || $v === false || $v === '') ? $default : $v;
}

function env_bool(string $key, bool $default = false): bool
{
    $v = env_val($key);
    if ($v === null) {
        return $default;
    }
    return in_array(strtolower((string) $v), ['1', 'true', 'on', 'yes', 'sim'], true);
}

$gt_defaults = [
    'db_host'     => (string) env_val('DB_HOST', '127.0.0.1'),
    'db_port'     => (int) env_val('DB_PORT', 3306),
    'db_name'     => (string) env_val('DB_NAME', 'gestora'),
    'db_user'     => (string) env_val('DB_USER', 'root'),
    'db_pass'     => (string) env_val('DB_PASS', ''),
    'db_ssl'      => env_bool('DB_SSL', false),
    'db_ssl_ca'   => (string) env_val('DB_SSL_CA', ''),
    'timezone'    => (string) env_val('APP_TIMEZONE', 'Africa/Luanda'),
    'debug'       => env_bool('APP_DEBUG', false),
    'setup_token' => (string) env_val('SETUP_TOKEN', ''),
];

$gt_local = [];
$gt_local_file = __DIR__ . '/config.local.php';
if (is_file($gt_local_file)) {
    $loaded = require $gt_local_file;
    if (is_array($loaded)) {
        $gt_local = $loaded;
    }
}

$GLOBALS['gt_config'] = array_merge($gt_defaults, $gt_local);

date_default_timezone_set((string) $GLOBALS['gt_config']['timezone']);

if (!empty($GLOBALS['gt_config']['debug'])) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}

function cfg(string $key, $default = null)
{
    return $GLOBALS['gt_config'][$key] ?? $default;
}
