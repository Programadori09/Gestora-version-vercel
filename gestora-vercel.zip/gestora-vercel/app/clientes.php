<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/contacts.php';

render_contacts([
    'table' => 'clientes', 'area' => 'clientes', 'active' => 'clientes', 'singular' => 'Cliente', 'plural' => 'Clientes',
    'file' => 'clientes.php', 'icon' => 'users', 'sale_link' => true,
    'subtitle' => 'Quem compra de ti, o que comprou e o que ainda deve.',
]);
