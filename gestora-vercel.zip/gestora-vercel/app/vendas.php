<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('vendas');

$qText = get('q');
$estado = get('estado');
$de = valid_date(get('de')) ? get('de') : '';
$ate = valid_date(get('ate')) ? get('ate') : '';

$where = ['1=1'];
$params = [];
if ($qText !== '') {
    $where[] = '(v.numero LIKE ? OR c.nome LIKE ?)';
    $params[] = '%' . $qText . '%';
    $params[] = '%' . $qText . '%';
}
if ($de !== '') {
    $where[] = 'v.data_venda >= ?';
    $params[] = $de;
}
if ($ate !== '') {
    $where[] = 'v.data_venda <= ?';
    $params[] = $ate;
}
if ($estado === 'anulada') {
    $where[] = "v.estado = 'anulada'";
} elseif ($estado === 'paga') {
    $where[] = "v.estado = 'emitida' AND v.total - v.valor_pago <= 0.004";
} elseif ($estado === 'pendente') {
    $where[] = "v.estado = 'emitida' AND v.total - v.valor_pago > 0.004";
}
$W = implode(' AND ', $where);
$from = 'FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id';

$pg = paginate((int) fetch_val("SELECT COUNT(*) $from WHERE $W", $params), 15);
$rows = fetch_all("SELECT v.*, c.nome cliente $from WHERE $W ORDER BY v.data_venda DESC, v.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params);
$tot = fetch_one("SELECT COALESCE(SUM(CASE WHEN v.estado='emitida' THEN v.total END),0) total,
                         COALESCE(SUM(CASE WHEN v.estado='emitida' THEN v.total - v.valor_pago END),0) aberto,
                         COUNT(CASE WHEN v.estado='emitida' THEN 1 END) n $from WHERE $W", $params);

page_header('Vendas e faturas', 'vendas', [
    'subtitle' => 'Todas as faturas emitidas e o estado de cada pagamento.',
    'actions' => '<a class="btn btn-primary" href="venda_nova.php">' . icon('plus', 18) . ' Nova venda</a>',
]);
?>
<div class="grid g-3 mb">
  <div class="card kpi"><div class="k-ic"><?= icon('file', 22) ?></div><div class="k-label">Faturas (filtro atual)</div><div class="k-value"><?= num($tot['n']) ?></div></div>
  <div class="card kpi good"><div class="k-ic"><?= icon('trend', 22) ?></div><div class="k-label">Total faturado</div><div class="k-value"><?= e(money($tot['total'])) ?></div></div>
  <div class="card kpi warn"><div class="k-ic"><?= icon('wallet', 22) ?></div><div class="k-label">Por receber</div><div class="k-value"><?= e(money($tot['aberto'])) ?></div></div>
</div>

<div class="card">
  <form class="filters" method="get">
    <input type="search" name="q" value="<?= e($qText) ?>" placeholder="Nº da fatura ou cliente…" aria-label="Pesquisar">
    <select name="estado" aria-label="Estado">
      <option value="">Todos os estados</option>
      <option value="paga"<?= sel($estado, 'paga') ?>>Pagas</option>
      <option value="pendente"<?= sel($estado, 'pendente') ?>>Por pagar / parciais</option>
      <option value="anulada"<?= sel($estado, 'anulada') ?>>Anuladas</option>
    </select>
    <div class="field"><input type="date" name="de" value="<?= e($de) ?>" aria-label="De"></div>
    <div class="field"><input type="date" name="ate" value="<?= e($ate) ?>" aria-label="Até"></div>
    <button class="btn" type="submit"><?= icon('search', 16) ?> Filtrar</button>
    <?php if ($qText !== '' || $estado !== '' || $de !== '' || $ate !== ''): ?><a class="btn btn-sm" href="vendas.php">Limpar</a><?php endif; ?>
  </form>

  <?php if (!$rows): echo empty_state('Nenhuma venda encontrada.', 'cart'); else: ?>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>Fatura</th><th>Cliente</th><th>Data</th><th class="num">Total</th><th class="num">Pago</th><th>Estado</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): [$lbl, $cls] = sale_payment_state($r); ?>
      <tr<?= $r['estado'] === 'anulada' ? ' style="opacity:.6"' : '' ?>>
        <td><a class="cell-main" href="venda_ver.php?id=<?= (int) $r['id'] ?>"><?= e($r['numero']) ?></a><span class="cell-sub"><?= e(ucfirst($r['canal'])) ?></span></td>
        <td><?= e($r['cliente'] ?? 'Consumidor final') ?></td>
        <td class="nowrap"><?= e(fdate($r['data_venda'])) ?></td>
        <td class="num"><?= e(money($r['total'])) ?></td>
        <td class="num"><?= e(money($r['valor_pago'])) ?></td>
        <td><?= badge($lbl, $cls) ?></td>
        <td><div class="row-actions">
          <a class="btn btn-sm btn-icon" title="Ver" href="venda_ver.php?id=<?= (int) $r['id'] ?>"><?= icon('eye', 16) ?></a>
          <a class="btn btn-sm btn-icon" title="Imprimir" target="_blank" rel="noopener" href="venda_imprimir.php?id=<?= (int) $r['id'] ?>"><?= icon('printer', 16) ?></a>
        </div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= pagination_html($pg) ?>
  <?php endif; ?>
</div>
<?php page_footer(); ?>
