<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('vendas');

$id = (int) get('id');
$v = fetch_one('SELECT v.*, c.nome cliente, c.telefone cli_tel, c.email cli_email, c.endereco cli_end, c.nif cli_nif, u.nome vendedor
                FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id LEFT JOIN utilizadores u ON u.id = v.utilizador_id WHERE v.id = ?', [$id]);
if (!$v) {
    flash('error', 'Fatura não encontrada.');
    redirect('vendas.php');
}

if (is_post()) {
    csrf_verify();
    $op = post('op');
    if ($op === 'pagamento') {
        $valor = round(parse_decimal(post('valor')), 2);
        $data = post('data', date('Y-m-d'));
        $em_aberto = round((float) $v['total'] - (float) $v['valor_pago'], 2);
        if ($v['estado'] === 'anulada') {
            flash('error', 'Não é possível registar pagamentos numa fatura anulada.');
        } elseif ($valor <= 0) {
            flash('error', 'Indica um valor de pagamento válido.');
        } elseif ($valor > $em_aberto + 0.004) {
            flash('error', 'O pagamento (' . money($valor) . ') excede o valor em aberto (' . money($em_aberto) . ').');
        } elseif (!valid_date($data)) {
            flash('error', 'Data inválida.');
        } else {
            q('INSERT INTO pagamentos (venda_id, valor, metodo, data_pagamento, utilizador_id, notas) VALUES (?,?,?,?,?,?)',
                [$id, $valor, post('metodo', 'Numerário'), $data, $user['id'], str_or_null(post('notas'))]);
            recompute_sale_payment($id);
            log_activity('pagamento_registado', $v['numero'] . ' · ' . money($valor));
            flash('success', 'Pagamento registado.');
        }
        redirect('venda_ver.php?id=' . $id);
    }
    if ($op === 'anular') {
        if (!in_array($user['perfil'], ['admin', 'gestor'], true)) {
            http_response_code(403);
            exit('Sem permissão.');
        }
        try {
            cancel_sale($id);
            log_activity('venda_anulada', $v['numero']);
            flash('success', 'Fatura anulada e stock reposto.');
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
        }
        redirect('venda_ver.php?id=' . $id);
    }
}

$items = fetch_all('SELECT * FROM venda_itens WHERE venda_id = ? ORDER BY id', [$id]);
$pags = fetch_all('SELECT p.*, u.nome utilizador FROM pagamentos p LEFT JOIN utilizadores u ON u.id = p.utilizador_id WHERE venda_id = ? ORDER BY p.data_pagamento, p.id', [$id]);
$emAberto = max(0.0, round((float) $v['total'] - (float) $v['valor_pago'], 2));
[$lbl, $cls] = sale_payment_state($v);
$lucro = (float) $v['base_tributavel'];
foreach ($items as $it) {
    $lucro -= (float) $it['quantidade'] * (float) $it['custo_unitario'];
}

page_header('Fatura ' . $v['numero'], 'vendas', [
    'subtitle' => 'Emitida a ' . fdate($v['data_venda']) . ($v['vendedor'] ? ' por ' . $v['vendedor'] : ''),
    'actions' => '<a class="btn" href="vendas.php">Voltar</a>'
        . '<a class="btn btn-primary" target="_blank" rel="noopener" href="venda_imprimir.php?id=' . $id . '">' . icon('printer', 18) . ' Imprimir / PDF</a>',
]);
?>
<div class="grid g-main">
  <div class="grid" style="align-content:start">
    <div class="card">
      <div class="card-head"><h2>Itens</h2><?= badge($lbl, $cls) ?></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Descrição</th><th class="num">Qtd.</th><th class="num">Preço unit.</th><th class="num">Total</th></tr></thead>
        <tbody>
        <?php foreach ($items as $it): ?>
          <tr><td><?= e($it['descricao']) ?></td><td class="num"><?= num($it['quantidade'], fmod((float) $it['quantidade'], 1) ? 2 : 0) ?></td><td class="num"><?= e(money($it['preco_unitario'])) ?></td><td class="num"><?= e(money($it['total'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php if ($v['notas']): ?><p class="muted" style="margin-top:14px"><b>Notas:</b> <?= e($v['notas']) ?></p><?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h2>Pagamentos</h2></div>
      <?php if (!$pags): echo empty_state('Ainda não há pagamentos registados.', 'wallet'); else: ?>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Data</th><th>Método</th><th>Registado por</th><th class="num">Valor</th></tr></thead>
        <tbody>
        <?php foreach ($pags as $p): ?>
          <tr><td><?= e(fdate($p['data_pagamento'])) ?></td><td><?= e($p['metodo']) ?><?= $p['notas'] ? '<span class="cell-sub">' . e($p['notas']) . '</span>' : '' ?></td><td><?= e($p['utilizador'] ?? '—') ?></td><td class="num"><?= e(money($p['valor'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php endif; ?>

      <?php if ($v['estado'] === 'emitida' && $emAberto > 0.004): ?>
      <form method="post" class="mt" data-once>
        <?= csrf_field() ?><input type="hidden" name="op" value="pagamento">
        <div class="form-grid">
          <div class="field col-3"><label for="valor">Valor (em aberto: <?= e(money($emAberto)) ?>)</label><input type="text" inputmode="decimal" id="valor" name="valor" value="<?= e($emAberto) ?>" required></div>
          <div class="field col-3"><label for="data">Data</label><input type="date" id="data" name="data" value="<?= e(date('Y-m-d')) ?>" max="<?= e(date('Y-m-d')) ?>" required></div>
          <div class="field col-3"><label for="metodo">Método</label><select id="metodo" name="metodo"><?php foreach (PAYMENT_METHODS as $m): ?><option><?= e($m) ?></option><?php endforeach; ?></select></div>
          <div class="field col-3"><label for="notas">Nota</label><input type="text" id="notas" name="notas" maxlength="200"></div>
        </div>
        <div class="form-actions"><button class="btn btn-success" type="submit"><?= icon('check', 18) ?> Registar pagamento</button></div>
      </form>
      <?php endif; ?>
    </div>
  </div>

  <div class="grid" style="align-content:start">
    <div class="card">
      <div class="card-head"><h2>Totais</h2></div>
      <div class="summary-box">
        <div class="stat-row"><span>Subtotal</span><b><?= e(money($v['subtotal'])) ?></b></div>
        <?php if ((float) $v['desconto'] > 0): ?><div class="stat-row"><span>Desconto</span><b>− <?= e(money($v['desconto'])) ?></b></div><?php endif; ?>
        <div class="stat-row"><span>Base tributável</span><b><?= e(money($v['base_tributavel'])) ?></b></div>
        <div class="stat-row"><span>IVA (<?= num($v['iva_taxa'], 0) ?>%)</span><b><?= e(money($v['iva_valor'])) ?></b></div>
        <div class="stat-row total"><span>Total</span><b><?= e(money($v['total'])) ?></b></div>
        <div class="stat-row"><span>Pago</span><b style="color:var(--success)"><?= e(money($v['valor_pago'])) ?></b></div>
        <div class="stat-row"><span>Em aberto</span><b style="color:<?= $emAberto > 0.004 ? 'var(--warning)' : 'inherit' ?>"><?= e(money($emAberto)) ?></b></div>
      </div>
      <?php if (in_array($user['perfil'], ['admin', 'gestor'], true) && $v['estado'] === 'emitida'): ?>
        <div class="stat-row" style="margin-top:10px"><span>Lucro desta venda</span><b><?= e(money($lucro)) ?></b></div>
      <?php endif; ?>
    </div>
    <div class="card">
      <div class="card-head"><h2>Cliente</h2></div>
      <?php if ($v['cliente']): ?>
        <p style="margin:0"><b><?= e($v['cliente']) ?></b></p>
        <p class="muted" style="margin:4px 0 0"><?= e(implode(' · ', array_filter([$v['cli_tel'], $v['cli_email'], $v['cli_end'], $v['cli_nif'] ? 'NIF ' . $v['cli_nif'] : '']))) ?></p>
      <?php else: ?><p class="muted" style="margin:0">Consumidor final</p><?php endif; ?>
      <hr>
      <p class="muted" style="margin:0">Canal: <b style="color:var(--text)"><?= e(ucfirst($v['canal'])) ?></b> · Método: <b style="color:var(--text)"><?= e($v['metodo_pagamento']) ?></b></p>
    </div>
    <?php if ($v['estado'] === 'emitida' && in_array($user['perfil'], ['admin', 'gestor'], true)): ?>
    <form method="post" data-confirm="Anular esta fatura? O stock dos itens será reposto e a venda deixa de contar nos totais.">
      <?= csrf_field() ?><input type="hidden" name="op" value="anular">
      <button class="btn btn-danger btn-block" type="submit"><?= icon('x', 18) ?> Anular fatura</button>
    </form>
    <?php endif; ?>
  </div>
</div>
<?php page_footer(); ?>
