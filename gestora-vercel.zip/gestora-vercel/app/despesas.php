<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/bootstrap.php';
$user = require_area('despesas');
$acao = get('acao');

if (is_post()) {
    csrf_verify();
    $op = post('op');
    if ($op === 'guardar') {
        $id = (int) post('id');
        $data = post('data_despesa', date('Y-m-d'));
        $desc = post('descricao');
        $valor = round(parse_decimal(post('valor')), 2);
        $cat = in_array(post('categoria'), EXPENSE_CATEGORIES, true) ? post('categoria') : 'Outras';
        if ($desc === '' || $valor <= 0 || !valid_date($data)) {
            flash('error', 'Indica uma descrição, uma data válida e um valor maior que zero.');
            redirect($id ? 'despesas.php?acao=editar&id=' . $id : 'despesas.php?acao=novo');
        }
        $vals = [$data, $desc, $cat, $valor, post('metodo', 'Numerário'), opt_null(post('fornecedor_id')), str_or_null(post('notas'))];
        if ($id) {
            q('UPDATE despesas SET data_despesa=?, descricao=?, categoria=?, valor=?, metodo=?, fornecedor_id=?, notas=? WHERE id=?', array_merge($vals, [$id]));
            flash('success', 'Despesa atualizada.');
        } else {
            q('INSERT INTO despesas (data_despesa, descricao, categoria, valor, metodo, fornecedor_id, notas, utilizador_id) VALUES (?,?,?,?,?,?,?,?)', array_merge($vals, [$user['id']]));
            flash('success', 'Despesa registada.');
        }
        log_activity('despesa_guardada', $desc . ' · ' . money($valor));
        redirect('despesas.php');
    }
    if ($op === 'eliminar') {
        q('DELETE FROM despesas WHERE id = ?', [(int) post('id')]);
        log_activity('despesa_removida', '#' . (int) post('id'));
        flash('success', 'Despesa eliminada.');
        redirect('despesas.php');
    }
}

$forns = fetch_all('SELECT id, nome FROM fornecedores WHERE ativo = 1 ORDER BY nome');

if ($acao === 'novo' || $acao === 'editar') {
    $d = ['id' => 0, 'data_despesa' => date('Y-m-d'), 'descricao' => '', 'categoria' => 'Outras', 'valor' => '', 'metodo' => 'Numerário', 'fornecedor_id' => '', 'notas' => ''];
    if ($acao === 'editar') {
        $row = fetch_one('SELECT * FROM despesas WHERE id = ?', [(int) get('id')]);
        if (!$row) {
            redirect('despesas.php');
        }
        $d = $row;
    }
    page_header($d['id'] ? 'Editar despesa' : 'Nova despesa', 'despesas', ['actions' => '<a class="btn" href="despesas.php">Voltar</a>']);
    ?>
    <form class="card" method="post" data-once>
      <?= csrf_field() ?><input type="hidden" name="op" value="guardar"><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
      <div class="form-grid">
        <div class="field col-8"><label class="required" for="descricao">Descrição</label><input type="text" id="descricao" name="descricao" value="<?= e($d['descricao']) ?>" required maxlength="200"></div>
        <div class="field col-4"><label class="required" for="valor">Valor (<?= e(setting('moeda', 'Kz')) ?>)</label><input type="text" inputmode="decimal" id="valor" name="valor" value="<?= e($d['valor'] === '' ? '' : (float) $d['valor']) ?>" required></div>
        <div class="field col-3"><label for="data_despesa">Data</label><input type="date" id="data_despesa" name="data_despesa" value="<?= e($d['data_despesa']) ?>" required></div>
        <div class="field col-3"><label for="categoria">Categoria</label><select id="categoria" name="categoria"><?php foreach (EXPENSE_CATEGORIES as $c): ?><option<?= sel($d['categoria'], $c) ?>><?= e($c) ?></option><?php endforeach; ?></select></div>
        <div class="field col-3"><label for="metodo">Método</label><select id="metodo" name="metodo"><?php foreach (PAYMENT_METHODS as $m): ?><option<?= sel($d['metodo'], $m) ?>><?= e($m) ?></option><?php endforeach; ?></select></div>
        <div class="field col-3"><label for="fornecedor_id">Fornecedor</label><select id="fornecedor_id" name="fornecedor_id"><option value="">—</option><?php foreach ($forns as $f): ?><option value="<?= (int) $f['id'] ?>"<?= sel($d['fornecedor_id'], $f['id']) ?>><?= e($f['nome']) ?></option><?php endforeach; ?></select></div>
        <div class="field col-12"><label for="notas">Notas</label><textarea id="notas" name="notas" style="min-height:70px"><?= e($d['notas']) ?></textarea></div>
      </div>
      <div class="form-actions"><a class="btn" href="despesas.php">Cancelar</a><button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Guardar</button></div>
    </form>
    <?php
    page_footer();
    exit;
}

$de = valid_date(get('de')) ? get('de') : date('Y-m-01');
$ate = valid_date(get('ate')) ? get('ate') : date('Y-m-d');
$catF = get('cat');
$where = ['d.data_despesa BETWEEN ? AND ?'];
$params = [$de, $ate];
if (in_array($catF, EXPENSE_CATEGORIES, true)) {
    $where[] = 'd.categoria = ?';
    $params[] = $catF;
}
$W = implode(' AND ', $where);
$total = (float) fetch_val("SELECT COALESCE(SUM(valor),0) FROM despesas d WHERE $W", $params);
$byCat = fetch_all("SELECT categoria, SUM(valor) t FROM despesas d WHERE $W GROUP BY categoria ORDER BY t DESC", $params);
$pg = paginate((int) fetch_val("SELECT COUNT(*) FROM despesas d WHERE $W", $params), 15);
$rows = fetch_all("SELECT d.*, f.nome fornecedor FROM despesas d LEFT JOIN fornecedores f ON f.id = d.fornecedor_id WHERE $W ORDER BY d.data_despesa DESC, d.id DESC LIMIT {$pg['per']} OFFSET {$pg['offset']}", $params);

page_header('Despesas', 'despesas', [
    'subtitle' => 'Rendas, salários, marketing e todos os custos do negócio.',
    'actions' => '<a class="btn btn-primary" href="despesas.php?acao=novo">' . icon('plus', 18) . ' Nova despesa</a>',
]);
?>
<div class="grid g-main mb">
  <div class="card">
    <form class="filters" method="get">
      <div class="field"><input type="date" name="de" value="<?= e($de) ?>" aria-label="De"></div>
      <div class="field"><input type="date" name="ate" value="<?= e($ate) ?>" aria-label="Até"></div>
      <select name="cat" aria-label="Categoria"><option value="">Todas as categorias</option><?php foreach (EXPENSE_CATEGORIES as $c): ?><option<?= sel($catF, $c) ?>><?= e($c) ?></option><?php endforeach; ?></select>
      <button class="btn" type="submit"><?= icon('search', 16) ?> Filtrar</button>
    </form>
    <?php if (!$rows): echo empty_state('Nenhuma despesa neste período.', 'wallet'); else: ?>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>Data</th><th>Descrição</th><th>Categoria</th><th class="num">Valor</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="nowrap"><?= e(fdate($r['data_despesa'])) ?></td>
          <td><span class="cell-main"><?= e($r['descricao']) ?></span><span class="cell-sub"><?= e(implode(' · ', array_filter([$r['metodo'], $r['fornecedor']]))) ?></span></td>
          <td><?= badge($r['categoria'], 'neutral') ?></td>
          <td class="num"><?= e(money($r['valor'])) ?></td>
          <td><div class="row-actions">
            <a class="btn btn-sm btn-icon" title="Editar" href="despesas.php?acao=editar&id=<?= (int) $r['id'] ?>"><?= icon('edit', 16) ?></a>
            <form class="inline-form" method="post" data-confirm="Eliminar esta despesa?"><?= csrf_field() ?><input type="hidden" name="op" value="eliminar"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-icon btn-danger" title="Eliminar" type="submit"><?= icon('trash', 16) ?></button></form>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot><tr><td colspan="3">Total do período</td><td class="num"><?= e(money($total)) ?></td><td></td></tr></tfoot>
    </table></div>
    <?= pagination_html($pg) ?>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h2>Por categoria</h2></div>
    <?php if (!$byCat): echo empty_state('Sem dados.', 'chart'); else: foreach ($byCat as $c): $pc = $total > 0 ? (float) $c['t'] / $total * 100 : 0; ?>
      <div style="margin-bottom:14px">
        <div class="stat-row" style="border:0;padding:0 0 6px"><span><?= e($c['categoria']) ?></span><b><?= e(money($c['t'])) ?> <span class="muted" style="font-weight:400">(<?= num($pc, 0) ?>%)</span></b></div>
        <div class="progress"><span style="width:<?= e(number_format($pc, 1, '.', '')) ?>%"></span></div>
      </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<?php page_footer(); ?>
