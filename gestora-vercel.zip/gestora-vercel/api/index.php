<?php
/**
 * Front controller da GesTora na Vercel (runtime vercel-php).
 *
 * O vercel.json encaminha cada pedido de /xxx.php para aqui com ?__p=xxx.php.
 * Só são executados ficheiros .php que estejam diretamente em app/ (nunca includes/, config/ ou database/).
 */

$appDir = realpath(__DIR__ . '/../app');

// 1) Descobrir que página foi pedida
$page = $_GET['__p'] ?? null;

if ($page === null) {
    // Plano B: usar o caminho original do pedido.
    $path = (string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
    $page = ltrim(rawurldecode($path), '/');
}

// 2) Limpar o parâmetro interno para que a aplicação não o veja
unset($_GET['__p'], $_REQUEST['__p']);
if (isset($_SERVER['QUERY_STRING'])) {
    $qs = preg_replace('/(^|&)__p=[^&]*/', '', (string) $_SERVER['QUERY_STRING']);
    $_SERVER['QUERY_STRING'] = ltrim((string) $qs, '&');
}

$page = (string) $page;
if ($page === '' || $page === '/') {
    $page = 'index.php';
}

// 3) Só nomes simples terminados em .php (sem barras, sem ..)
if (!preg_match('/^[A-Za-z0-9_\-]+\.php$/', $page) || $appDir === false || !is_file($appDir . '/' . $page)) {
    http_response_code(404);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><title>Não encontrado</title>'
       . '<body style="font-family:system-ui;display:grid;place-items:center;min-height:100vh;margin:0;background:#060d24;color:#e8eeff">'
       . '<div style="text-align:center"><h1 style="margin:0 0 8px">404</h1><p>Página não encontrada.</p>'
       . '<p><a style="color:#7aa2ff" href="/">Voltar ao início</a></p></div></body>';
    exit;
}

// 4) Fazer a página "acreditar" que foi chamada diretamente
$_SERVER['SCRIPT_NAME']     = '/' . $page;
$_SERVER['PHP_SELF']        = '/' . $page;
$_SERVER['SCRIPT_FILENAME'] = $appDir . '/' . $page;
if (isset($_SERVER['REQUEST_URI']) && strpos((string) $_SERVER['REQUEST_URI'], '/api/index.php') === 0) {
    $_SERVER['REQUEST_URI'] = '/' . $page;
}

chdir($appDir);
require $appDir . '/' . $page;
